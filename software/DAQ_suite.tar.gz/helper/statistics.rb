# This module can be included by classes like Array,
# to easily be able to get statistics for instances.


module Statistics
  
  def sum
    inject(0) {|sum,x| sum += x} unless empty?
  end
  
  def mean
    sum / length.to_f unless empty?
  end
  
  def std_dev
    if empty? then return nil; end
    m = mean
    variance = (inject(0) {|var,i| var += (i-m)**2})/length.to_f
    Math.sqrt(variance)
  end
  
  
  # calculates the running mean - moving average - of data in array x
  # which returns smoothed (low-pass filtered) new array.
  def self.moving_average(ary, num_bins)
    return unless ary
#    # pragmatic version:
#    running_mean = ary[(num_bins/2)-1..-(num_bins/2)+1]
#    ary[num_bins-1..-1].each_index {|i|              
#      running_mean[i-(num_bins/2)] = [ary[i-(num_bins/2)][0], ary[(i-num_bins)..i].inject(0){|x,y| x += y[1]} / num_bins.to_f]
#    }
#    running_mean
    
    #higher performance version: y[k] = y[k-1] + 1/n * (x[k] - x[k-n])
    n = num_bins
    x = ary.collect {|t, val| val }
    y = Hash.new(x[0])
    1.upto(ary.length-1) { |k|      
      if k < n
        y[k] = x[0,k].inject(0) {|el,sum| sum += el } / k.to_f
        #y[k] = y[k-1] + (x[k] - x[1]) / k.to_f
      else
        y[k] = y[k-1] + (x[k] - x[k-n]) / n.to_f
      end
      
    }
    i = -1
    x = ary.collect {|t, val|      
      i += 1
      [t, y[i+num_bins/2]] # adjust for the phase shift
    }

  end 
  
end
