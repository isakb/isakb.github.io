BASH_SCRIPT = <<EOF
#!/bin/sh
module="tdcmod"
device="tdc"
mode="666"

# Group: since distributions do it differently, look for wheel or use staff
if grep -q '^staff:' /etc/group; then
    group="staff"
else
    group="wheel"
fi

# invoke insmod with all arguments we got
# and use a pathname, as insmod doesn't look in . by default
/sbin/insmod ./$module.ko $* || exit 1

# retrieve major number
major=$(awk "\$2==\"$module\" {print \$1}" /proc/devices)

# Remove stale nodes and replace them, then give gid and perms
# Usually the script is shorter, it's scull that has several devices in it.
rm -f /dev/${device}
mknod /dev/${device} c $major 0
chgrp $group /dev/${device}
chmod $mode  /dev/${device}
EOF

def tdc_module_create_loader(file)
  puts "  [Creating loader script...]"
  if File.exist?(file)
    puts "  [already exists: %s]" % file
    return true
  end
  begin
    f = File.new(file, "w")
    f.write(BASH_SCRIPT)
    f.chmod(0777)    
  rescue
    false
  ensure 
    f.close
  end
  puts "  [script created as: %s]" % file
  true
end


def tdc_module_helper(file)
  puts "Execute the loader script as superuser to setup everything you need."
  puts "You need to have the tdc module, normally tdcmod.ko, in the same directory as the loader script."
  puts "Then just execute from terminal as root (or sudo): %s" % file
  puts "(If you get an error execute dmesg to see details.)"
  puts
  puts "If you don't have the tdcmod.ko file, you can compile it from the source code."
  puts "The source code of the module is in the ToF SVN repository under tof/TDC/trunk/module/"
  puts "Egil Andersson or Isak Bakken can give you details on how to access the repository."
  puts
  puts "Note: The tdcmod source code is written for Linux 2.6.x."
  puts "It is tested with Linux 2.6.22 and Linux 2.6.18."
  puts "If you have a different kernel version, you may need to make some changes in the code,"
  puts "as the kernel internals change in different versions."
end
  
   
