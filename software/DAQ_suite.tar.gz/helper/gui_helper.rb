require 'libglade2'

module GuiHelper
  
  def self.quick_format(title, body)
    "<big>#{title}</big>\n\n#{body}"
  end

  # Display a quick messagebox that obstrusively steals the user's attention
  def self.alert(message, parent=nil)
    dialog = Gtk::Dialog.new("Alert",
      parent,
      Gtk::Dialog::DESTROY_WITH_PARENT | Gtk::Dialog::MODAL,
      [Gtk::Stock::OK, Gtk::Dialog::RESPONSE_ACCEPT])

    dialog.width_request = 384
    dialog.height_request = 192

    label = Gtk::Label.new()
    label.wrap = true
    label.width_chars = 60
    label.set_markup(message)

    dialog.vbox.add(label)
    dialog.show_all
    
    dialog.run do |response| # ignore the response, but wait in this loop until user responds...
      dialog.destroy
    end
  end
  
  
  def self.dialog_file_save(title = "Save file as...", filter_pattern=nil, parent_window=nil, &block)
    dialog = Gtk::FileChooserDialog.new(title, parent_window, Gtk::FileChooser::ACTION_SAVE,
      nil, [Gtk::Stock::CANCEL, Gtk::Dialog::RESPONSE_CANCEL], [Gtk::Stock::SAVE, Gtk::Dialog::RESPONSE_ACCEPT])
    dialog.filter = Gtk::FileFilter.new.add_pattern(filter_pattern) unless filter_pattern.nil?
    dialog.do_overwrite_confirmation = true
    while dialog.run == Gtk::Dialog::RESPONSE_ACCEPT
      yield dialog.filename
      break
    end
    dialog.destroy
  end  
  
  def self.dialog_file_open(title="Open File...", filter_pattern=nil, parent_window=nil, msg_no_such_file="Please select a valid file.", current_folder=nil, &block)
    dialog2 = Gtk::FileChooserDialog.new(title, parent_window, Gtk::FileChooser::ACTION_OPEN,
      nil, [Gtk::Stock::CANCEL, Gtk::Dialog::RESPONSE_CANCEL], [Gtk::Stock::OPEN, Gtk::Dialog::RESPONSE_ACCEPT])
    dialog2.current_folder = current_folder if current_folder && File.exist?(current_folder)
    unless filter_pattern.nil?
      f = Gtk::FileFilter.new
      if filter_pattern.is_a?(Array)
        filter_pattern.each {|fp| f.add_pattern(fp) }
      else
         f.add_pattern(filter_pattern)
      end
      dialog2.filter = f
    end
    while dialog2.run == Gtk::Dialog::RESPONSE_ACCEPT
      unless File.exist?(dialog2.filename)          
        self.alert(self.quick_format("Invalid file selected", msg_no_such_file), dialog2)
        next
      end
      yield dialog2.filename
      break
    end
    dialog2.destroy
  end
  
end

