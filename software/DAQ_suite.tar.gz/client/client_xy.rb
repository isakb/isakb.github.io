#!/usr/bin/env ruby

$: << File.expand_path( File.dirname(__FILE__) + "/../")

require 'model/tof_client'
require 'model/gtkglapp'
#require 'helper/pm'

class XYGraphics < Graphics
  attr_accessor :e_positions, :histogram
  def initialize(*args)
    super
    @e_positions = []
    @histogram = Hash.new(0)
  end
  def draw(renderer)
    renderer.drawHistogram(@histogram, "width:100%; height:100%; padding:5")
    @e_positions.each {|pos|
      drawHitPosition(renderer, pos)
    }
    #p @histogram.keys.max #=> kusligt nära (2^16 - 1) för det mesta!
    
    #renderer.drawCircleFilled([@x, @y], 10, RGBA.new(0.2,1,0.5))
    #renderer.drawHistogram(nil, [120, 195], [220, 100])     
  end
  
  def drawHitPosition(renderer, pos)
    if pos.y.nil?
      renderer.drawCircleFilled([pos.x, 0], 2, RGBA.new(0.2,1,0.5)) unless pos.x.nil?
    elsif pos.x.nil?
      renderer.drawCircleFilled([0, pos.y], 2, RGBA.new(0.2,1,0.5)) unless pos.y.nil?
    else
      if ((pos.x - pos.y)**2).abs < 10
        color = RGBA.new(1,1,1)
        size = 1
      else
        color =RGBA.new(1,1,0)
        size = 5
      end
      renderer.drawCircleFilled([pos.x*0.01, pos.y*0.01], size, color)
      if pos.x < -2000 || pos.x > 2000
        puts "X: " << pos.x.to_s
      end
      if pos.y < -2000 || pos.y > 2000
        puts "Y: " << pos.y.to_s
      end      
    end    
  end
end

class ClientAppXY < GtkGLApp  

  class Client
    include TofClient  
  end
  
  
  def initialize(options = {:title => 'ClientAppXY', :width => 1680, :height => 1000, :host=>nil, :port=>nil, :debug=>false})
    options[:title] ||= 'ClientAppXY'
    options[:width] ||= 800
    options[:height] ||= 600
    begin
      super(options[:title], options[:width], options[:height], 32, options[:debug])   
      
      @window.gl_area.graphics = XYGraphics.new(RGBA.new(0x33/255.0, 0x66/255.0, 0xcc/255.0, 0.5),
        options[:width], options[:height] )
      @gfx = @window.gl_area.graphics

      puts "client starting..." if @debug
      @client = Client.new(options)      
      
      @window.gl_area.bgcolor = RGBA.new(0x33/255.0, 0x66/255.0, 0xcc/255.0, 0)
      
      ## Connect signals to handle keyboard user input.
      # destroy current signal handlers (from super class)
      #@window.gl_area.signal_connect("button_press_event") { button_press_event() }
      
      @window.gl_area.signal_connect("button_release_event") { button_release_event() }
      
      ## Connect signals to handle keyboard user input.
      @window.signal_connect("key_press_event") { key_press_event() }
      @window.signal_connect("key_release_event") { key_release_event() }
      
  
      @window.signal_connect("scroll_event") { scroll_event }
      #pm @window.events if @debug
    rescue => e
      raise e
    end
  end 
  
  def scroll_event()
    p Gtk.current_event
  end
  
  def button_press_event()
    #pm @window.gl_area
    @window.gl_area.refresh()
    p "hej"
    p Gtk.current_event.x
  end
  
  def button_release_event()
    #pm @window.gl_area
    #p @client.server.stop
  end
  
  def key_press_event()
    @client.server.run_toggle()
    gather_events if @client.server.running?
    
    #p Gtk.current_event().state # här hittas information om t ex shift används samtidigt. se 
    # http://ruby-gnome2.sourceforge.jp/hiki.cgi?Gtk
    # samt: http://www.pygtk.org/pygtk2tutorial/sec-EventHandling.html    
    true
  end

  def key_release_event() 
    #pm @window.gl_area
    true    
  end
  
  def gather_events
    @thr2 = Thread.new do      
      begin
        timeout(3) { until @client.running? do end }
        
        @client.each_event(10000) do |event|
          @gfx.e_positions.shift if @gfx.e_positions.length > 100
          event.classify
          #puts event.to_s if @debug
          @gfx.e_positions << event.e_pos if event.e_pos          
          event.each do |hit|
            @gfx.histogram[hit.delay] += 1 #if hit.channel == event.ch[:electron]
          end
          #sleep(0.01)
        end   
        puts "No more events..."        
#        File.open("../data/temporary_output.txt", "w") { |f|
#          puts "saving to file..."
#          @gfx.histogram.sort{|a,b| a[1]<=>b[1]}.each_with_index {|key, value|
#            f.puts "#{key}\t#{value}"
#          }
#          puts "done."
#          #exit
#        } if @debug    
      rescue Timeout::Error
        puts "Waited too long for server to start."
        exit
      end
    end
  end
  
  def main    
    Thread.abort_on_exception = true 
    @thr1 = Thread.new do
      p @client.server.help()
      statusmsg = @client.server.status
      status = statusmsg.split[0]
      
      puts "Press any key in main window to start gathering..."
#      case status
#        when "SERVER_STOPPED", "SERVER_ENDED"      
#          puts "data gathering is not running. starting it."          
#          @client.server.start
#      end
    end    
    
    @histogram_update_thread = Thread.new do    
      loop {
        sleep(0.5)    
        @window.gl_area.refresh()
      }
    end
    
    #gather_events
    
#    @thr2 = Thread.new do
#      begin
#        timeout(1) { until @client.running? do end }
#        
#        @client.each_event(10) do |event|
#          @window.gl_area.graphics.e_positions.shift if @window.gl_area.graphics.e_positions.length > 100
#          event.classify
#          puts event.to_s
#          @window.gl_area.graphics.e_positions << event.e_pos if event.e_pos
#        end    
#        @client.quit
#      rescue Timeout::Error
#        puts "Waited too long for server to start."
#        exit
#      end
#    end
    
    

    super
  end
  
end

# Main program
if __FILE__ == $0 
  
  host, port = TofClient.get_host_port_from_argv

  client = ClientAppXY.new(:title => 'ClientApp XY', :width => 800, :height => 300, :debug => true, :host => host, :port => port)  
  client.main  
  
end
