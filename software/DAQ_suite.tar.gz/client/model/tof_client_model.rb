require 'tempfile'
require 'observer'
require '../model/tof_client'
require '../model/daq_metadata'
class TofClientModel
  include Observable

  class Config < Hash
    DEFAULTS = {
      :measurement => DaqMetaData.new,
      :GUI => {
        :energy_scale => 200,
        :dock_gnuplot => false, # show gnuplot in the notebook, or in a child window?
        :spectrum => :exToF,
        :widgets => {
          :tbAutoUpdateSpectrum =>  {:active => true},
        },
      },
      :server => {}
    }
    def initialize(opts = {})
      super
      DEFAULTS.merge(opts).each {|k,v| self[k]=v }
    end
  end

  class Client
    include TofClient
  end

  attr_accessor :cfg,
                :hist_ex_ToF,
                :hist_ex_E,
                :hist_e1_ToF,
                :hist_e1_E,
                :config_filename,
                :autosave_filename,
                :measurement_files,
                :client, :client_clone,
                :threads,

                :str_multi_tof # TODO: This is just temporary...

  attr_reader :is_connected, :daq_state

  def initialize(client_options)
    @cfg = Config.new

    @threads = {}

    @client = Client.new(client_options, false)
    @client_clone = Client.new(client_options, false)

    @config_filename = nil # the selected config file with custom configuration

    _clear_histograms()

    @histogram_lock = Mutex.new

    @autosave_filename = {}
    @measurement_files = {}

    @daq_state = nil # set it to nil first so that setting it to false in the controller initializer will init the GUI correctly
    @is_connected = nil
  end

  def setup_autosave_path()
    timestamp = Time.now.strftime("%Y-%m-%d_%H%M%S")
    dir = "./autosaved_data/#{timestamp[0..9]}"
    File.makedirs(dir) unless File.exist?(dir)
    @autosave_filename[:metadata] = "#{dir}/#{timestamp}_metadata.par"
    @autosave_filename[:exToF] = "#{dir}/#{timestamp}_all_electrons-exToF.tofspc"
    @autosave_filename[:e1ToF] = "#{dir}/#{timestamp}_single_electrons-e1ToF.tofspc"
    @autosave_filename[:e1e2ToF] = "#{dir}/#{timestamp}_double_electrons-e2ToF.e2c.txt"
    @autosave_filename[:e1e2e3ToF] = "#{dir}/#{timestamp}_triple_electrons-e3ToF.e3c.txt"
    @autosave_filename[:e1e2e3e4ToF] = "#{dir}/#{timestamp}_quad_electrons-e4ToF.e4c.txt"
    @autosave_filename[:e1e2e3e4e5ToF] = "#{dir}/#{timestamp}_pent_electrons-e5ToF.e5c.txt"
    return dir
  end
  def autosave_data()
    return unless @autosave_filename[:metadata]
    tof_spectrum_file_temp = Tempfile.new('ToF_spc_tmpfile')
    self.sync_histograms {
      @str_multi_tof.each do |typ, value|
        next unless value
        sym = {2=>:e1e2ToF, 3=>:e1e2e3ToF, 4=>:e1e2e3e4ToF, 5=>:e1e2e3e4e5ToF}
        filename = @autosave_filename[sym[typ]]
        begin
          File.open(filename, "ab") {|f| f.write(value) }
        rescue
          puts "Error saving spectrum file #{filename}"
        end      
        @str_multi_tof[typ] = ""
      end
      ary = @hist_ex_ToF.to_a.sort
      # two bytes (16-bit) for unsigned index, 8 bytes for unsigned long counter
      ary.each{|v| tof_spectrum_file_temp.print(v.pack("SL")) }
      if tof_spectrum_file_temp.size > 0
        File.copy(tof_spectrum_file_temp.path, @autosave_filename[:exToF])
      end
      ary = @hist_e1_ToF.to_a.sort
      ary.each{|v| tof_spectrum_file_temp.print(v.pack("SL")) }
      if tof_spectrum_file_temp.size > 0
        File.copy(tof_spectrum_file_temp.path, @autosave_filename[:e1ToF])
      end
      #Save metadata
      begin
        File.open(@autosave_filename[:metadata], 'w') {|f|
          YAML.dump(@cfg[:measurement], f)
        }
      rescue => e
        puts "Error saving metadata."
      end      
    }
    @autosave_filename.each { |k,v|
      @measurement_files[k] = v unless k == :metadata
    }
  end

  def is_connected=(value)
    if value != @is_connected
      @is_connected = (value == true)
      changed
      notify_observers(:connection_state_changed, @is_connected)
    end
  end

  def daq_state=(value)
    if value != @daq_state
      @daq_state = value
      changed
      notify_observers(:daq_state_changed, @daq_state)
    end
  end
  def daq_running?() @daq_state == :running end

  def hist_ex_ToF_sorted
    @histogram_lock.synchronize { @hist_ex_ToF.to_a.sort }
  end
  def hist_ex_E_sorted
    @histogram_lock.synchronize { @hist_ex_E.to_a.sort[1..-1] } # ignore the first bin, nrj = -0xDEAD
  end
  
  

  def clear_histograms(lock=true)
    if lock
      sync_histograms {
        _clear_histograms
      }
    else
      _clear_histograms
    end
  end
  
  def clear_measurement()
    clear_histograms
    @measurement_files = {}
  end

  def sync_histograms(&block)
    @histogram_lock.synchronize do
      yield
    end
  end
  def measurement_details()
    @cfg[:measurement].to_yaml.to_s
  end
  def load_measurement_from_file(file)    
    clear_measurement()
    str = file.gsub("_metadata.par", "") 
    filename = {}
    filename[:metadata] = str + "_metadata.par"
    filename[:exToF] = str + "_all_electrons-exToF.tofspc"
    filename[:e1ToF] = str + "_single_electrons-e1ToF.tofspc"
    filename[:e1e2ToF] = str + "_double_electrons-e2ToF.e2c.txt"
    filename[:e1e2e3ToF] = str + "_triple_electrons-e3ToF.e3c.txt"
    filename[:e1e2e3e4ToF] = str + "_quad_electrons-e4ToF.e4c.txt"
    filename[:e1e2e3e4e5ToF] = str + "_pent_electrons-e5ToF.e5c.txt"
    @measurement_files = filename    
  end

  def load_hist_ex_from_file(file)
    spectrum_type = :none
    sync_histograms {
      #clear_histograms(false)
      begin        
        f = File.open(file, "rb")        
        case file     
          when /\.tofspc$/
            spectrum_type = :exToF
            puts "Reading time-of-flight spectrum from file: #{file}"                    
            loop {
              str = f.read(6)
              break unless str
              t, val = str.unpack("SL")   
              next if t < @cfg[:measurement][:t_min] || @cfg[:measurement][:t_max] < t
              @hist_ex_ToF[t] += val
              energy = time_to_energy(t, true)
              @hist_ex_E[energy] += val
            }                        
          when /\.e2c/
            spectrum_type = :e1e2ToF
            puts "Reading e1 vs e2 coincidence time-of-flight spectrum from file: #{file}"
            @str_multi_tof[2] = f.read
          when /\.e3c/
            spectrum_type = :e1e2e3ToF
            puts "Reading e1 vs e2 vs e3 coincidence time-of-flight spectrum from file: #{file}"
            @str_multi_tof[3] = f.read            
          else
            puts "No implemented handler for spectrum file: #{file}"           
        end
      ensure
        f.close if f
      end      
    }
    @cfg[:GUI][:spectrum] = spectrum_type
    return spectrum_type
  end

  # Add a TDC event from the server to the relevant histograms
  def add_hist_data(event)    
    num_electrons = event.classify #is it a single/double/triple hit, etc?
    # incoming t is in units of 0.5 ns, so double the t_min/max settings in this check:
    delays = event.electrons_delays {|t| @cfg[:measurement][:t_min]*2 < t && t < @cfg[:measurement][:t_max]*2 }
    return unless delays # if no delays satisfy the criteria
    
    # after checking if time range is satisfied, some electrons might be dropped...
    num_electrons = delays.length

    delays = delays.map{|t|
      # incoming t is in units of 0.5 ns
      # reduce resolution?
      case @cfg[:measurement][:t_res]
      when 0.5
        # no change, by default the time unit is 0.5 ns
      when 1
        t >>= 1 # reduces resolution to 1 ns
      when 2  # 2 ns
        t >>= 2
      when 4  # 4 ns
        t >>= 3
      when 8  # 8 ns
        t >>= 4
      else
        raise "Bad @cfg[:measurement][:t_res] value"
      end

      sync_histograms {
      
      # These histograms have information about ALL electrons:
        @hist_ex_ToF[t] += 1
        @hist_ex_E[time_to_energy(t, true)] += 1
      }

      t # return the new t from the block
    }

    #Now take care of sorting out singles, doubles, triples, etc:
    sync_histograms {
      case num_electrons
        when 1
          # These histograms have information about SINGLE electrons:
          @hist_e1_ToF[delays[0]] += 1
          @hist_e1_E[time_to_energy(delays[0], true)] += 1

        # TODO: Do relevant things with doubles, triples, etc.
      when 2..5
          # check dt (delta-t, min time difference) criteria:
          1.upto(num_electrons-1) {|i|
            if @cfg[:measurement][:t_diff_min] >= (delays[i] - delays[i-1]).abs
              return # do not add to multihit
            end
          }          
          @str_multi_tof[num_electrons] += delays.pack("L*")
      end
    }
  end

  # converts flight-time of electrons into kinetic energy
  def time_to_energy(t, evenly_spaced_bins=false)
    d = @cfg[:measurement][:length_constant]
    t0 = @cfg[:measurement][:t_offset] || 0
    e0 = @cfg[:measurement][:energy_offset] || 0

    energy = ( d/(t+t0) )**2 - e0
    
    return (@cfg[:GUI][:energy_scale]*energy + 0.5).to_i / @cfg[:GUI][:energy_scale].to_f if evenly_spaced_bins
    return energy
  end

  protected
  def _clear_histograms
    #Histograms for electrons of type x, i.e. any number of hits. ToF = Time-of-flight. Ekin = Kinetic energy
    #@hist_ex_ToF = GSL::Vector.calloc(@model.cfg[:measurement][:t_max])
    #Histograms for electrons of type 1,2,3, that is singles, doubles, triples:
    # Don't save histograms, instead save raw data about the events:

    @hist_e1_ToF = nil
    @hist_e1_E = nil
    @hist_ex_ToF = nil
    @hist_ex_E = nil
    @str_multi_tof = nil

    @hist_e1_ToF = Hash.new(0)
    @hist_e1_E = Hash.new(0)
    @hist_ex_ToF = Hash.new(0)
    @hist_ex_E = Hash.new(0)
    @str_multi_tof = Hash.new("")
    # This implicit declaration is due to some bug with Hash.each that cannot find each element if I just use Hash.new("")
    #@str_multi_tof = {0=>"", 1=>"", 2=>"", 3=>"", 4=>"", 5=>"", 6=>"", 7=>"", 8=>"", 9=>"", 10=>"", 11=>"", 12=>"", 13=>"", 14=>"", 15=>"", 16=>""}
  end

end
