require 'tempfile'
require 'observer'



class BasicPlotter
  include Observable
  def initialize(model, socket=nil)
    @model = model
    @socket = socket
    @gnu_pipe = IO.popen("gnuplot","r+")
    @spectrum_plot_file = Tempfile.new('ToF_spectrum_data')
    @smoothed_spectrum_plot_file = Tempfile.new('ToF_spectrum_data_smoothed')
    prepare()
  end

  def set_spectrum_type(type)
    case type
      when :exToF
      @gnu_pipe.puts  "set title 'Electron time-of-flight spectrum';" <<
                        ("set xlabel 'flight-time (%sns)';" % (@model.cfg[:measurement][:t_res] != 1 ? "%.1f "%@model.cfg[:measurement][:t_res] : ""))<<
                        "set ylabel 'electron count';"

      when :exEkin
      @gnu_pipe.puts  "set title 'Electron kinetic energies';" <<
                      ("set xlabel 'energy (? unit)';")<<
                        "set ylabel 'intensity (arbitrary units)';"
    end
    prepare()
  end

  def prepare_gnuplot()
    sleep(0.05)
    # choose the appropriate socket, depending on which spectrum we want to see
    socket_id = @socket[@model.cfg[:GUI][:spectrum]].id.to_i.to_s(16) if @socket

    if @socket && @model.cfg[:GUI][:dock_gnuplot]
      @gnu_pipe << "set term x11 window \"#{socket_id}\"; "
    else
      @gnu_pipe << "set term x11; "
    end
    #@gnu_pipe << "set datafile separator ',' ;"
    @gnu_pipe.puts "reset"
    @gnu_pipe.puts "set autoscale keepfix"

#    case @model.cfg[:GUI][:spectrum]
#      when :exToF
#      @gnu_pipe.puts  "set title 'Electron time-of-flight spectrum';" <<
#                        ("set xlabel 'flight-time (%sns)';" % (@model.cfg[:measurement][:t_res] != 1 ? "%.1f "%@model.cfg[:measurement][:t_res] : ""))<<
#                        "set ylabel 'electron count';"
#
#      when :exEkin
#      @gnu_pipe.puts  "set title 'Electron kinetic energies';" <<
#                      ("set xlabel 'energy (? unit)';")<<
#                        "set ylabel 'intensity (arbitrary units)';"
#    end

    #@gnu_pipe.puts "plot x**2;"
    @gnu_pipe.flush


#      # HSV palette
#      @gnu_pipe.puts  "set palette model HSV;" <<
#                      "set palette defined ( 0 0 1 1, 1 1 1 1 );" <<
#                      "set palette defined ( 0 0 1 0, 1 0 1 1, 6 0.8333 1 1, 7 0.8333 0 1);"

  end
  alias :prepare :prepare_gnuplot

  def gnuplot_zoomout
    @gnu_pipe << "reset;"
    prepare_gnuplot
    update_spectrum
    @gnu_pipe.puts "replot"
  end
  alias :zoomout :gnuplot_zoomout

  def update_spectrum(extra_plot="")
    #return if @model.cfg[:GUI][:spectrum].nil? or @model.hist_ex_ToF.nil? or @model.hist_ex_ToF.empty?

    @spectrum_plot_file.truncate(0)
    @spectrum_plot_file.pos = 0
    #which spectrum should be plotted?
    plot = "plot"
    case @model.cfg[:GUI][:spectrum]
      when nil, :exToF
        #time-of-flight spectrum for all electrons
        format = " binary format=\"%uint16%uint32\""
        plot_type = " with impulses title 'Spectrum' lt 1"
        ary = @model.hist_ex_ToF_sorted()
        # if binary:
        ary.each{|a| @spectrum_plot_file.print(a.pack("SL")) }
        # if plain text:
#        ary.each do |t, val|
#          @spectrum_plot_file.puts("#{t}\t#{val}") # if hist_ex_E is used, t is energy, not time
#        end

      when :e1e2ToF
        #time-of-flight spectrum for double electrons
        format = " binary format=\"%uint32%uint32\" using 1:2" # TODO: uint16 instead?
        plot_type = "  title 'e1 vs e2 ToF' "
        # if binary:
        @spectrum_plot_file.print(@model.str_multi_tof[2])
        # if plain text:
#        ary = @model.hist_e2_ToF_sorted()
#        ary.each do |t, val|
#          @spectrum_plot_file.puts("#{t}\t#{val}") # if hist_ex_E is used, t is energy, not time
#        end
      when :e1e2e3ToF
        #time-of-flight spectrum for triple electrons
#        @gnu_pipe.puts "set pm3d map"
#        @gnu_pipe.puts "set isosample 400"
#        @gnu_pipe.puts "set palette defined (-1 'blue', 0 'red', 1 'yellow')"
        plot = "splot"
        format = " binary format=\"%uint32%uint32%uint32\" using 1:2:3" # TODO: uint16 instead?

        plot_type = "  title 'e1 vs e2 vs e3 tof' "
        @spectrum_plot_file.print(@model.str_multi_tof[3])
      when :exEkin
        #corresponding energy for all electrons
        format = " binary format=\"%float32%uint32\""
        plot_type = " with filledcurve y1=0 title 'Spectrum' lt 1"
        ary = @model.hist_ex_E_sorted()
        # if binary:
        if ary
          ary.each{|a| @spectrum_plot_file.print(a.pack("FL"))}
        else
          puts "No hist_ex_E_sorted found!"
        end
        # if plain text:
#        ary.select {|nrj,val|
#          #@plot_e_min < nrj && nrj < @plot_e_max
#          true
#        }.each do |nrj, val|
#          @spectrum_plot_file.puts("#{nrj}\t#{val}") # if hist_ex_E is used, t is energy, not time
#        end
      else
        puts "Wrong spectrum is selected: " << @model.cfg[:GUI][:spectrum].to_s
        return
    end
    @spectrum_plot_file.flush
    if File.size(@spectrum_plot_file.path) > 0
      @gnu_pipe << plot << " '#{@spectrum_plot_file.path}' " << format << plot_type << extra_plot
      @gnu_pipe.puts
    else
      sleep(0.05)
    end
  end
  alias :update :update_spectrum
  alias :refresh :update_spectrum
end


class Plotter < BasicPlotter
  attr :runMeanNum

  def initialize(model, socket=nil)
    super(model, socket)
    @runMeanNum = 0
  end
  def runMeanNum=(val)
    if val != @runMeanNum
      @runMeanNum = val
      changed
      notify_observers(:runMeanNum_value_changed, val)
    end
  end
  def update_spectrum()    
    runMeanNum = @runMeanNum # @widgets["spinRunMean"].value.to_i
    if runMeanNum > 0    
      case @model.cfg[:GUI][:spectrum]
        when nil, :exToF
          ary = @model.hist_ex_ToF_sorted()
        when :exEkin
          ary = @model.hist_ex_E_sorted()
      end     
      return unless ary
      running_mean = Statistics.moving_average(ary, runMeanNum)
      @smoothed_spectrum_plot_file.truncate(0)
      @smoothed_spectrum_plot_file.pos = 0
      # if binary is used:
      smooth_format = " binary format=\"%float32%float32\""
      running_mean.each{|a| @smoothed_spectrum_plot_file.print(a.pack("FF")) }
      # if plain text is used:
#      running_mean.each do |t,val|
#        @smoothed_spectrum_plot_file.puts("#{t}\t#{val}")
#      end
      @smoothed_spectrum_plot_file.flush
      extra_plot = ", '#{@smoothed_spectrum_plot_file.path}' " << smooth_format << " with lines title 'Running mean' lt 3 lw 1"
    else
      extra_plot = ""
    end
    super(extra_plot)

#    # Hash version, printing directly to gnuplot:
#    @gnu_pipe << "plot '-' with impulses title 'Spectrum' lt 1"
#    @gnu_pipe << ", '-' with lines title 'Running mean' lt 3 lw 1\n"
#    ary = @model.hist_ex_ToF.to_a.sort
#    ary.each do |t, val|
#      @gnu_pipe.puts "#{t}\t#{val}"
#    end
#    #@gnu_pipe.puts "e"
#
#    if runMeanNum > 0
#      #running_mean = Statistics.moving_average(ary, runMeanNum)
#      running_mean = Statistics.moving_average(ary, runMeanNum)
#      @gnu_pipe.puts
#      #@gnu_pipe << ", plot '-' with lines title 'Running mean' lt 3 lw 1\n"
#      #@gnu_pipe << ", '-' with lines title 'Running mean' lt 3 lw 1\n"
#      running_mean.each do |t,val|
#        @gnu_pipe.puts "#{t}\t#{val}"
#      end
#      @gnu_pipe.puts "e"
#    end
#    @gnu_pipe.flush


  end
  alias :update :update_spectrum
  alias :refresh :update_spectrum
end

class DensityPlotter  

  def initialize(model)
    @model = model
    @gnu_pipe = IO.popen("gnuplot","r+")    
  end

  
  def plot_2d_map(file, t_min, t_max, bins=500)
    # Make the colored map
    begin
      require 'gsl'
    rescue LoadError
      puts "GNU Scientific Library is not installed! Please install it if you need to view the more advanced features."
      return
    end    

    h2 = GSL::Histogram2d.alloc(bins, [t_min, t_max], bins, [t_min, t_max])
    
    arr = File.open(file).read.unpack("I*") # TODO: uint16 instead of uint32?
    times = []
    until arr.empty?
      times << [arr.shift, arr.shift]
    end
    times.each {|e1,e2|
      h2.increment(e1,e2)
      h2.increment(e2,e1) #symmetry...
    }
    path = "/tmp/tofHist2Dplot.txt"
    h2.fprintf(path)
    rgb="21,22,23"
    cmd = "set pm3d map; "
    #cmd << "set isosample 40,40; "
    #cmd << "set palette rgbformulae #{rgb}; "
    cmd << "set palette model XYZ functions gray**0.35, gray**0.5, gray**0.8; "
    cmd << "splot \"#{path}\" using 1:3:5 ; "
    @gnu_pipe.puts cmd

#    hx = h2.xproject
#    hy = h2.yproject
#    printf("%f %f %f %f\n", h2.xsigma, h2.ysigma, hx.sigma, hy.sigma)
#    GSL::graph(hx, hy, "-T X -C -g 3")
    
  end  
  
  
  def plot_2d_map_Ekin(file, t_min, t_max, bins=500)
    # Make the colored map
    begin
      require 'gsl'
    rescue LoadError
      puts "GNU Scientific Library is not installed! Please install it if you need to view the more advanced features."
      return
    end

    h2 = GSL::Histogram2d.alloc(bins, [t_min, t_max], bins, [t_min, t_max])
    
    arr = File.open(file).read.unpack("I*") # TODO: uint16 instead of uint32?
    times = []
    until arr.empty?
      times << [arr.shift, arr.shift]
    end
    times.each {|e1,e2|
      e1, e2 = @model.time_to_energy(e1), @model.time_to_energy(e2)    
      h2.increment(e1,e2)
      h2.increment(e2,e1) #symmetry...
    }
    path = "/tmp/EkinHist2Dplot.txt"
    h2.fprintf(path)
    rgb="21,22,23"
    
    ## To plot a 3D graph for viewing intensities along the energy lines, like in Phys. Rev. Letters 90, Eland, Fig 4:
    ## bins = 100 
    #cmd = "set pm3d; "
    #cmd << "set isosample 40,40; "
    
    cmd = "set pm3d map; "
    #cmd << "set palette rgbformulae #{rgb}; "
    cmd << "set palette model XYZ functions gray**0.35, gray**0.5, gray**0.8; "
    cmd << "splot \"#{path}\" using 1:3:5 ; "
    @gnu_pipe.puts cmd
  end
  
end



