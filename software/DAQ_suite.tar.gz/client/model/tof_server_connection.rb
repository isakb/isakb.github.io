require 'net/telnet'

$: << File.expand_path( File.dirname(__FILE__) + "/../../")
require 'model/protocol'

# This class uses the decorator pattern.
# Instead of extending Net::Telnet, it subclasses it.

class TofServerConnection

  attr_accessor :state
  
  class EWrongServer < RuntimeError; end
  class EWrongProtocol < RuntimeError; end
  class ECannotStart < RuntimeError; end
  class ERunningAlready < RuntimeError; end
  class EOffline < RuntimeError; end

  MAX_NO_DATA_READS = 5 # if server has replied that no data is available, stop trying after this many read attempts.
  TELNET_TIMEOUT = 10 #seconds
  
  def initialize(options = {:host=>nil, :port=>nil, :client=>nil, :debug=>false, :debug_comm=>false, :do_connect => true })
    @telnet = nil
    @state = :offline
    @state_lock = Mutex.new # for changing state
    @count_failed_attempts = 0
    @debug = options[:debug]
    @debug_comm = options[:debug_comm]
    @semaphore = Mutex.new
    @client = options[:client]
    connect if options[:do_connect]
    @options = options
  end

  def connect()
    raise ECannotStart, "Host and port must be specified." if @options[:host].nil? or @options[:port].nil?
    raise ECannotStart, "Already connected." if @telnet
    @telnet = Net::Telnet.new('Host' => @options[:host],
                              'Port' => @options[:port],
                              'Telnetmode' => true,
                              'Timeout' => TELNET_TIMEOUT )
    @state_lock.synchronize { @state = :connected }
    true
  end

  def connected?() not @state_lock.synchronize { @state == :offline } end

  def disconnect()
    try_command(TofProtocol.cmd(:quit))
    @telnet = nil
    @state_lock.synchronize { @state = :offline }
  end

  # client sends cmd to server
  def say(cmd)
    if @state_lock.synchronize { @state == :offline }
      @client.inform "Server is offline!" if @debug
      return
    end
    begin
      @client.inform "\n      [ client:  #{cmd.to_s.dump} ]" if @debug_comm
      @telnet.puts cmd.to_s
    rescue Errno::EPIPE, Errno::ECONNRESET => e
      @client.on_server_disconnect
      @client.inform "Connection to server was reset. " << e if @debug
    rescue => e
      @state_lock.synchronize { @state = :offline }
      raise e
    end
  end

  # client listens to what server says
  def listen(raw = false)
    raise EOffline if @state_lock.synchronize { @state == :offline }
    begin
      resp = Timeout.timeout(@client.listen_timeout) {
        raw ? @telnet.gets : @telnet.gets.to_s.chomp
      }
      @client.inform "      [ server:  #{resp.to_s.dump} ] \n" if @debug_comm
      return resp
    rescue Errno::EPIPE, Errno::ECONNRESET => e
      @client.on_server_disconnect
      @client.inform "Connection to server was reset. " << e if @debug
      raise EOffline
    rescue Timeout::Error
      @state_lock.synchronize { @state = :offline }
      raise TofProtocol::ERROR::NoServerResponse, "Waited for a server response for #{@client.listen_timeout} seconds without success."
    end
  end

  def run_toggle()
    if running?
      stop()
    else
      start()
    end
  end


  def running?() @state_lock.synchronize { @state == :running } end

  def stop()
    @state_lock.synchronize { @state = :stopped } if try_command_check(TofProtocol.cmd(:stop))
    @state_lock.synchronize { @state == :stopped }
  end
  
  def pause()
    @state_lock.synchronize { @state = :paused } if try_command_check(TofProtocol.cmd(:pause))
    @state_lock.synchronize { @state == :paused }
  end  

#  # Instead of explicitly declaring all simple protocol command functions, like:
#  #   def clear() try_command(TofProtocol.cmd(:clear)) end
#  #   def status() try_command(TofProtocol.cmd(:status)) end
#  #   def test() try_command(TofProtocol.cmd(:test)) end
#  #   def help(keyword=nil) try_command(TofProtocol.cmd(:help), keyword) end
#  # let's have them all in this function, for easier maintainability.
#  # On second thought: This would break the methods like responds_to? etc.
#  # So let's have explicit declartations instead, for now.
#  def method_missing(method, *args, &block)
#    #first, see if it's a valid protocol command, and if so, try to execute it
#    if TofProtocol.has_cmd?(method)
#      return try_command(TofProtocol.cmd(method), *args, &block)
#    else
#      # the method is probably not defined
#      raise NoMethodError, "undefined method `#{method.to_s}' for #{self}"
#    end
#  end
  def clear() try_command_check(TofProtocol.cmd(:clear)) end
  def status() try_command(TofProtocol.cmd(:status)) end
  def test() try_command(TofProtocol.cmd(:test)) end
  def help(keyword=nil) try_command(TofProtocol.cmd(:help), keyword) end

  def configure(options = {})
    options = {
      :max_hits_per_channel => -1,
      :com_mode => "COMMON_START",
      :t_min => 0,
      :t_max => 0xffff,
      :trig_rate => 4000
    }.merge(options)
    unless try_command_check(TofProtocol.cmd(:configure), [options[:t_min], options[:t_max], options[:trig_rate], options[:com_mode], options[:max_hits_per_channel]])
      raise "Error with configure"
    end
  end

  def start(num_com_limit=0)
    cmd = TofProtocol.cmd(:start)
    message = try_command(cmd, num_com_limit) {|m| p m }
    case message
      when cmd.responses[:success] #TofProtocol.tdc_started()
        @state_lock.synchronize { @state = :running }
      when cmd.responses[:failure] # TofProtocol.tdc_start_failure()
        raise ECannotStart, "the server didn't start as expected"
      when cmd.responses[:already_started] # TofProtocol.tdc_already_started()
        @state_lock.synchronize { @state = :running }
        raise ERunningAlready, "server is already running"
    else
      raise ECannotStart, message
    end
    running?
  end

    # give ack and wait for server ack?
  def send_ack?(message, server_ack = nil)
    @client.inform "Sending ack message: %s to server."  % message if @debug_comm
    say message
    return ack?(server_ack) unless server_ack.nil?
    return true
  end

  # wait for server ack and give ack to server afterwards
  def wait_for_ack(message, client_ok = nil, client_err = nil)
    unless ack?(message)
      say client_err unless client_err.nil?
      return false
    end
    say client_ok unless client_ok.nil?
    true
  end


  # get ack from server?
  def ack?(expected)
    msg = listen()
    unless msg == expected
      @client.inform "Ack err: %s, expected: %s " % [msg, expected] if @debug_comm
      return false
    end
    @client.inform "Ack received: %s"  % expected if @debug_comm
    true
  end

  def try_read(*args)
    raise EOffline if @state_lock.synchronize { @state == :offline }
    begin
      resp = Timeout.timeout(@client.listen_timeout) { @telnet.read(*args) }
      if @debug_comm
        @client.inform resp.to_s.length < 100 ? "      [ server:  #{resp.to_s[0,60].dump} ] \n" : "      [ server: ... #{resp.to_s.length} bytes ... ] \n"
      end
      return resp
    rescue Errno::EPIPE, Errno::ECONNRESET => e
      @client.on_server_disconnect
      @client.inform "Connection to server was reset. " << e if @debug
      raise EOffline
    rescue Timeout::Error
      @state_lock.synchronize { @state = :offline }
      raise TofProtocol::ERROR::NoServerResponse, "Waited for a server response for #{@client.listen_timeout} seconds without success." if @debug
    end
  end

  def read_bytestream()
    #number of bytes to expect:
    str = listen
    if str == TofProtocol.tx_no_data_server()
      say(TofProtocol.tx_no_data_client())
      sleep(1)
      return
    end

    str =~ Regexp.new(TofProtocol.tx_bytes_server("([0-9]+)"))
    num_bytes = $1.to_i

    raise TofProtocol::ERROR::TransmitFailure, "num_bytes = %d, which is not > 0." % [num_bytes] unless num_bytes > 0
    raise TofProtocol::ERROR::TransmitFailure, "Could not receieve all of the expected text. Received %d bytes but expected %d bytes." % [str.length, num_bytes] \
      unless send_ack?(TofProtocol.tx_bytes_client(num_bytes), TofProtocol.server_ack)

    #read until nym_bytes bytes is received
    str = try_read(num_bytes)

    #verify length of data with server
    raise TofProtocol::ERROR::TransmitFailure, "Could not receieve complete stream. Received %d bytes but expected %d bytes." % [str.length, num_bytes] \
      unless send_ack?(TofProtocol.tx_bytes_client_ack(str.length), TofProtocol.tx_server_ok)

    yield str if block_given?
    str
  end

  def read_eventstream()
    #number of events and bytes to expect:
    str = listen
    #todo: TofProtocol...
    if str == TofProtocol.tx_no_data_server()
      say(TofProtocol.tx_no_data_client())
      sleep(1)
      return
    end

    str =~ Regexp.new(TofProtocol.tx_bytes_server("([0-9]+) ([0-9]+)"))
    num_events, num_bytes = $1.to_i, $2.to_i

    raise TofProtocol::ERROR::TransmitFailure, "num_bytes = %d, which is not > 0." % [num_bytes] unless num_bytes > 0
    raise TofProtocol::ERROR::TransmitFailure, "Could not receieve all of the expected text. Received %d bytes but expected %d bytes." % [str.length, num_bytes] \
      unless send_ack?(TofProtocol.tx_events_client(num_events, num_bytes), TofProtocol.server_ack)

    @client.inform "will read %d events (encoded as %d bytes)..." % [num_events, num_bytes] if @debug_comm

    #read until nym_bytes bytes is received
    buffer = try_read(num_bytes)

    #verify length of data with server
    raise TofProtocol::ERROR::TransmitFailure, "Could not receieve complete stream. Received %d bytes but expected %d bytes." % [str.length, num_bytes] \
      unless send_ack?(TofProtocol.tx_bytes_client_ack(buffer.length), TofProtocol.tx_server_ok)

    yield buffer if block_given?

    buffer
  end


  def get_by_cmd(command, *args)
    try_command(TofProtocol.cmd(command), *args) { |cmd|
      func = case cmd.transmit_procedure.type
        when :line: #unimplemented
        when :stream: :read_bytestream
        when :events: :read_eventstream
      end
      self.send(func) { |buf|
        @client.inform "got one buf, bufsize: %s" % buf.size.to_s if @debug
        @count_failed_attempts = 0
        yield buf if block_given?
        return true
      }
      @client.inform "got nothing" if @debug
      @count_failed_attempts += 1
      return false
    }
  end

#  def get_histogram()
#    try_command(TofProtocol.cmd(:read_histogram)) {
#      ret = read_bytestream {|buf|
#        @count_failed_attempts = 0
#        yield buf if block_given?
#      }
#      @count_failed_attempts += 1 if ret.nil?
#    }
#  end

  def has_more_data?()
    @count_failed_attempts < MAX_NO_DATA_READS
  end
  def has_more_data=(reset)
    @count_failed_attempts = 0 if reset
  end 

  # sends a command to the server and checks if it is valid
  # raises TofProtocol::ERROR::InvalidCommand if command is not accepted
  def try_command(command, parameters = nil)
    begin
      raise EOffline if @state_lock.synchronize { @state == :offline }
      raise "command is nil" unless command
      @semaphore.synchronize {
        parameters = parameters.join(" ") if parameters.kind_of?(Array)
        instruction = "" << command
        instruction << " %s" % parameters unless parameters.nil?
        say instruction        
        raise TofProtocol::ERROR::InvalidCommand, "Server did not accept command: #{command} (parameters: #{parameters})" \
          unless ack?(TofProtocol.cmd_ok(command))
        if block_given?
          yield command
        end
        case command.transmit_procedure.type
          when :line            
            return listen.strip # remove "\r" and "\n" ...
          when :stream
            return read_bytestream
          when :events
            return read_events
          else
            return nil
        end
      }
    rescue => e
      raise e if @debug
      p "EXCEPTION: "
      p e
    end
    false
  end
  
  # Validates according to command response codes. Only for commands that transmit one line.
  def try_command_check(command, *parameters)
    raise ArgumentError, "Wrong command type" if command.transmit_procedure.type != :line
    try_command(command, *parameters) == command.responses[:success]
  end

end