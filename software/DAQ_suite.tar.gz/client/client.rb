#!/usr/bin/env ruby
#
# This file is gererated by ruby-glade-create-template 1.1.4.
#

$: << File.expand_path( File.dirname(__FILE__) + "/../")

require 'model/gtkglapp'
require 'helper/pm'

class Graphics    
  def draw(renderer)
    #GL.Color3f(0.2, 0.1, 1)  
      
    renderer.drawCircleFilled(center=[0,-100], radius=100, fillcolor=RGBA.new(0.2,1,0.5))
    
    # drawCircle is BUGGY!
    #renderer.drawCircle(center=[0,100], radius=100, color=RGBA.new(0.2,1,0.5))      
    
#    ## Scene Rendering Code ------------------------------------------------->>>
#    GL.PushMatrix()
#    GL.LineWidth(4.0)
#    GL.Begin(GL::LINE_STRIP)
#      GL.Color3f(0, 0, 1)
#      GL.Vertex2f(-10, -10)
#      GL.Color3f(0, 1, 0)
#      GL.Vertex2f(10, 10)
#      GL.Color3f(1, 0, 0)
#      GL.Vertex2f(10, -10)
#      GL.Vertex2f(100, -10)
#      GL.Color3f(0, 0.2, 0)
#      GL.Vertex2f(0, -200)
#    GL.End()    
#    GL.PopMatrix()
#    ## ------------------------------------------------------------------------- 
             
    renderer.drawHistogram(nil, [-380, -280], [740, 380])
    renderer.drawHistogram(nil, [-395, -295], [200,100]) 
  end    
end

class Client < GtkGLApp
  
  def initialize(debug)
    super("Client", 800, 600, 32, debug)    

    @window.gl_area.graphics = Graphics.new(RGBA.new(0x33/255.0, 0x66/255.0, 0xcc/255.0, 0))
    
    ## Connect signals to handle keyboard user input.
    # destroy current signal handlers (from super class)
    @window.gl_area.signal_connect("button_press_event") { button_press_event() }
    @window.gl_area.signal_connect("button_release_event") { button_release_event() }
    
    ## Connect signals to handle keyboard user input.
    @window.signal_connect("key_press_event") { key_press_event() }
    @window.signal_connect("key_release_event") { key_release_event() }
    

    @window.signal_connect("scroll_event") { scroll_event }
    pm @window.events
  end 
  
  def scroll_event()
    p Gtk.current_event
  end
  
  def button_press_event()
    #pm @window.gl_area
    @window.gl_area.refresh()
    p "hej"
    p Gtk.current_event.x
  end
  
  def button_release_event()
    #pm @window.gl_area
  end
  
  def key_press_event()
    p Gtk.current_event().state # här hittas information om t ex shift används samtidigt. se 
    # http://ruby-gnome2.sourceforge.jp/hiki.cgi?Gtk
    # samt: http://www.pygtk.org/pygtk2tutorial/sec-EventHandling.html    
    true
  end

  def key_release_event() 
    pm @window.gl_area
    true    
  end
  
  def main    

    Thread.abort_on_exception = true
    @th1 = Thread.new do    
      loop {
        sleep(0.05)    
        @window.gl_area.refresh()
      }
    end  
    super
  end
  
end

# Main program
if __FILE__ == $0
  raise "not updated code"
  client = Client.new(debug=true)  
  client.main
  
end
