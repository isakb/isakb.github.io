require 'ftools' # for File.copy
require 'tempfile'
require 'yaml'

#require '../helper/pm'
require '../helper/gui_helper'
require '../helper/statistics'
#require '../model/tof_client'

require '../model/signal_watcher'

require 'model/tof_client_model'
require 'model/plotter'

#require 'rbgsl'

require 'view/measure_dialog_egils.noglade.rb'

#require 'client_xy'

# -0xDEAD is used as a magic ignore number below...

class ClientAppEventHandler

  AUTOSAVE_INTERVAL = 60
  TDC_MEASUREMENT_INFO_INTERVAL = 1
  TDC_EVENT_BUFSIZE = 0xffff

  def initialize(widgets, client_options=nil)
    @model = TofClientModel.new(client_options)
    @widgets = widgets
    @mainWindow = @widgets["mainWindow"]

    @server_lock = Mutex.new

    # This must be done before we refresh the GUI:
    @socket = {}
    @socket[:energy] = Gtk::Socket.new
    @widgets["vpEnergy"].add(@socket[:energy])
    @socket[:tof] = Gtk::Socket.new
    @widgets["vpToF"].add(@socket[:tof])
    @socket.each {|key, s| s.show; s.realize }
    @plotter = Plotter.new(@model, @socket)

    @magicPlotter = BasicPlotter.new(@model)

    @mapPlotter = DensityPlotter.new(@model)


    # was a host or port passed in argv when starting program, then don't load them from config:
    has_server_uri = (client_options[:host].nil? and client_options[:port].nil?) ? false : true
    load_config_from_file(:skip_server_uri => has_server_uri) # will refresh GUI

    @status = @widgets["statusbar1"]

    @widgets["notebook1"].signal_connect(:switch_page) { |nb, page, page_num|
      @model.cfg[:GUI][:spectrum] = nil
      case page_num
        when 0 then @model.cfg[:GUI][:spectrum] = :exToF
        when 1 then @model.cfg[:GUI][:spectrum] = :exEkin
        when 3 then @show_measurement_info = true
      end
      @plotter.refresh unless @model.cfg[:GUI][:spectrum].nil?
    }

    #@widgets["tbMagic"].signal_connect(:clicked) { @model.cfg[:GUI][:spectrum] = :e1e2ToF }
    #@widgets["tbMagic2"].signal_connect(:clicked) { @model.cfg[:GUI][:spectrum] = :e1e2e3ToF }
    @widgets["cboPlot"].active = 0
    ["e1 vs e2 ToF",
    "e1 vs e2 E_kin",
    "e1 vs e2 vs e3 ToF"].each {|t|
      @widgets["cboPlot"].append_text(t)
    }
    @widgets["cboPlot"].signal_connect(:changed) {|s|
      if @model.measurement_files.empty?
        inform "No specturm to plot (yet). Acquire more data or load a measurement first."
      else
        f = nil
        case s.active
          when 1
            inform "Trying to plot e1 vs e2 ToF"
            @model.cfg[:GUI][:spectrum] = :e1e2ToF
            f = @model.measurement_files[:e1e2ToF]
          when 2
            @model.cfg[:GUI][:spectrum] = :e1e2Ekin
            inform "Trying to plot e1 vs e2 Ekin"
            f = @model.measurement_files[:e1e2ToF]
          when 3
            @model.cfg[:GUI][:spectrum] = :e1e2e3ToF
            inform "Trying to plot e1 vs e2 vs e3 ToF"
            f = @model.measurement_files[:e1e2e3ToF]
        end
        if f && File.exist?(f)
          load_spectrum_from_file(f)
        else
          inform "Could not plot #{f}"
        end
      end
    }
    @widgets["btnForcePlot"].signal_connect(:clicked) {
      @widgets["cboPlot"].signal_emit(:changed)
    }

    @widgets["btnNewMeas"].signal_connect(:clicked) { on_new_measurement_clicked }

    @widgets["tbConnectToggle"].signal_connect(:toggled) { |b| toggle_connect_callback(b) }
    @widgets["tbRunToggle"].signal_connect(:toggled) { |b| toggle_run_callback(b) }

    @widgets["btnStop"].signal_connect(:clicked) { stop_measurement_callback }

    @widgets["toolbutton5"].signal_connect(:clicked) { help_callback }
    @widgets["toolbutton6"].signal_connect(:clicked) { info_callback }

#    @widgets["btnLoadSpectrum"].signal_connect(:clicked) { |b|
#      GuiHelper.dialog_file_open("Open Time-of-Flight Spectrum File", ["*.tofspc", "*.e?c.txt"],
#          @mainWindow, "Please choose a valid time-of-flight spectrum file.", @model.cfg[:GUI][:current_folder]) { |filename|
#        @model.cfg[:GUI][:current_folder] = File.dirname(filename) # remember the location for next time dialog is opened
#        load_spectrum_from_file(filename)
#      }
#    }
#
    @widgets["btnLoadMeas"].signal_connect(:clicked) { |b|
      GuiHelper.dialog_file_open("Open Time-of-Flight File or Measurement metadata file", ["*.tofspc", "*.e?c.txt", "*.par"],
          @mainWindow, "Please choose a valid time-of-flight spectrum file of a metadata file.", @model.cfg[:GUI][:current_folder]) { |filename|
        @model.cfg[:GUI][:current_folder] = File.dirname(filename) # remember the location for next time dialog is opened
        case filename
          when /\.par$/
            load_measurement_from_file(filename)
          else
            load_spectrum_from_file(filename)
        end
      }
    }

    @widgets["tbAutoUpdateSpectrum"].signal_connect(:toggled) { |b| toggle_update_spectrum_callback(b) }

    @widgets["tbZoomOut"].signal_connect(:clicked) {
      @plotter.zoomout
    }
    @widgets["btnRefresh"].signal_connect(:clicked) {
      unless @model.daq_running?
        puts "not running daq"
        # load spectrum from file?
        begin
          case @model.cfg[:GUI][:spectrum]
            when :exToF, :exEkin
              load_spectrum_from_file(@model.measurement_files[:exToF])
          end
        rescue
          inform "Could not plot any spectrum"
        end
      end
      @plotter.refresh
    }

    @widgets["spinEnergyScale"].signal_connect(:value_changed) { |s|
      if @model.daq_running?
        GuiHelper.alert(GuiHelper.quick_format("Not allowed!", "You cannot change this value while acquiring data."), @mainWindow)
      else
        @model.cfg[:GUI][:energy_scale] = s.value
      end
    }
    @widgets["t_min"].signal_connect(:value_changed) { |s| @model.cfg[:measurement][:t_min] = s.value }
    @widgets["t_max"].signal_connect(:value_changed) { |s| @model.cfg[:measurement][:t_max] = s.value }
    #For now, turn them off, since they are set in the new measuremet dialog.
    @widgets["t_min"].sensitive = false
    @widgets["t_max"].sensitive = false

    @widgets["spinRunMean"].signal_connect(:value_changed) { |s|
      @plotter.runMeanNum = s.value.to_i
      @model.cfg[:GUI][:running_mean_num_bins] = s.value.to_i
    }

    @log = Gtk::TextBuffer.new
    @widgets["textview1"].buffer = @log

    @server_details = Gtk::TextBuffer.new
    @widgets["txtServerDetails"].buffer = @server_details

    @meas_details = Gtk::TextBuffer.new
    @widgets["txtMeasDetails"].buffer = @meas_details

    Thread.abort_on_exception = true

    @auto_update_spectrum = true
    @widgets["tbAutoUpdateSpectrum"].active = @auto_update_spectrum

    @widgets["toolbar1"].n_items.times do |n|
      w = @widgets["toolbar1"].nth_item(n)
      w.tooltip_text = w.label unless w.is_a?(Gtk::ToolItem) or w.is_a?(Gtk::ToolSepItem)
    end

    @widgets["mnuHelp"].signal_connect(:activate) { help_callback }
    @widgets["mnuAbout"].signal_connect(:activate) { @widgets["dlgAbout"].visible = true }
    @widgets["dlgAbout"].signal_connect(:response) { @widgets["dlgAbout"].visible = false }

    @widgets["mnuConfigNew"].signal_connect(:activate) { @model.config_filename = nil }

    @widgets["mnuConfigOpen"].signal_connect(:activate) {
      GuiHelper.dialog_file_open("Open Config File", "*.tofdaq.yml",
          @mainWindow, "Please choose a valid config file") { |filename|
        puts "Loading config from file: #{filename}"
        @model.config_filename = filename
        load_config_from_file(:file => @model.config_filename)
      }
    }
    @widgets["mnuConfigSaveAs"].signal_connect(:activate) {
      GuiHelper.dialog_file_save("Save Config File As...", "*.tofdaq.yml", @mainWindow) { |filename|
        @model.config_filename = filename
        @widgets["mnuConfigSave"].signal_emit(:activate)
      }
    }
    @widgets["mnuConfigSave"].signal_connect(:activate) {
      # has the user chosen a file name for the config file?
      @widgets["mnuConfigSaveAs"].signal_emit(:activate) unless @model.config_filename
      puts "Saving config to file: #{@model.config_filename}"
      save_config_to_file(@model.config_filename)
    }

    @widgets["mnuTextBelowIcons"].signal_connect(:toggled) { |e|
      @model.cfg[:GUI][:tbTextBelowIcons] = e.active?
      refresh_GUI
    }
    @widgets["mnuLargeIcons"].signal_connect(:toggled) { |e|
      @model.cfg[:GUI][:tbLargeIcons] = e.active?
      refresh_GUI
    }
    @widgets["mnuDockGnuplot"].signal_connect(:toggled) { |e|
      @model.cfg[:GUI][:dock_gnuplot] = e.active?
      refresh_GUI
    }

    # incorporate Egil's measurement settings into the New Measurement dialog:
    @egilsDlg = MeasureDialog.new(@model.cfg[:measurement])
    @widgets["measDlgNotebook"].prepend_page(@egilsDlg.content, Gtk::Label.new("_General settings", true))
    @widgets["measDlgNotebook"].show_all
    @widgets["measDlgNotebook"].page = 0

    DaqMetaData::LENGTH_CONSTANTS.each {|k,val| @widgets["cboMeasLengthConstant1"].append_text(val.to_s) }
    @widgets["cboMeasLengthConstant1"].active = 0
#    @trig_combo.active = 0 # make sure one trig_type is choosen
    #meas.length_constant = @widgets["cboMeasLengthConstant1"].active_text
    @widgets["btnMeasLoadDefaults"].signal_connect(:clicked) {
      @model.cfg[:measurement] = DaqMetaData.new
      init_meas_dialog_from_config()
    }

    # Make sure that the GUI reflects the model's values:

    SignalWatcher.new(@plotter, [:runMeanNum_value_changed]) { |val|
      @widgets["spinRunMean"].value = val
    }
    #@plotter.runMeanNum = 0

    SignalWatcher.new(@model, [:daq_state_changed]) { |state|
      #p "daq change: " << running.to_s
      on_daq_state_change(state)
    }
    @model.daq_state = :unknown # this will init the GUI, because of the callback

    SignalWatcher.new(@model, [:connection_state_changed]) { |connected|
      #p "conn change"TRIGGER_MODES.each {|mode| @trig_combo.append_text(mode) }
#    @trig_combo.active = 0 # make sure one trig_type is choosen
      on_connection_state_change(connected)
    }
    @model.is_connected = false

    @is_measurement_prepared = false
    # TODO: make is_meas... an observable instead!
  end

  def load_config_from_file(options = {})
    options[:file] ||= "config.tofdaq.yml"
    options[:skip_server_uri] = false if options[:skip_server_uri].nil?
    begin
      conf = open(options[:file]) {|f| YAML.load(f) }
      #conf[:measurement] = DaqMetaData.yaml_initialize(conf[:measurement])
      conf.each {|k,v| @model.cfg[k] = v}
    rescue => e
      puts "Error loading config file: #{options[:file]}"
      p e
    end
    if options[:skip_server_uri]
      @model.cfg[:server][:uri] = @model.client.server_uri
    else
      @model.client.server_uri = @model.cfg[:server][:uri]
    end
    init_GUI_from_config
  end

  def refresh_GUI
    begin
      @widgets["toolbar1"].icon_size = if @model.cfg[:GUI][:tbLargeIcons]
        Gtk::IconSize::LARGE_TOOLBAR
      else
        Gtk::IconSize::MENU
      end
      @widgets["toolbar1"].toolbar_style = if @model.cfg[:GUI][:tbTextBelowIcons]
        Gtk::Toolbar::Style::BOTH
      else
        Gtk::Toolbar::Style::ICONS
      end
      @widgets["spinEnergyScale"].value = @model.cfg[:GUI][:energy_scale].to_f
      @widgets["t_min"].value = @model.cfg[:measurement][:t_min].to_f
      @widgets["t_max"].value = @model.cfg[:measurement][:t_max].to_f

      @widgets["txtServer"].text = @model.client.server_uri
      @widgets["tbConnectToggle"].active = @model.client.connected?
    rescue TypeError => e
      p e
      # The structure of the config file has changed...
      @model.cfg = TofClientModel::Config.new
    end
  end

  def init_GUI_from_config()
    begin
      @model.cfg[:GUI][:widgets].each { |widget, v|
        v = v.to_a[0]
        prop, val = v[0].to_s, v[1]
        @widgets[widget.to_s].set_property(prop, val)
      }
      @widgets["mnuTextBelowIcons"].active = @model.cfg[:GUI][:tbTextBelowIcons]
      @widgets["mnuLargeIcons"].active = @model.cfg[:GUI][:tbLargeIcons]
      @widgets["mnuDockGnuplot"].active = @model.cfg[:GUI][:dock_gnuplot]
      @widgets["spinRunMean"].value = @model.cfg[:GUI][:running_mean_num_bins].to_f
      @plotter.runMeanNum = @model.cfg[:GUI][:running_mean_num_bins].to_f
      @plotter.prepare
      refresh_GUI()
      @plotter.zoomout
    rescue => e
      raise
    end
  end

  def save_config_to_file(file="config.tofdaq.yml")
    @model.cfg[:server][:uri] = @model.client.server_uri
    begin
      open(file, 'w') {|f| YAML.dump(@model.cfg, f)}
    rescue => e
      puts "Error saving config file: #{file}"
      p e
      raise e
    end
  end

  def on_connection_state_change(is_connected)
    btn = @widgets["tbConnectToggle"]
    btn.active = is_connected
    if is_connected
      btn.label = "Disconnect"
      btn.tooltip_text = btn.label
      btn.stock_id = "gtk-disconnect"
      @widgets["btnNewMeas"].sensitive = true
      @widgets["tbRunToggle"].sensitive = true if @is_measurement_prepared
      @widgets["btnStop"].sensitive = true if @is_measurement_prepared
      @widgets["tbAutoUpdateSpectrum"].sensitive = true
    else
      btn.label = "Connect..."
      btn.tooltip_text = btn.label
      btn.stock_id = "gtk-connect"
      @model.daq_state = :unknown
      @widgets["btnNewMeas"].sensitive = false
      @widgets["tbRunToggle"].sensitive = false
      @widgets["btnStop"].sensitive = false
      @widgets["tbAutoUpdateSpectrum"].sensitive = false
    end

  end

  def on_daq_state_change(daq_state)
    #p "on_daq_state_change called. value is " << daq_state.to_s
    btn = @widgets["tbRunToggle"]
    btn.active = @model.daq_running?
    if btn.active?
      btn.label = "Pause"
      btn.stock_id = "gtk-media-pause"
    else
      btn.label = "Run"
      btn.stock_id = "gtk-media-play"
    end
    case @model.daq_state
    when :running
      @widgets["btnNewMeas"].sensitive = false
      @widgets["btnStop"].sensitive = true
      acquire_data()
    when :paused
      #nothing
      @model.autosave_data()

    when :stopped, :ended
      @is_measurement_prepared = false # will not allow continuation of the same measurement.
      @widgets["btnNewMeas"].sensitive = true
      @widgets["btnStop"].sensitive = false
      btn.sensitive = false
      @model.autosave_data()
    end
    btn.tooltip_text = btn.label
    inform "DAQ state: " << daq_state.to_s
  end

  def on_quit
    if @model.daq_running?
      @model.daq_state = :ended
    end

    puts "Saving settings to config file..."
    save_config_to_file

    @server_lock.synchronize {
      puts "Disconnecting properly from server..." if @model.client.disconnect
    }

    puts "Terminating threads..."
    @model.threads.each { |key, th| th.kill }

    puts "Exiting application."
  end

  def inform(text, log_it=true)
    self.log(text) if log_it
    text = text.to_s.dump[1..-2]
    @status.push(@status.get_context_id("info"), text)
  end

  def log(text, dump=true)
    text = text.to_s
    text = text.dump[1..-2] if dump
    @log.insert(@log.end_iter, "[%s]\t%s\n" % [Time.now.strftime("%Y-%m-%d %H:%M:%S"), text])
    @widgets["textview1"].scroll_to_iter(@log.end_iter, 0.4, true, 0, 0)
    #$stdout.puts(text)
  end

  def help_callback
    url = File.expand_path( File.dirname(__FILE__) + "/../help") + "/help.xml"
    url = "file://" + url
    Thread.new {
      #TODO: better help window
      system("gnome-help " << url)
    }

    str = nil

    self.log("
    MOUSE AND KEYBOARD SHORTCUTS IN GNUPLOT:

 2x<B1>             print coordinates to clipboard using `clipboardformat`
                    (see keys '3', '4')
 <B2>               annotate the graph using `mouseformat` (see keys '1', '2')
                    or draw labels if `set mouse labels is on`
 <Ctrl-B2>          remove label close to pointer if `set mouse labels` is on
 <B3>               mark zoom region (only for 2d-plots and maps).
 <B1-Motion>        change view (rotation). Use <ctrl> to rotate the axes only.
 <B2-Motion>        change view (scaling). Use <ctrl> to scale the axes only.
 <Shift-B2-Motion>  vertical motion -- change xyplane

 Space          raise gnuplot console window
 q            * close this X11 plot window

 a              `builtin-autoscale` (set autoscale keepfix; replot)
 b              `builtin-toggle-border`
 e              `builtin-replot`
 g              `builtin-toggle-grid`
 h              `builtin-help`
 l              `builtin-toggle-log` y logscale for plots, z and cb logscale for splots
 L              `builtin-nearest-log` toggle logscale of axis nearest cursor
 m              `builtin-toggle-mouse`
 r              `builtin-toggle-ruler`
 1              `builtin-decrement-mousemode`
 2              `builtin-increment-mousemode`
 3              `builtin-decrement-clipboardmode`
 4              `builtin-increment-clipboardmode`
 5              `builtin-toggle-polardistance`
 6              `builtin-toggle-verbose`
 7              `builtin-toggle-ratio`
 n              `builtin-zoom-next` go to next zoom in the zoom stack
 p              `builtin-zoom-previous` go to previous zoom in the zoom stack
 u              `builtin-unzoom`
 Right          `builtin-rotate-right` only for splots; <shift> increases amount
 Up             `builtin-rotate-up` only for splots; <shift> increases amount
 Left           `builtin-rotate-left` only for splots; <shift> increases amount
 Down           `builtin-rotate-down` only for splots; <shift> increases amount
 Escape         `builtin-cancel-zoom` cancel zoom region

              * indicates this key is active from all plot windows
    ", false)
    if ask_server {|s| str = s.help("*") }
      @widgets["notebook1"].page = 2
      self.log("Help on client-server communication protocol: \n\n" << str, false)
      self.inform("Help on commands added to Log tab.", false)
    end
  end

  def info_callback
    #TODO: better info window
    str = nil
    if ask_server {|s| str = s.status }
      @widgets["notebook1"].page = 2
      self.log("Server info: \n\n" << str, false)
      self.inform(str, false)
    end
    ask_server do |server|
      server.get_by_cmd(:tdc_info) { |buf|
        #p buf
        @server_details.text = buf
      }
    end
  end

#  # temporary function.
#  # @TODO: Make a better one in a suitable class...
#  def time_to_energy(t, evenly_spaced_bins=false)
#    energy = (@model.cfg[:measurement][:length_constant]**2 / (t**2))
#    #    return (1000*energy).round() / 1000.0 if evenly_spaced_bins
#
#    if energy > 8
#      log "Ignoring high energy: #{energy}"
#      return -0xDEAD # any negative value would suffice... no negative energy will exist...
#    end
#    return (@model.cfg[:GUI][:energy_scale]*energy).round() if evenly_spaced_bins
#    return energy
#  end


  def load_measurement_from_file(file)
    #Only allow this when not gathering data already...
    #on_end_daq
    @model.daq_state = :stopped
    unless file =~ /\.par$/
      inform "Incorrect spectrum file"
      return
    end
    inform "Loading measurement from file: #{file}"
    @model.cfg[:measurement] =  open(file) {|f| YAML.load(f) }
    @meas_details.text = @model.measurement_details()
    @model.load_measurement_from_file(file)
  end

  def load_spectrum_from_file(file)
    unless file =~ /\.(tofspc|e[0-9]c\.txt)$/
      inform "Incorrect spectrum file"
      return
    end
    inform "Loading spectrum from file: #{file}"

    case file
      when /\.tofspc$/
        #Only allow this when not gathering data already...
        #on_end_daq
        @model.daq_state = :stopped

        @model.load_hist_ex_from_file(file)
        @plotter.set_spectrum_type(:exToF)
        @plotter.refresh
      when /\.e2c/
#        @model.load_hist_ex_from_file(file)
#        @plotter.set_spectrum_type(:e1e2ToF)
#        @magicPlotter.update
        case @model.cfg[:GUI][:spectrum]
          when :e1e2ToF
            plot_2d_map(file)
          when :e1e2Ekin
            plot_2d_map(file, :e1e2Ekin)
         end
      when /\.e3c/
        @model.load_hist_ex_from_file(file)
        @plotter.set_spectrum_type(:e1e2e3ToF)
        @magicPlotter.refresh
      else
        puts "No implemented handler for spectrum file: #{file}"
    end

#    case @model.load_hist_ex_from_file(file)
#      when :exToF
#        @plotter.set_spectrum_type(:exToF)
#        @plotter.update
#      when :e1e2ToF
#        @plotter.set_spectrum_type(:e1e2ToF)
#        @magicPlotter.update
#        plot_2d_map(file)
#      when :e1e2e3ToF
#        @plotter.set_spectrum_type(:e1e2e3ToF)
#        @magicPlotter.update
#      else
#      # no plotting
#    end
#    unless @model.cfg[:GUI][:spectrum].nil?
#      @plotter.prepare
#      @plotter.update
#    end

  end

  def plot_2d_map(file, type=nil)
    raise ArgumentError, "No such file: #{file}" unless file && File.exist?(file)

    case type
      when nil, :e1e2ToF
        bins = 400 # TODO: GUI config value
        min = @model.cfg[:measurement].t_min * @model.cfg[:measurement].t_res
        max = @model.cfg[:measurement].t_max * @model.cfg[:measurement].t_res
        @mapPlotter.plot_2d_map(file, min, max, bins)
      when :e1e2Ekin

        # TODO: Mer vettiga E_min och E_max eftersom det annars lätt händer att allt intressant hamnar i ett hörn.
        bins = 400
        min = @model.time_to_energy(@model.cfg[:measurement].t_min * @model.cfg[:measurement].t_res)
        max = @model.time_to_energy(@model.cfg[:measurement].t_max * @model.cfg[:measurement].t_res)
        min, max = max, min # time_to_energy reverses them...
        max = (max-min)/4 # för att fokusera på de lägre energierna
        @mapPlotter.plot_2d_map_Ekin(file, min, max, bins)
    end
  end

  def try_server(check_connection=true)
    @server_lock.synchronize {
      if @model.client.server && (!check_connection || @model.client.server.connected?)
        yield @model.client.server
        true
      else
        inform "Not connected to server!"
        false
      end
    }
  end

  #this uses the clone connection
  def ask_server(check_connection=true)
    #@model.client_clone = @model.client
    if @model.client_clone.server && (!check_connection || @model.client_clone.server.connected?)
      yield @model.client_clone.server
      true
    else
      inform "Not connected to server!"
      false
    end
  end

  def toggle_connect_callback(btn)
    begin
      if @model.is_connected
        @server_lock.synchronize {
          @model.client.disconnect()
          @model.client_clone.disconnect()
        }
      else
        @model.client.server_uri = @widgets["txtServer"].text
        @model.client_clone.server_uri = @model.client.server_uri
        @model.client.connect
        @model.client_clone.connect
      end
    rescue SocketError => e  #invalid url
      inform e
      btn.active = false
      GuiHelper.alert(GuiHelper.quick_format("Incorrect socket address", "Are you sure you entered the URI correctly?\n\nClear the field to set default value (localhost)."), @mainWindow)
    rescue TofClient::EConnection, TofServerConnection::EOffline => e
      inform e
      btn.active = false
      GuiHelper.alert(GuiHelper.quick_format("Server not found", "Are you sure you entered the URI correctly?\n\nClear the field to set default value (localhost)."), @mainWindow)
    end
    if @model.client.connected?
      inform "Connected"
      @model.is_connected = true
      #on_connect
    else
      inform "Disconnected"
      @model.is_connected = false
      #on_disconnect
    end
  end

  def init_meas_dialog_from_config()
    meas = @model.cfg[:measurement]
    @egilsDlg.set_metadata(meas)
    #@widgets["measDlgNotebook"].show_all
    # TODO: vettiga values här
    tdc_channel_combos = {
      "measEleCh" => 5,
      "measEleXCh" => 0,
      "measEleYCh" => 1,
      "measIonCh" => 6
    }
    tdc_channel_combos.each {|k,v|
      @widgets[k+"1"].active = v+1
    }
    @widgets["measName1"].text = meas.name
    @widgets["measDesc1"].buffer = Gtk::TextBuffer.new.set_text(meas.description)
    @widgets["cboMeasLengthConstant1"].active = meas.length_constant < 9000 ? 0 : 1
  end

  def on_new_measurement_clicked()
    meas = @model.cfg[:measurement]
    begin
      init_meas_dialog_from_config()
    rescue
      inform "Old config file loaded, not compatible."
    end
    dlg = @widgets["dlgNewMeas"]
    dlg.visible = true
    dlg.has_focus = true
    dlg.signal_connect(:response) { |d, resp|
      case resp
        when 0
          # cancel
        when 1
          # ok
          puts "OK"
          @egilsDlg.get_metadata.each { |k,v| meas[k] = v }
          meas.name = @widgets["measName1"].text
          meas.description = @widgets["measDesc1"].buffer.text
          meas.length_constant = @widgets["cboMeasLengthConstant1"].active_text.to_f
          meas.trigger_mode = @widgets["comMode1"].active_text
          inform "Setting up TDC server config..."
          options = {
            :t_min => (meas.t_min*2).to_i,
            :t_max => (meas.t_max*2).to_i,
            :trig_rate => meas.trigger_rate.to_i * 4,
            :com_mode => meas.trigger_mode,
            :max_hits_per_channel => 16 # todo: possibility to change?
          }

          try_server{ |s|
            s.clear
            s.configure(options)
          }

          @model.clear_measurement()


      end
      dlg.visible= false
    }
    dir = @model.setup_autosave_path()
    log "Data will be auto-saved to directory: " << dir

    @meas_details.text = @model.measurement_details()

    @is_measurement_prepared = true
    # TODO: make is_meas... an observable instead!
    @widgets["tbRunToggle"].sensitive = true
  end

#  def pause_measurement_callback()
#    try_server{ |s| s.pause }
#    @model.daq_state = :paused
#  end


  def stop_measurement_callback()
    @model.daq_state = :stopped
  end

  def toggle_run_callback(btn, init=false)
    unless @is_measurement_prepared
      GuiHelper.alert(GuiHelper.quick_format("No measurement", "Create a new measurement first!"))
      btn.active = false
      return
    end
    try_server{ |s|
      if s.running?
        s.pause
      else
        begin
          s.start
        rescue TofServerConnection::ERunningAlready => e
          inform e.to_s
          puts e.to_s
        rescue TofServerConnection::ECannotStart => e
          inform e.to_s
          puts e.to_s
        end
      end
      #p "HM"
      @model.daq_state = s.running? ? :running : :paused
    }
  end

  def toggle_update_spectrum_callback(btn)
    @auto_update_spectrum = btn.active?
    @plotter.update() if btn.active?
  end

  def acquire_data()
    begin
      Thread.abort_on_exception = true
      @model.threads[:daq_thread] = Thread.new {
        log "Starting data acquisition."
        @model.client.each_event(TDC_EVENT_BUFSIZE) do |event|
          p event.e_pos if event.e_pos && @debug
          @model.add_hist_data(event)
          @has_histogram = true
          break unless @model.daq_state == :running
        end
        log "No more data to acquire."
      }

      @model.threads[:auto_save_data_thread] = Thread.new {
        #@model.autosave_filename[:exToF] = "autosaved_data/ToF_spectrum_data_%s.tofspc" % timestamp
        begin
          while @model.daq_state == :running
            sleep(0.2) until @has_histogram
            @model.autosave_data()
            log "Files have been autosaved. Will save again in #{AUTOSAVE_INTERVAL} seconds."
            sleep(AUTOSAVE_INTERVAL)
          end
        rescue
          raise
        end
        # save data once again after DAQ is ended.
        sleep(0.2) until @has_histogram
        @model.autosave_data()
      }

      @model.threads[:tdc_info_thread] = Thread.new {
        while @model.daq_running?
          sleep(TDC_MEASUREMENT_INFO_INTERVAL)
          ask_server { |server|
            server.get_by_cmd(:tdc_info) { |buf|
              @server_details.text = buf
            }
          }
        end
      }

      # Start auto plotter thread
      @model.threads[:auto_update_spectrum_thread] = Thread.new {
        while @model.daq_running?
          sleep(0.5) until @auto_update_spectrum
          while not @has_histogram && @model.daq_running? && @auto_update_spectrum
            #log("Waiting for histogram to update...")
            sleep(2)
          end
          break unless @model.daq_running? || !@auto_update_spectrum
          @plotter.update()
          sleeptime = @widgets["spinSpecUpdateInterval"].value # TODO: model it and have it observable
          sleep(sleeptime)
        end
      }



    rescue TofServerConnection::EOffline
      inform "Server went offline..."
    end
  end


end
