#!/usr/bin/env ruby

# A minimalistic client for use in testing the server.

require 'net/telnet'
require 'base64'

$: << File.expand_path( File.dirname(__FILE__) + "/../")
require 'model/tdc_event'
require 'helper/statistics'
require 'model/tof_client'

class ClientMini
  include TofClient
  
  def r(num=nil)
    @server.get_raw_by_cmd(  TofProtocol.cmd(:read_events),
                                          TofProtocol.event_types(:any),
                                          num,
                                          "events")
  end  
end
      
if __FILE__ == $0  
  host, port = TofClient.get_host_port_from_argv
  client = ClientMini.new(:debug => true, :host => host, :port => port)
  p  client.server.stop
  puts  client.server.help
  p  client.server.stop
  p  client.server.stop
  p  client.server.start
  p  client.server.stop
  p  client.server.start



 
statusmsg = client.server.status
status = statusmsg.split[0]
case status
  when "SERVER_STOPPED", "SERVER_ENDED"      
    puts "data gathering is not running. starting it."
    client.server.start
end
client.r 10

client.r 
    



# these two are the same:
puts client.server.help()
puts client.cmd(TofProtocol.cmd(:help))

puts client.cmd(TofProtocol.cmd(:help), "READ")
puts client.cmd(TofProtocol.cmd(:help), ["READ"])
puts client.cmd(TofProtocol.cmd(:help), "READ")


t = []
t << client.test_speed(10)

t << client.test_speed(10) do |i|
  puts i, client.server.status
end

t << client.test_speed(10) { client.r(10) }

client.server.stop
t << client.test_speed(10) { client.server.start(); client.server.stop() }

puts "Above tests resulted in the following times (ms)"
puts "       max       min        mean      std_dev   "
t.each do |i|
  puts " %10.03f %10.03f %10.03f %10.03f" % i
end



client.quit    

end
