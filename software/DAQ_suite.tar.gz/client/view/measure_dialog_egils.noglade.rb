# This file is based on Egil's file measure_dialog.noglade.rb
# but modified by Isak.

require 'gtk2'
require File.expand_path( File.join( __FILE__,"..",
         "..","..","model","spectra", "metadatastruct"))

class MeasureDialog
  TRIGGER_RATES = [0.1, 40_000] #min max
#  LAMP_PERIOD = [10,100_000] #min max
#  MIN_RUNTIME = 2 #s
#  MAX_RUNTIME = 350000 #s
  TRIGGER_MODES = ["He-lamp","Synchrotron"]
  MIN_TIMES = [0,0x7fff ]
  MAX_TIMES = [0,0x7fff ]
  DELTA_TIMES = [0,0x7fff ]
  HV = [0.0, 10000.0]
  E0 = [-500.000,500.000]
  T0 =[-0x7fff,0x7fff]

  def content() @vbox end

  def set_metadata(metadata)
    @metadata = metadata
    update_values()
  end

  def get_metadata()
    metadata = @metadata
#    metadata.trigger_type =  @trig_combo.active_text
#    metadata.lightsource_period = @ring_p.text.to_i
    metadata.trigger_rate = @trigger_rate.value
    metadata.trigger_period = (1e9/metadata.trigger_rate.to_f).to_i
    #metadata.total_runtime = run_mode
    metadata.t_min = @sp_tm.value
    metadata.t_max = @sp_tM.value
    metadata.t_diff_min = @sp_dt.value
    metadata.excitation_energy = @sp_hv.value
    metadata.sample_name = @i_entries[0].text
    #metadata.run_no = @i_entries[1].text.to_i
    metadata.run_no = @i_entries[1].value
    metadata.energy_offset = @cal_sp[0].value
    metadata.t_offset = @cal_sp[1].value
    metadata
  end

  def update_values()
    @default_times = [@metadata.t_min, @metadata.t_max, @metadata.t_diff_min, @metadata.excitation_energy]
    @trigger_rate.value = @metadata.trigger_rate #default value
    @tt_sp.each_with_index { |v,i| v.value = @default_times[i].to_f}
    @i_entries[0].set_text(@metadata.sample_name)
    #@i_entries[1].set_text(@metadata.run_no.to_s)
    @i_entries[1].set_value(@metadata.run_no)
    @cal_sp[0].value = @metadata.energy_offset
    @cal_sp[1].value = @metadata.t_offset
    @vbox.realize
  end

  def initialize(metadata=nil)
    @metadata = metadata || DaqMetaData.new
    #DEFAULT_TIMES = [50,10000,50,40.81] # tm, tM, dt, hv
    @default_times = [@metadata.t_min, @metadata.t_max, @metadata.t_diff_min, @metadata.excitation_energy]


    #set up dialog
    vbox = Gtk::VBox.new
    settings_box = Gtk::VBox.new
    calibration_box = Gtk::VBox.new
    info_box = Gtk::VBox.new
    vbox.add(settings_box)
    vbox.add(calibration_box)
    vbox.add(info_box)

    # + + + + + + + + Settings box  + + + + + + + + + + + + + + + + + + +
    settings_frame = Gtk::Frame.new("Measurement settings")
    settings_box.add settings_frame
    settings_align = Gtk::Alignment.new(0.5, 0.5, 1.0, 1.0)
    settings_frame.add settings_align
    settings_vbox = Gtk::VBox.new
    settings_align.add settings_vbox
    #fill settings box
    trig_table = Gtk::Table.new 2,2,true
    align3 = Gtk::Alignment.new(0.5, 0.5, 1.0, 1.0)
    run_mode_table = Gtk::Table.new 2,2,true
    align1 = Gtk::Alignment.new(0.5, 0.5, 1.0, 1.0)
    time_table = Gtk::Table.new 4,2,true

    settings_vbox.add trig_table
    settings_vbox.add align3
    settings_vbox.add run_mode_table
    settings_vbox.add align1
    settings_vbox.add time_table


    # - - - - - - - - - ---trig table- - - - - - - - - - - - - - - -
    #
    #  Trigger scheme | combobox v|
    #  Lamp period    | spinner
    #


#    #trigger scheme
#    align5 = Gtk::Alignment.new(0.5, 0.5, 1.0, 1.0)
#    lbl1=Gtk::Label.new("Trigger scheme  ")
#    lbl1.xalign = 1 # right justify
#
#    @trig_combo = Gtk::ComboBox.new(true)
#    TRIGGER_MODES.each {|mode| @trig_combo.append_text(mode) }
#    @trig_combo.active = 0 # make sure one trig_type is choosen
#
#    align5.add lbl1




    #lamp pulse frequency
    align_p_r = Gtk::Alignment.new(0.5, 0.5, 1.0, 1.0)
    lbl_p_r=Gtk::Label.new("Trigger pulse rate   ")
    lbl_p_r.xalign = 1 # right justify
    lbl_p_r_unit=Gtk::Label.new("Hz")
    p_r_hbox = Gtk::HBox.new
    @trigger_rate = Gtk::SpinButton.new(TRIGGER_RATES[0], TRIGGER_RATES[1], 1)
    @trigger_rate.value = @metadata.trigger_rate #default value

    p_r_hbox.add @trigger_rate
    p_r_hbox.add lbl_p_r_unit
    align_p_r.add lbl_p_r

#    #lamp period
#    align_l_p = Gtk::Alignment.new(0.5, 0.5, 1.0, 1.0)
#    lbl_l_p=Gtk::Label.new("Lamp period (if short)")
#    lbl_l_p_unit=Gtk::Label.new("ns")
#    l_p_hbox = Gtk::HBox.new
#    @ring_p = Gtk::SpinButton.new(LAMP_PERIOD[0], LAMP_PERIOD[1], 1)
#    @ring_p.value = @metadata.lightsource_period #default value
#
#    l_p_hbox.add @ring_p
#    l_p_hbox.add lbl_l_p_unit
#    align_l_p.add lbl_l_p

    #pull it together
#    trig_table.attach_defaults(align5,0,1,0,1)
#    trig_table.attach_defaults(align_l_p,0,1,1,2)
    trig_table.attach_defaults(align_p_r,0,1,1,2)

#    trig_table.attach_defaults(@trig_combo,1,2,0,1)
#    trig_table.attach_defaults(l_p_hbox,1,2,1,2)
    trig_table.attach_defaults(p_r_hbox,1,2,1,2)



    # - - - - - - - - - ----- separator --- - - - - - - - - - - - - - - -
    sep1 = Gtk::HSeparator.new
    align3.add sep1


#    # - - - - - - - - - ----- run_mode_table - - - - - - - - - - - - - - -
#    #  Run mode    | 0 Manual stop
#    #            | 0 Run for |Spinner| s
#    #
#    lbl9=Gtk::Label.new("Run mode  ")
#    lbl9.xalign = 1 # right justify
#    run_m_hbox = Gtk::HBox.new
#    align9 = Gtk::Alignment.new(1, 0.5, 1.0, 1.0)
#    align10 = Gtk::Alignment.new(1, 0.5, 1.0, 1.0)
#    @run_m_manual_stop = Gtk::RadioButton.new("Manual stop")
#    @run_mode_fixed_time = Gtk::RadioButton.new( @run_m_manual_stop, "Run for")
#    run_m_hbox2 = Gtk::HBox.new
#    @run_time_spinner = Gtk::SpinButton.new(MIN_RUNTIME,MAX_RUNTIME,1)
#    lbl_s=Gtk::Label.new("s")
#
#    run_mode_table.attach_defaults(lbl9,0,1,0,1)
#    run_mode_table.attach_defaults(run_m_hbox,1,2,0,1)
#    run_mode_table.attach_defaults(run_m_hbox2,1,2,1,2)
#
#    run_m_hbox.add align9
#
#    align9.add @run_m_manual_stop
#    align10.add @run_mode_fixed_time
#
#    run_m_hbox2.add align10
#    run_m_hbox2.add @run_time_spinner
#    run_m_hbox2.add lbl_s
#
#    # - - - - - - - - - ----- separator --- - - - - - - - - - - - - - - -
#    sep2 = Gtk::HSeparator.new
#    align1.add sep2


    #  - - - - - - - - - - -time table - - - - - - - - - - - - - - - - - -
    # Min time    | spinner ns
    # Max time    | spinner ns
    # ∆t        | spinner ns
    # hv        | spinner ns

    #labels
    lbl_tm=Gtk::Label.new.set_markup("t<sub>min</sub>   ").set_tooltip_markup("Minimum flight-time").set_has_tooltip(true)
    lbl_tM=Gtk::Label.new.set_markup("t<sub>max</sub>   ").set_tooltip_markup("Maximum flight-time").set_has_tooltip(true)
    lbl_dt=Gtk::Label.new.set_markup("∆t   ").set_tooltip_markup("Minimum photon difference").set_has_tooltip(true)
    lbl_hv=Gtk::Label.new.set_markup("hν   ").set_tooltip_markup("Photon energy").set_has_tooltip(true)

    lbl_ns0=Gtk::Label.new("ns")
    lbl_ns1=Gtk::Label.new("ns")
    lbl_ns2=Gtk::Label.new("ns")
    lbl_ns3=Gtk::Label.new("eV")

    #spinners
    @sp_tm = Gtk::SpinButton.new( MIN_TIMES[0], MIN_TIMES[1] , 0.5).set_tooltip_markup("Minimum time").set_has_tooltip(true)
    @sp_tM = Gtk::SpinButton.new( MAX_TIMES[0], MAX_TIMES[1] , 0.5).set_tooltip_markup("Maximum time").set_has_tooltip(true)
    @sp_dt = Gtk::SpinButton.new( DELTA_TIMES[0], DELTA_TIMES[1] ,0.5).set_tooltip_markup("Minimum photon difference").set_has_tooltip(true)
    @sp_hv = Gtk::SpinButton.new( HV[0], HV[1], 0.001).set_tooltip_markup("Photon energy").set_has_tooltip(true)
    @sp_hv.digits = 3 # set precision

    #aligns
    a_tm = Gtk::Alignment.new(1, 0.5, 1.0, 1.0)
    a_tM = Gtk::Alignment.new(1, 0.5, 1.0, 1.0)
    a_dt = Gtk::Alignment.new(1, 0.5, 1.0, 1.0)
    a_hv = Gtk::Alignment.new(1, 0.5, 1.0, 1.0)

    #hboxes
    hb_tm = Gtk::HBox.new
    hb_tM = Gtk::HBox.new
    hb_dt = Gtk::HBox.new
    hb_hv = Gtk::HBox.new

    #make arrays
    tt_hb= [hb_tm, hb_tM ,hb_dt , hb_hv]
    tt_a= [a_tm, a_tM ,a_dt , a_hv]
    @tt_sp= [@sp_tm, @sp_tM ,@sp_dt , @sp_hv]
    tt_ns_lbl= [lbl_ns0, lbl_ns1 ,lbl_ns2 , lbl_ns3]
    tt_lbl= [lbl_tm, lbl_tM ,lbl_dt , lbl_hv]

    #right justify
    tt_lbl.each{|i| i.xalign= 1}

    #pull it together
    tt_hb.each_index do |i|
      @tt_sp[i].value= @default_times[i] #set default value
      tt_a[i].add @tt_sp[i] #spinners into aligns
      tt_hb[i].add tt_a[i] #vboxes into vboxes
      tt_hb[i].add tt_ns_lbl[i] # ns into vboxes
    end

    time_table.attach_defaults(lbl_tm,0,1,0,1)
    time_table.attach_defaults(lbl_tM,0,1,1,2)
    time_table.attach_defaults(lbl_dt,0,1,2,3)
    time_table.attach_defaults(lbl_hv,0,1,3,4)

    time_table.attach_defaults(hb_tm,1,2,0,1)
    time_table.attach_defaults(hb_tM,1,2,1,2)
    time_table.attach_defaults(hb_dt,1,2,2,3)
    time_table.attach_defaults(hb_hv,1,2,3,4)

    ## - - - - - - - - - ----- separator --- - - - - - - - - - - - - - - -
    #sep1 = Gtk::HSeparator.new
    #align3.add sep1


    #  + + + + + + + + + + + calibration_box  + + + + + + + + + + + + + + +

    cal_frame = Gtk::Frame.new("Measurement settings")
    calibration_box.add cal_frame
    cal_align = Gtk::Alignment.new(0.5, 0.5, 1.0, 1.0)
    cal_frame.add cal_align
    cal_vbox = Gtk::VBox.new
    cal_align.add cal_vbox

    cal_table = Gtk::Table.new 2,2,true
    cal_vbox.add cal_table

    # e0    | spinner eV
    # t0    | spinner ns

    #labels
    cal_lbl= [
      Gtk::Label.new.set_markup("E<sub>0</sub>  ").set_tooltip_markup("Energy offset").set_has_tooltip(true),
      Gtk::Label.new.set_markup("t<sub>0</sub>  ").set_tooltip_markup("Flight-time offset").set_has_tooltip(true)
     ]
    cal_lbl_units = [ Gtk::Label.new("eV"), Gtk::Label.new("ns") ]

    cal_lbl.each{|i| i.xalign= 1}

    #spinners
    @cal_sp = [
      Gtk::SpinButton.new( E0[0], E0[1], 0.001).set_tooltip_markup("Energy offset").set_has_tooltip(true),
      Gtk::SpinButton.new( T0[0], T0[1], 0.5).set_tooltip_markup("Flight-time offset").set_has_tooltip(true)
    ]

    @cal_sp[0].value = @metadata.energy_offset
    @cal_sp[1].value = @metadata.t_offset

    #aligns
    cal_a = [ Gtk::Alignment.new(0.5, 0.5, 1.0, 1.0),
    Gtk::Alignment.new(0.5, 0.5, 1.0, 1.0)]

    cal_hb = [ Gtk::HBox.new,  Gtk::HBox.new ]

    #pull it together
    cal_hb.each_index do |i|
      cal_a[i].add @cal_sp[i] #spinners into aligns
      cal_hb[i].add cal_a[i] #vboxes into vboxes
      cal_hb[i].add cal_lbl_units [i] # ns into vboxes
    end

    cal_table.attach_defaults(cal_lbl[0],0,1,0,1)
    cal_table.attach_defaults(cal_lbl[1],0,1,1,2)

    cal_table.attach_defaults(cal_hb[0],1,2,0,1)
    cal_table.attach_defaults(cal_hb[1],1,2,1,2)

    #  + + + + + + + + + + + info_box  + + + + + + + + + + + + + + +

    i_frame = Gtk::Frame.new("Spectrum info")
    info_box.add i_frame
    i_align = Gtk::Alignment.new(0.5, 0.5, 1.0, 1.0)
    i_frame.add i_align
    i_vbox = Gtk::VBox.new
    i_align.add i_vbox

    i_table = Gtk::Table.new 2,2,true
    i_vbox.add i_table

    # Sample name  | ___________
    # Run number   | ___________

    #labels
    i_lbl= [ Gtk::Label.new("Sample name  "), Gtk::Label.new("Run number  ") ]

    #right justify
    i_lbl.each{|i| i.xalign= 1}

    #spinners
    @i_entries = [
      Gtk::Entry.new.set_text(@metadata.sample_name),
      #Gtk::Entry.new.set_text(@metadata.run_no.to_s)
      Gtk::SpinButton.new( -1, 1000000, 1).set_value(-1)
    ]
    #aligns
    i_a = [ Gtk::Alignment.new(1, 0.5, 1.0, 1.0),
    Gtk::Alignment.new(1, 0.5, 1.0, 1.0)]
    #pull it together
    i_a.each_index do |i|
      i_a[i].add @i_entries[i] #entries into aligns
    end
    i_table.attach_defaults(i_lbl[0],0,1,0,1)
    i_table.attach_defaults(i_lbl[1],0,1,1,2)

    i_table.attach_defaults(i_a[0],1,2,0,1)
    i_table.attach_defaults(i_a[1],1,2,1,2)
    # - + - + - + - + - + - + - + - + - + - + - + - + - + - + - + - + - +

    @vbox = vbox
  end

end
