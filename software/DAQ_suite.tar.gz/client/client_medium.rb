#!/usr/bin/env ruby

require '../model/tof_client'

class ClientMedium
  include TofClient 
  attr_reader :semaphore
  
  def read_raw(num=nil)
    return @server.get_raw_by_cmd("READ", "DOUBLES", num, "events") do |buf|      
      while buf[0] do
        nhits = buf[0]
        event = TDCEvent.new(buf[0..nhits*5+1])
        yield event
        buf = buf[nhits*5+1..-1]
      end
    end
  end
  
  def each_event(num=1, &block)
    while running?
      read_raw(num) do |e|
        yield e
      end
    end
  end
  
  def running?() @server.state == :running end
end
      
if __FILE__ == $0
  
  host, port = TofClient.get_host_port_from_argv

  client = ClientMedium.new(:debug => true, :host => host, :port => port)
  events = []
  Thread.abort_on_exception = true
  
  thr1 = Thread.new do
    statusmsg = client.server.status
    status = statusmsg.split[0]
    case status
      when "SERVER_STOPPED", "SERVER_ENDED"      
        puts "data gathering is not running. starting it."
        client.server.start
    end
    sleep(5)
    client.server.stop
    p events
  end
  
  
  thr2 = Thread.new do
    begin
      timeout(1) { until client.running? do end }
      client.each_event(10) do |event|
        events << event
        
      end    
      client.quit
    rescue Timeout::Error
      puts "Waited too long for server to start."
      exit
    end
  end
  thr1.join
  thr2.join  
  
end
