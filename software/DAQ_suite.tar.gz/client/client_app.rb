#!/usr/bin/env ruby
#
# This file is gererated by ruby-glade-create-template 1.1.4.
#
require 'libglade2'

require 'controller/client_app.events.rb'

class ClientAppGlade
  include GetText

  attr :glade
  
  def initialize(path_or_data, root = nil, domain = nil, localedir = nil, flag = GladeXML::FILE)
    bindtextdomain(domain, localedir, nil, "UTF-8")
    @glade = GladeXML.new(path_or_data, root, domain, localedir, flag) {|handler| method(handler)}
  end
  def eventHandler=(h)
    @eventHandler = h
  end
  
  def main()
    Gtk.main()  ## Enter into Gtk's main event processing loop.
    true
  end
  
  def gtk_main_quit()
    @eventHandler.on_quit
    Gtk.main_quit()    
  end
  
end

# Main program
if __FILE__ == $0
  # Set values as your own application. 
  PROG_PATH = "view/client_app.glade"
  PROG_NAME = "YOUR_APPLICATION_NAME"
  
  host, port = TofClient.get_host_port_from_argv(true)

  $DEBUG = true
  $DEBUG_COMM = false  


  app = ClientAppGlade.new(PROG_PATH, nil, PROG_NAME, nil, GladeXML::FILE)
  $APPLICATION = app
  
  class GLib::Object
    alias :signal_connect_without_exception_handling :signal_connect  
    def signal_connect(signal_name)
      signal_connect_without_exception_handling(signal_name) { |*args|
        begin
          yield *args
        rescue Exception => e
          # tell the user that their command failed...
          puts "Exception happened without any handler!"
          puts "Terminating application properly first."
          begin
            $APPLICATION.gtk_main_quit()
          rescue
            puts "Could not terminate application properly. Something went wrong in gtk_main_quit."
          end
          puts "Raising original exception again..."
          raise
        end
      }
    end
  end  
  app.eventHandler = ClientAppEventHandler.new(app.glade, {:host => host, :port => port, :debug => $DEBUG, :debug_comm=> $DEBUG_COMM})
  app.main()
end
