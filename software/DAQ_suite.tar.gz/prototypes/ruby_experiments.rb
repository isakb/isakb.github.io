#!/usr/bin/env ruby

#some experiments to test various ways of using Ruby more efficiently

module RubyExperiments
  
  class StopWatch
    @@id = 0
    def initialize(name="Stopwatch")
      @@id += 1
      @name = name
      @t0 = nil
      @duration = 0
    end
    def running?() not @t0.nil? end
    def start()
      raise "Started already" if running?
      @t0 = Time.now
    end
    def stop()
      @duration = Time.now - @t0 if running?
      @t0 = nil
    end
    def to_s() "  StopWatch#%02d:  %-40s  %.03f ms." % [@@id, @name, @duration*1000] end
    def to_f() @duration end
    def name() @name end
  end
  
  def speedtest(name="Speedtest", repeat=1000, &block)
    t = StopWatch.new name
    t.start
    repeat.times {
      yield
    }
    t.stop
    t 
  end

  def timeoutExperiment()
    require 'timeout'
    puts "Testing different ways to use Timeout."
    t1, t2 = [], []
    10.times {    
      t1 << speedtest("The first way of doing it") {
        ack = nil
        begin
          Timeout::timeout(1) { ack = "hej"; dummy = "hello"} # the return value of the block is hello
          if ack == "hej"
            ack = "ok"
          end
        rescue Timeout::Error
          puts "Timeout error"
        end
        raise "Wrong ack: #{ack}" unless ack == "ok"
      }
      puts t1.last
      t2 << speedtest("The second, compact, way of doing it") {
        begin
          ack = Timeout::timeout(1) { dummy = "hello"; ack = "hej"} # the return value of the block is ack
          if ack == "hej"
            ack = "ok"
          end
        rescue Timeout::Error
          puts "Timeout error"
        end
        raise "Wrong ack: #{ack}" unless ack == "ok"
      }
      puts t2.last
    }
    puts "Total:"
    puts "  %s: %.3f s" % [t1.first.name, t1.inject(0) {|sum,t| sum += t.to_f}]
    puts "  %s: %.3f s" % [t2.first.name, t2.inject(0) {|sum,t| sum += t.to_f}]
    
    # The conclusion seems to be that the first way is a little bit faster, but the difference is not really noticeable.
  end
  
  def tempfileExperiment
    f = File.new("/dev/shm/tempfileExperiment-#{Time.now.strftime("%Y-%m-%d-%H-%M-%S")}.dat", "w+")
    
    f << "0123456789"
    f.flush


    puts IO.read(f.path, num=15, offset=0)
    
    puts IO.read(f.path, num=15, offset=5)
    
    puts IO.read(f.path, num=15, offset=11)
    
    f.close
    File.unlink f.path
    

  end
  
  def datarepresentationExperiment
    # Converts the datafiles from the 5 byte per hit repr. to the 3 byte per hit one.
    ["data.dat", "recorded_data_20080208_ch1-x2_ch2-y2_ch6-be.dat", "data_20080229_01.dat"].each do |fname|    
      f = File.open("../data/#{fname}", "r")
      str = ""
      begin
        loop {
          num_hits = f.readchar
          unless num_hits
            puts "num_hits isn't"
            break
          end
          str << num_hits
          num_hits.times do |hit|
            ch = f.readchar  
            dly = f.read(4).unpack("I4").first.to_i
            if dly & 0xffff != dly
              puts "%d är för stort!"
            end          
            str << [ch, dly].pack("CS") # S = unsigned short, 2 bytes     
          end
        }
      rescue EOFError => e
        puts "No more data to read from TDC device: %s" % e
      end    
      f.close
      p File.size(f.path)
      p str.length
      
      new = fname.gsub("\.dat", "_new.dat")
      File.open("../data/#{new}", "w") do |f2|
        f2 << str
      end      
    end
    
  end
end


if $0 == __FILE__
  include RubyExperiments
  
  #timeoutExperiment 
  #datarepresentationExperiment
  tempfileExperiment
  
end