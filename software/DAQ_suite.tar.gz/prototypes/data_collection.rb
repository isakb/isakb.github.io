#!/usr/bin/ruby

require '../model/tdc'
require '../helper/tdc_module_help'  
require '../helper/statistics'

DataFile = "../data/measurement_#{Time.now.to_i}.raw"
system("touch " + DataFile)

ShowOutput = false

class Array
  include Statistics
end

duration, num_com_events, num_hits = 0, 0, 0
begin
  tdc = TdcCard.new DataFile
rescue TdcCard::ENoDevice => e
  puts "No TDC device found - #{e}"    
  print "Get help on how to load module? (y/N): "
  ans = $stdin.gets.chop
  if ans.downcase == 'y'
    tdc_load_file = File.expand_path( File.dirname(__FILE__) + "/tdc_load")    
    tdc_module_helper(tdc_load_file) if tdc_module_create_loader(tdc_load_file)
  end
  exit
rescue
  raise
end
tdc.debug = true

#tdc.max_delay = 32000  

run = true

Thread.abort_on_exception = true
th1 = Thread.new do    
  puts "Saving data to file: #{DataFile}"
  puts "Starting data gathering... will run until you stop it by pressing enter."
  tdc.start
  while true
    r,w,e = IO.select([$stdin],nil,nil,0)
    sleep(1)
    break unless r.nil? 
  end
  tdc.stop
  puts "Ended gathering."
end

th2 = Thread.new do
  # save data to file continuously with low-level system call
  system("cat /dev/tdc > #{DataFile}")
end
 

# make sure that th1 always executes completely
# even if main thread is finished first.
th1.join
th2.join

