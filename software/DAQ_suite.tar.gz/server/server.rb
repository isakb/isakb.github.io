#!/usr/bin/env ruby

# Server for the Time-of-flight magnetic bottle spectrometer.
# To talk to the server you need to connect to it
# (i.e. with a Telnet client ) on the proper port
# (default 10001).

require 'gserver'
#require 'timeout'
#require 'base64'
#require 'tempfile'

$: << File.expand_path( File.dirname(__FILE__) + "/../")
require 'model/tdc'
require 'model/protocol'
require 'server/model/event.rb'
require 'server/model/measurement.rb'
require 'server/model/session.rb'



class Server < GServer

  attr_reader :measurement

  attr_accessor :show_output, :tdc

  class ECmdFailed < RuntimeError; end
  class EClientDisconnect < RuntimeError; end


  def initialize(tdc, *args)
    raise ArgumentError, "First argument must be of class TdcCard. Got: #{tdc.inspect}." unless tdc.kind_of?(TdcCard)
    @tdc = tdc
    @raise_exceptions = true
    @gather_thread_lock = Mutex.new
    super(*args)
    TofProtocol.validate_server(self)
    reset
  end

  def serve(io)
    #TODO: Spara measurement till fil eller databas istället för att ha allt i ramminnet.
    begin
      # if a client connects when no other clients are connected, it should be the master client.
      client = Session.new(io)
      client.server = self

      inform("New connection: %s in %s mode." % [client, client.master? ? "master" : "restricted"], true)
      #inform "Number of current connections: %d" % connections

      client << TofProtocol.client_connect_message()

      while line = client.gets

        line.chomp!
        inform "received: #{line} (from #{client.addr})"

        # If we get a command followed by some parameter(s), extract them:
        # If client sends: "command param1 param2 ... paramN"
        # Then:
        # => command = "command"; params = ["param1", "param2", "...", "paramN"]
        params = line.split(" ")
        command = params.shift

        # check if protocol defines this command
        cmd = TofProtocol.cmd(command)
        if cmd
          begin
            inform(cmd.to_s + " " + params.join(" "))

            #if the client is not master, don't allow restricted commands
            unless client.master? or not cmd.restricted?
              inform "restricted command and client is not master"
              client << TofProtocol.cmd_restricted(command)
            else
              #acknowledge client's command
              client << TofProtocol.cmd_ok(command)
              #send_ack?(io, command + " ACCEPTED")
            end

            if self.send(cmd.handler, client, *params) == :disconnect
              break
            end
          rescue => e
            inform "Error with command: %s ... Error: %s" % [command, e]
            raise e if @debug
            sleep(1)
          end
        else
          inform "Unknown instruction: #{command}, params: [#{params.join(", ")}]"
          sleep(1)
          client << TofProtocol.cmd_err(command)
          #say io, "IMPOSSIBLE"
        end
      end


      # if the last client disconnects without an error, reset server.
      if Session.connections == 1 # if this was the last client...
        inform("Resetting server", true)
        self.reset()
        #TODO: Gör ett CLEAR commando så att en master client kan
        #rensa all data i @measurement vid behov, istället för detta:
      end

    rescue Errno::ECONNRESET => e
      inform "Connection to client was reset: " << e
    rescue Errno::EPIPE => e
      inform "Client died abruptly. " << e
    end

    inform("Closing connection to client: #{client}", true)
    #inform "%d connections remaining" % (connections - 1)

    client.destroy

  end


  # for debug, since super suppresses messages
  def error(detail)
    super
    raise detail if @debug && @raise_exceptions
  end

  def reset()
    @tdc.stop
    if @measurement
      @measurement.save_data()
      inform "Clearing measurement data..."
      @measurement.reset()
      #@measurement.stop_analysis()
      #@measurement.clear()
      #@measurement = nil
      #sleep(0.1)
      #GC.start
      #sleep(0.1)
    else
      @measurement = Measurement.new(:db_path => "../data/measurements/beta/measurement_#{Time.now.to_i}_.db",
                                      :type => :raw_buf, #:event_buf, #:raw_file
                                      :analyse => false)
    end
    #@measurement = Measurement.new("../data/measurements/beta/measurement_#{Time.now.to_i}_.db")
  end

  # puts text to console window
  def inform(text, always_show=false)
    return unless @show_output or always_show

    #first replace \ with \\ since we use \ as escaping character below
    text.gsub!(/\\/, "\\\\")

    #escape non-printable characters, to prettify output and make it safer
    #characters are escaped as \xhh where hh is the hexadecimal representation
    #of the raw byte
    text.gsub!(/([^[:print:]])/)  {|s| '\\x' + s[0].to_s(base=16)}

    #TODO: Maybe write text to log file in addition to displaying it?

    #text = text.dump[1..-2] #dump encloses string within "", but I dont want ""

    #Show the output in the console window
    $stdout.print(" ", text, "\n>>")
    $stdout.flush
  end

  def cmd_status(client, *params)
    client.send_cmd_data?(:status,
      "SERVER_#{@tdc.status}") # << " MEASUREMENT_STATUS #{@measurement}")
  end

  def cmd_quit(client, *params)
    return :disconnect
  end

  def cmd_start(client, *params)
    cmd = TofProtocol.cmd(:start)
    if @tdc.running?
      data = cmd.responses[:already_started] #TofProtocol.tdc_already_started()
      inform "Already running, not starting."
    else
      num_com_signals = 0
      begin
        num_com_signals = Integer(params[0]) if params[0]
      rescue ArgumentError => e
        inform "Invalid number received to cmd_start: " + e.to_s
        inform "Params were: %s" % params.join(" ")
      end
      self.start_tdc()
      if @tdc.running?
        data = cmd.responses[:success] #TofProtocol.tdc_started()
        inform "OK"
      else
        p "not"
        data = cmd.responses[:failure] #TofProtocol.tdc_start_failure()
        inform "Error starting TDC card."
      end
    end
    client.send_cmd_data?(:start, data)
  end

  def cmd_configure(client, *params)
    cmd = TofProtocol.cmd(:configure)
    # Setup trigger_rate_hz, t_min, t_max, num_channels, etc...
    t_min, t_max, trig_rate, com_mode, hits_per_ch = -1, -1, -1, TdcCard::TDCMode::COMMON_START, -1
    begin
      t_min = Integer(params[0]) if params[0]
      t_max = Integer(params[1]) if params[1]
      trig_rate = Integer(params[2]) if params[2]
      com_mode = params[3] if params[3] #TODO: Protocol string
      hits_per_ch = Integer(params[4]) if params[4]
    rescue ArgumentError => e
      inform "Invalid number received to cmd_setup: " + e.to_s
      inform "Params were: %s" % params.join(" ")
    end
    options = {}
    # TODO: Constant for the values in class TDC ?
    options[:t_min] = t_min if 0 <= t_min && t_min < 0xffff
    options[:t_max] = t_max if t_min < t_max && t_max <= 0xffff
    options[:trig_rate] = trig_rate if 1 < trig_rate && trig_rate < 100000
    options[:com_mode] = TdcCard::TDCMode::COMMON_STOP if com_mode == "COMMON_STOP" #TODO: Protocol string
    options[:max_hits_per_channel] = hits_per_ch if 0 <= hits_per_ch && hit_per_ch <= 16
    if @tdc.configure(options)
      data = cmd.responses[:success] #TofProtocol.tdc_configured()
      inform "OK"
    else
      data = cmd.responses[:failure] #TofProtocol.tdc_configure_failure()
      inform "Failed"
    end
    client.send_cmd_data?(:configure, data)
  end

  def cmd_help(client, *params)
    client.send_cmd_data?(:help, TofProtocol.help((params[0] if params[0])))
  end

  def cmd_tdc_info(client, *params)
    details = "No details available"
    begin
      f = File.open("/proc/tdc_measurement", "r")
      details = f.read
    rescue => e
      inform e.to_s
    ensure
      f.close if f
    end
    client.send_cmd_data?(:help, details)
  end

#  # send raw events as buffer
#  def cmd_read_events(client, *params)
#    raise "Deprecated! Use cmd_read_buf instead."
#    events = case params[0]
#      when TofProtocol.buffer_types(:singles); []
#      when TofProtocol.buffer_types(:doubles); @measurement.doubles
#      when TofProtocol.buffer_types(:triples); @measurement.triples
#      when TofProtocol.buffer_types(:quads); @measurement.quads
#      when TofProtocol.buffer_types(:any); raise "Call instead: cmd_read_buf"
#      else raise "Wrong eventtype: %s" << params[0]
#    end
#    offset, num = 0, nil
#    begin
#      offset = Integer(params[1]) if params[1]
#      num ||= Integer(params[2]) if params[2]
#    rescue ArgumentError => e
#      inform "Invalid number received to cmd_read: " + e
#      inform "Params were: %s" % params.join(" ")
#    end
#    offsetend = num ? offset + num : -1
#    data = events.slice(offset..offsetend)
#    inform "will send %s bytes as buffer" % data.size.to_s
#    unless client.send_cmd_data?(:read_events, data)
#      inform "error in transmission"
#    end
#  end

  # send raw bytes from selected buffer buf
  def cmd_read_buf(client, *params)
    offset, num = 0, nil
    begin
      offset = Integer(params[1]) if params[1]
      num ||= Integer(params[2]) if params[2]
    rescue ArgumentError => e
      inform "Invalid number received to cmd_read_stream: " + e
      inform "Params were: %s" % params.join(" ")
    end
    offsetend = num ? offset - 1 + num : -1

    data = case params[0]
      when TofProtocol.buffer_types(:tof_histogram); @measurement.tof_histogram.slice(offset..offsetend)
      when TofProtocol.buffer_types(:delays);
        #force buffer size modulo 2, since each delay is represented by 2 bytes binary
        buf = @measurement.delays.slice(offset..offsetend)
        if buf && buf.length.modulo(2) != 0
          buf = buf[0..-2] # skip last byte
        end
        buf
      when TofProtocol.buffer_types(:raw_buf), nil; @measurement.raw_event_buf.slice(offset..offsetend)
      else raise "Wrong eventtype: %s" % params[0].to_s
    end

    data = "" if data.nil?

#    d = data.nil? ? nil : data[0..-1]
#
#    sem = Mutex.new
#    while data.length > 0
#      unless sem.synchronize{data.length > TDCHit::NUM_BYTES}
#        p "fifo buf has too little data, size: #{data.length}"
#        raise "No more data available from server."
#      end
#      str = sem.synchronize{
#        nhits = data[0]
#        next if nhits.nil?
#        next if data.length <= nhits * TDCHit::NUM_BYTES
#        str = data.slice!(0..nhits * TDCHit::NUM_BYTES)
#      }
#      p str
#      next if str.nil?
#      p str
#      p TDCEvent.new(str)
#    end
#
#
#
#    data = d


    #data = Base64.encode64(data)


    #File.open("/dev/shm/debug1.txt", "a") do |f| f.puts data.dump end

    inform "cmd_read_buf - will send %d bytes of data as buffer, starting at offset: %d " % [data.length, offset]
    unless client.send_cmd_data?(:read_buf, data)
      inform "error in transmission"
    end


#
#    sem = Mutex.new
#    while data.length > 0
##      unless sem.synchronize{data.length > TDCHit::NUM_BYTES}
##        p "fifo buf has too little data, size: #{data.length}"
##        raise "No more data available from server."
##      end
#      str = sem.synchronize{
#        nhits = data[0]
#        next if data.length <= nhits * TDCHit::NUM_BYTES
#        str = data.slice!(0..nhits * TDCHit::NUM_BYTES)
#      }
#      next if str.nil?
#      p str
#      p TDCEvent.new(str)
#    end

  end


  def cmd_test(client, *params)
    #does nothing
  end

  def cmd_clear(client, *params)
    @tdc.clear
    inform "clear"
    #client.send_cmd_data?(:clear, TofProtocol.tdc_cleared())
    client.send_cmd_data?(:clear, TofProtocol.cmd(:clear).responses[:success])
    # reset ?
  end

  def cmd_pause(client, *params)
    @tdc.pause
    inform "pause"
    client.send_cmd_data?(:pause, TofProtocol.cmd(:pause).responses[:success]) # TofProtocol.tdc_paused())
  end

  def cmd_stop(client, *params)
    @tdc.stop
    inform "stop"
    client.send_cmd_data?(:stop, TofProtocol.cmd(:stop).responses[:success]) # TofProtocol.tdc_stopped())
#    #"reset indices for testing purposes (So the testunit knows what to expect)"
#    @singles_index = 0
#    @doubles_index = 0
#    @measurement_fulhack = @measurement if @measurement
#    @measurement=nil
  end

  def start_tdc(num_com_signals=0)
    inform "Starting tdc card measurement. Com limit = %d" % num_com_signals
    @tdc.start(num_com_signals)
    inform "tdc card started."
    Thread.abort_on_exception = true
    Thread.new do
      inform "Starting data gathering thread..."

      # if you want the server to analyse the events
      # and sort them to singles, doubles, triples, etc...
      # this can be done by client instead to save server CPU
      #@measurement.prepare()
      @measurement.start_analysis() # returns a new thread

      tries = 0
      @gather_thread_lock.synchronize {
        begin
          @tdc.each_event_raw { |num_hits, buffer|

            next if num_hits == 0

            raw_data = "%c%s" % [num_hits, buffer]
            unless @measurement.append_data(raw_data)
              raise EClientDisconnect, "Last client disconnected while data gathering running."
            end
            break unless @tdc.running?
          }

         # @tdc.read_raw_data { |buffer|
         #   unless @measurement.append_data(buffer)
         #     raise EClientDisconnect, "Last client disconnected while data gathering running."
         #   end
         #   break unless @tdc.running?
         # }




#          @tdc.each_event { |event|
#            @measurement.append_data(event)
#          }

        rescue TdcCard::ENoComSignal => e
          inform "No COM signal detected: " + e
          unless tries > 10
            tries += 1
            retry
          end
          @tdc.stop
        rescue TdcCard::ETimeout => e
          inform "TimeOut while trying to read from device: " + e
          raise e
        rescue TdcCard::ENotRunning => e
          unless tries > 10
            tries += 1
            @tdc.start
            retry
          end
          inform  "TDC Card is not running: " + e
        rescue TdcCard::EBusy => e
          unless tries > 10
            tries += 1
            @tdc.start
            retry
          end
          inform "TDC Card is busy: " + e
        rescue EClientDisconnect => e
          # if the last client disconnects while we are gathering data, what to do?
          inform e.to_s
          inform "Stopping gathering."
          @tdc.stop
        rescue => e
          inform e.to_s
          p e
          raise e
        end
      }
      inform " Done with gathering!"
    end

#    @info_thread = Thread.new do
#      loop {
#        t0 = Time.now
#        nhits = tdc.num_hits
#        ntrigs = tdc.num_com_events
#        sleep(2.5)
#        break unless tdc.running?
#        @measurement.hitrate = (tdc.num_hits - nhits) / (Time.now - t0)
#        @measurement.eventrate = (tdc.num_com_events - ntrigs) / (Time.now - t0)
#        if @debug
#          inform ""
#          inform "    Countrate: %d hits/s, %d trigs/s." % [@measurement.hitrate, @measurement.eventrate]
#          inform "        total: %d hits, %d trigs." % [tdc.num_hits, tdc.num_com_events]
#          inform ""
#        end
#      }
#    end

  end

end

if __FILE__ == $0

  #default values:
  port =  10001
  host =  "127.0.0.1"
  data_file = nil

  $DEBUG = false

  puts "\n\tFor more options, try: ruby #{__FILE__} -help\n\n" if ARGV.empty?
  #check arguments
  ARGV.length.times do |i|
    case ARGV[i]
      when  /help/
        puts
        puts "   usage: ruby #{__FILE__} [-host 127.0.0.1] [-port 10001] [-simulated]"
        puts
        puts "      if '-host' is omitted, server will run locally, \n" <<
             "          and not be accessible via network.\n" <<
             "      if '-host auto' is passed, then ip address of host \n" <<
             "          will be set automatically if possible.\n" <<
             "      if '-simulated' is passed, server will simulate \n" <<
             "          the TDC card in software."
        puts
        exit

      when /host/
        if ARGV[i+1]
          host = ARGV[i+1]
          if host == "auto"
            puts "  -host auto given; reading eth0 inet addr..."
            begin
              host = IO.popen("ip -f inet -o addr show dev eth0 primary").readlines.first[/inet (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\/\d{1,3}/, 1]
            rescue
              puts "Unable to get hos automatically. For more info: run 'ruby #{__FILE__} -help'"
              exit
            end
          end
          puts "  -host #{host}"
        end

      when /port/
        if ARGV[i+1] and ARGV[i+1].to_i != 0
          port = ARGV[i+1].to_i
          puts "  -port #{port}"
        end

      when /debug/
        $DEBUG = true

      when /simulated/
        #data_file = "../data/data_20080229_01.dat.gz"
        data_file = "../data/recorded_data_20080328_ch5-be.dat.gz"
        #data_file = "../data/data_laser_2008-04-04_start_at_13_25_stop_at_14_15.dat.gz"
        #data_file = "../data/data.dat"
        puts "  -simulated ; using data file: #{data_file}"
    # If you don't want to gather data from tdc card for testing purposes,
    # you can save data from tdc card to a file, like: cat /dev/tdc > "data.dat"
    # and then use the data from this file
    # Connected cables:
    # CH1 is X2, CH2 is Y2, CH6 is BE, COM is the lamp pulse


      when /profile/
        require 'rubygems'
        require '/usr/lib/ruby/gems/1.8/gems/ruby-prof-0.6.0/lib/ruby-prof.rb'
        PROFILE = true
    end
  end

  RubyProf.start if defined? PROFILE

  server = nil # all threads below need access to this variable
  threads = []
  Thread.abort_on_exception = true
  threads << Thread.new do
    begin
      # (port, host, maxConnections, stdlog = $stderr, audit = false, debug = false)
      puts "Starting server on host: %s, port: %d..." % [host, port]
      server = Server.new(TdcCard.new(data_file),
        port, host)
      server.debug = $DEBUG         # turn off to improve response time
      server.show_output = $DEBUG   # turn off to improve response time
      server.audit = $DEBUG         # Turn logging off to improve response time
      server.start
      server.join                 # This seems to be important in Windows, but can be skipped in Linux/Mac.
    rescue Errno::EADDRNOTAVAIL => e
      puts "Gserver cannot run on %s:%s. %s" % [server.host, server.port, e]
    rescue TdcCard::ENoComSignal => e
      puts "No COM signal detected!!!"
    rescue TdcCard::ETimeout
      puts "TimeOut, TDC Card has been silent for 2 seconds. Not started?"
    rescue TdcCard::ENotRunning
      unless tries > 5
        tries += 1
        sleep(0.1)
        retry
      end
      puts "TDC Card is not running."
    rescue TdcCard::EBusy
      unless tries > 5
        tries += 1
        sleep(0.1)
        retry
      end
      puts "TDC Card is busy!"
    end
  end

  threads << Thread.new do
    sleep(0.01)  # give thr1 time to start server
    #break if server.stopped?
    puts ">> " << TofProtocol.welcome_message()
    puts ">> " << TofProtocol.version_info()
    puts ">> Server running on #{server.host}:#{server.port}."
    puts ">>   Commands in console:"
    puts ">>   quit,exit    shutdown server"
    puts ">>   p            print measurement data"
    puts ">>   sim          transform console into a simulated telnet session with server"
    puts ">>                WARNING! Only intended for debugging etc."
    print ">>"; $stdout.flush
    while str=$stdin.gets
      str = str.to_s.chomp
      if str =~ /exit|quit/
        server.debug = false # this is because server.stop stops the server via an exception...
        server.stop
        break
      elsif str == "p"
        puts server.measurement
        puts "TDC Module measurement info:"
        begin
          File.open("/proc/tdc_measurement") { |f|
            puts f.readlines()
          }
        rescue
          puts "No info found"
        end
      elsif str == "sim"
        server.serve( File.new("/dev/tty", "r+") )
      end
      print ">>"; $stdout.flush
    end
    puts "Server ended."
  end

  threads.each { |th|
    th.join
  }


  if defined? PROFILE
    result = RubyProf.stop

    printer = RubyProf::GraphHtmlPrinter.new(result)
    printer.print(STDOUT, :min_percent=>0)

#    printer = RubyProf::FlatPrinter.new(result)
#    printer.print(STDOUT, 0)

  end

end
