class EventList < Array
  attr_accessor :sent_index #points to the last event that was sent to client
  
  def initialize
    super
    @sent_index = 0
    @sent_index_backup = 0
  end
  
  # returns num number of entries as array from self, and updates @sent_index
  def get_next(num=nil)
    start = @sent_index
    @sent_index_backup = start    
    remaining = self.length - start
    num = num ? [num, remaining].min : remaining
    @sent_index += num
    # remove items that can safely be removed now
    #self.slice!(0..start-1)
    #self.compact!
    #return next items
    self.slice(start, num).to_a
  end
  
  def rollback
    @sent_index = @sent_index_backup
  end
end
