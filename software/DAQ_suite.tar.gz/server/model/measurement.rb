class Measurement
  
  @@id = 0
  TEMP_DIR = "/dev/shm" # /dev/shm = automounted RAMdisk in Debian and Ubuntu.
  #attr_accessor :raw_events, :events, :singles, :doubles, :num_events, :num_events_skipped
  attr_reader :doubles, :triples, :electron_xy_positions, :num_events, :delays
  attr_accessor :eventrate, :hitrate
  def initialize(options = {:type => nil,
                            :db_path => nil,
                            :file => nil,
                            :analyse => nil} )
    options[:type] ||= :raw_buf
    @lock = Mutex.new
#    @raw_data_file = File.new("#{TEMP_DIR}/Tof-server-raw-data-#{Time.now.strftime("%Y-%m-%d-%H-%M-%S")}.dat", "w+")
    @options = options
    @db = nil # path to a sqlite db where we will store measurement data    
    unless (db_path = options[:db_path]).nil?
      raise "File #{db_path} exists!" if File.exist?(db_path)
      #@db = SQLite::Database.new(db_path, 0644 )
    end    
    case @options[:type]
      when :raw_file
        @append_to_file = true
        alias append_data append_raw_event_to_file
      when :raw_buf
        alias append_data append_raw_event_to_buf
      when :event_buf
        alias append_data append_event
      else
        raise "Wrong type"
    end    
    reset()
  end
  
  def reset()
    case @options[:type]
      when :raw_file
        begin
          @raw_data_file.close
          File.unlink(@raw_data_file.path)
        rescue
        end        
        @raw_data_file = File.new("#{TEMP_DIR}/Tof-server-raw-data-#{Time.now.strftime("%Y-%m-%d-%H-%M-%S")}.dat", "w+")
      when :raw_buf
        @raw_event_buf = ""
      when :event_buf
        @events = [] #EventList.new()
      else
        raise "Wrong type"
    end
    if @options[:analyse]
      @delays = ""
      @tof_histogram = Hash.new(0) 
      @electron_xy_positions = []
      @singles = []
      @doubles = []
      @triples = []
      @multis = []
      @num_hits_of_type = Hash.new(0)
      @num_events = 0
    end
    @eventrate, @hitrate = 0, 0
    @@id += 1 # indicate that a new measurement is started
    self.stop_analysis()
    @events = [] #EventList.new()   
  end  
  
  def save_data()
    return true
    # TODO: do something with saved arrays and histograms...
  end
  
  def tof_histogram()
    @tof_histogram.sort.inject("") do |str,v|
      str += "%d\t%d\n" % [v[0], v[1]]
    end      
  end
  
#  # from GETSPEC5.BAS: time to energy
#  def self.fneV(ns)
#    ns = 200 if ns < 200
#    (3390 / (ns + t0)) ** 2 - e0 # 3390 mm? = the flight tube length?
#  end
  
  def analyser_thread()
    
    return unless @options[:analyse]
    
    func = case @options[:type]
      when :raw_file; :_get_event_from_raw_file
      when :raw_buf; :_get_event_from_raw_buf
      when :event_buf; :_get_event_from_events
      else raise "Wrong type"
    end
    
    Thread.new {
      while @analysis_running  
      
        event = self.send(func)
        next if event.nil?
        break unless @analysis_running        

        num_hits = event.classify()
        @num_hits_of_type[num_hits] += 1
        if num_hits > 0
          @num_events += 1
        else
          next
        end
        
        # save the electron hits to array t_val
        # and also add each hit to time histogram
        t_val = event.electrons_delays()
        t_val.each {|t| @tof_histogram[t] += 1 }
        
        @delays << t_val.pack("S"*t_val.length) # binary list of delays, for transmission
        
        case num_hits
          when 2          
            @doubles << event.electrons_delays_to_s
          when 3
            @triples << event.electrons_delays_to_s
        end
        e_pos = event.e_pos
        @electron_xy_positions << e_pos.to_s if e_pos   
        
        
        
        # Maybe the energy calculation is unnecessary
        # since Egil has written code for this already...
        # it can be calculated by the client.
#        #calculate energies?
#        # <calc comment="this calculation is adapted from GETSPEC5.BAS">
#        case num_hits
#          when 1:
#            # calculate energy for single electron hit
#            ke = facem * fnev(t_val[0]) if t_val[0] > tvmax #TODO: tvmax är förmodligen irrelevant
#            if ke > 0 and ke < Max_num_singles3000 then
#              me[ke] += 1
#              eme[ke / 6] += 1
#            end
#          when 2: 
#          when 3:
#        end
#        # </calc>

        #for garbage collection
        event = nil
      

      end
    }
  end
  
  def _get_event_from_raw_buf()
    #let data enter buffer first
    sleep(0.2) while @raw_event_buf.length <= TDCHit::NUM_BYTES && @analysis_running
    return unless @analysis_running
    
    str = nil
    @lock.synchronize {
      nhits = @raw_event_buf[0]
      next if nhits.nil?
      next if @raw_event_buf.length <= nhits * TDCHit::NUM_BYTES         
      str = @raw_event_buf.slice!(0..nhits * TDCHit::NUM_BYTES)
      next if str.nil?
    }
    TDCEvent.new(str)
  end
  
  def _get_event_from_raw_file()  
      # wait for file to fill up
    sleep(0.2) while File.size(@raw_data_file) <= TDCHit::NUM_BYTES && @analysis_running
    return unless @analysis_running
    
    str = nil
    @lock.synchronize {
      @raw_data_file.pos = 0
      nhits = @raw_data_file.read(1) # if offset is outside of file, nil will be returned
      next if nhits.nil?
      nhits = nhits.to_i
      next if File.size(@raw_data_file) <= nhits * TDCHit::NUM_BYTES         
      str = "%c%s" % [nhits, IO.read(@raw_data_file.path, 0, nhits * TDCHit::NUM_BYTES)]
      next if str.nil?
    }
    TDCEvent.new(str)
  end  
    
  def _get_event_from_events()  
        # wait for data to enter buffer
        sleep(0.2) while @events.empty? && @analysis_running
        return unless @analysis_running
        
        #event = @lock.synchronize{ @events.shift() }
        # event = @events.shift is bad in ruby 1.8 due to memleak when @events[0] just disappears without being nil
        event = @events[0]
        # due to ruby 1.8 memleak bug:
        @events[0] = nil
        @events.shift
        event
  end  
    
#  # analyses the raw data in the raw event buffer
#  def analyser_thread_buf()
#    Thread.new {
#      while @analysis_running
#        # wait for data to enter buffer
#        sleep(0.2) while @raw_event_buf.length <= TDCHit::NUM_BYTES && @analysis_running
#        break unless @analysis_running
#        str = nil
#        @lock.synchronize {
#          nhits = @raw_event_buf[0]
#          next if nhits.nil?
#          next if @raw_event_buf.length <= nhits * TDCHit::NUM_BYTES         
#          str = @raw_event_buf.slice!(0..nhits * TDCHit::NUM_BYTES)
#          next if str.nil?
#        }
#        event = TDCEvent.new(str)
#        num_hits = event.classify()
#        @num_hits_of_type[num_hits] += 1
#        if num_hits > 0
#          @num_events += 1
#        else
#          next
#        end
#        
#        # add each hit to time histogram
#        event.electrons {|hit| @tof_histogram[hit.delay] += 1 }
#        
#        case num_hits
#          when 2:
#            #@doubles << event.electron_delays
#          when 3:
#            #@triples << event.electron_delays
#        end
#        e_pos = event.e_pos
#        #@electron_xy_positions << e_pos.to_s if e_pos
#        
#        #for garbage collection
#        event = nil
#        e_pos = nil
#      end
#    }
#  end
#  
#  # analyses the raw data in the raw event buffer
#  def analyser_thread_file()
#    Thread.new {
#      while @analysis_running
#        # wait for data to enter buffer
#        sleep(0.2) while File.size(@raw_data_file) <= TDCHit::NUM_BYTES && @analysis_running
#        break unless @analysis_running
#        str = nil
#        @lock.synchronize {
#          @raw_data_file.pos = 0
#          nhits = @raw_data_file.read(1) # if offset is outside of file, nil will be returned
#          next if nhits.nil?
#          nhits = nhits.to_i
#          next if File.size(@raw_data_file) <= nhits * TDCHit::NUM_BYTES         
#          str = "%c%s" % [nhits, IO.read(@raw_data_file.path, 0, nhits * TDCHit::NUM_BYTES)]
#          next if str.nil?
#        }
#        event = TDCEvent.new(str)
#        num_hits = event.classify()
#        @num_hits_of_type[num_hits] += 1
#        if num_hits > 0
#          @num_events += 1
#        else
#          next
#        end
#        
#        # add each hit to time histogram
#        event.electrons {|hit| @tof_histogram[hit.delay] += 1 }
#        
#        case num_hits
#          when 2:
#            #@doubles << event.electron_delays
#          when 3:
#            #@triples << event.electron_delays
#        end
#        e_pos = event.e_pos
#        #@electron_xy_positions << e_pos.to_s if e_pos
#        
#        #for garbage collection
#        event = nil
#        e_pos = nil
#      end
#    }
#  end
#  
#  # analyses the events in the event buffer
#  def analyser_thread_events()
#    Thread.new {
#      while @analysis_running
#        # wait for data to enter buffer
#        sleep(0.2) while @events.empty?
#        
#        #event = @lock.synchronize{ @events.shift() }
#        # event = @events.shift is bad in ruby 1.8 due to memleak when @events[0] just disappears without being nil
#        event = @events[0]
#        # due to ruby 1.8 memleak bug:
#        @events[0] = nil
#        @events.shift
#        
#        next if event.nil? # händer mycket sällan
#        num_hits = event.classify()
#        @num_hits_of_type[num_hits] += 1
#        if num_hits > 0
#          @num_events += 1
#        else
#          next
#        end
#        
#        # add each hit to time histogram
#        event.electrons {|hit| @tof_histogram[hit.delay] += 1 }
#        
#        case num_hits
#          when 2:
#            @doubles << event.electron_delays
#          when 3:
#            @triples << event.electron_delays
#        end
#        e_pos = event.e_pos
#        @electron_xy_positions << e_pos.to_s if e_pos
#        
#        #for garbage collection
#        event = nil
#      end
#    }
#  end  

  def append_raw_event_to_file(event)
    @lock.synchronize {
      begin    
        @raw_data_file.pos = File.size(@raw_data_file)
        @raw_data_file << event
        @raw_data_file.flush
        return true
      rescue IOError
        return false
        # @raw_data_file has been closed due to clear() being called when last client disconnected
      end
    }
    true
  end
  def append_raw_event_to_buf(event)
    @lock.synchronize {
      @raw_event_buf << event
    }
    true
  end  
  def append_event(event)
    @events << event
    true
  end
  def raw_event_buf()
    @lock.synchronize {
      @raw_event_buf
    }
  end
  
  def num_bad_hits() @num_hits_of_type[0] end
  def num_singles() @num_hits_of_type[1] end
  def num_doubles() @num_hits_of_type[2] end
  def num_triples() @num_hits_of_type[3] end
  def num_others()
    sum = 0
    @num_hits_of_type.each_value {|v| sum += v}
    sum - @num_hits_of_type[3] - @num_hits_of_type[2] - @num_hits_of_type[1] - @num_hits_of_type[0]
  end
  
  
  def start_analysis()
    @analysis_running = true
    self.analyser_thread()
  end
  
  def stop_analysis()
    @analysis_running = false
  end
  

#  def append_raw_data(data)
#    @raw_data_buf << data
##    #@events << data
##    begin    
##      @raw_data_file << data
##      @raw_data_file.flush
##      return true
##    rescue IOError
##      return false
##      # @raw_data_file has been closed due to clear() being called when last client disconnected
#    end    
#  end
#  def get_raw_data(offset=nil, num=nil)
#    @raw_data_buf.slice(offset, num)
##    IO.read(@raw_data_file.path, num, offset) # if offset is outside of file, nil will be returned
#  end
  def clear()    
#    if @raw_data_file
#      # delete the raw data in the RAMdisk
#      # TODO: Save it to user specified location if needed.
#      @raw_data_file.close
#      File.unlink(@raw_data_file.path)
#    end
    self.instance_variables.each {|v| v = nil}
  end
  def bufsize()
    case @options[:type]
      when :raw_file
        File.size?(@raw_data_file) || 0
      when :raw_buf
        @raw_event_buf.size
      when :event_buf
        @events.size
      else
        raise "Wrong type"
    end
  end
  #def to_s() "Measurement ##{@@id}--- events: #{@num_events}, raw events: #{@events.length}, singles: #{@singles.length}, doubles: #{@singles.length}, skipped_events: #{@num_events_skipped}" end
  def to_s()
    ("Measurement ##{@@id}; type:#{@options[:type].to_s}; (bufsize: #{bufsize()}); eventrate: %.2f/s, hitrate: %.2f/s; " % [@eventrate, @hitrate] )<<
    if @options[:analyse]
      "valid trig events: #{@num_events}, " << @num_hits_of_type.sort.collect{|a| "#{Measurement.num_to_s(a[0])}: #{a[1]}" }.join(", ")
    else 
      ""
    end    
  end
  
  def self.num_to_s(num)
    case num
      when 0; "invalid hits"
      when 1; "singles"
      when 2; "doubles"
      when 3; "triples"
      when 4; "quads"
      else "#{num}s"
    end
  end  
  
end