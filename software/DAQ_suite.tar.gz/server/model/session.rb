#require "pp"

$: << File.expand_path( File.dirname(__FILE__) + "/../../")
require 'model/protocol'

#require 'helper/pm'

class Session
  @@server = nil
  @@connections = 0
  @io
  attr_reader :client, :remote_addr
  def initialize(io)
  	@@connections += 1
    @io = io
    @is_master = @@connections == 1
    @simulated = @io.tty? # server can run a simulated client session with a tty
  end
  def master?() @is_master end
  
  def destroy
    @@connections -= 1
  end
  def self.connections() @@connections end  
  def to_s()
    if @simulated
      "ServerAdmin simulating a client" 
    else
      begin
        @io.peeraddr.join('; ')
      rescue Errno::ENOTCONN
        "Crashed client"
      end      
    end
  end
  
  def addr() @simulated ? "$stdin" : @io.peeraddr[3] end 
  def server=(svr) @@server = svr end
    
    
  # check if data is available to read from client
  # or if cleint is ready to accept data depending on mode.
  # will only wait for TofProtocol::TIMEOUT seconds,
  # then default to return false
  def ready?(mode=:read)     
    r, w, e = IO.select([@io],[@io],[@io], TofProtocol::TIMEOUT)
    if mode == :read
      return r != nil
    end
    w != nil
  end
    

#  def send_ack?(message, client_ack = nil)
#    ack = nil
#    
#    p ready?
#    exit
#    
#    @@server.inform "Sending ack message: #{message} to client"
#    begin
#      Timeout::timeout(TofProtocol::TIMEOUT) { #TODO: gör detta med IO.select
#        say message
#        unless client_ack.nil?
#          ack = gets.to_s.chomp
#          @@server.inform "Client ack is: " << ack
#          return false unless ack == client_ack
#        end
#      }
#      return true
#    rescue Timeout::Error
#      @@server.inform "Ack failed for %s" % message
#    end
#    @@server.sleep(1)
#    @@server.inform "Wrong ack!"
#    false
#  end
  
  # Sends the data to client according to transmitprocedure
  # for command. Handles transmit failures and invalid commands.
  def send_cmd_data?(cmd, data)
    command = TofProtocol.cmd(cmd)
    if command.nil?
      @@server.inform "Command '#{cmd}' is not a command."
      return false
    end
    begin
      command.transmit_data(:server => @@server, :client => self,
        :data => data)
        return true
    rescue TofProtocol::ERROR::TransmitFailure => e
      @@server.inform "Transmit failure during command '#{cmd}': " << e
    end
    return false
  end
  
  def readline
    return @io.gets.to_s if IO.select([@io], [], [], TofProtocol::TIMEOUT)
    raise TofProtocol::ERROR::Timeout, "Client didn't say anything."
  end
  
  
  # to be called by server
  def ack?(expected, ok=nil, err=nil)
    #Wait for client ack
    begin      
#      ack = Timeout::timeout(TofProtocol::TIMEOUT) { # TODO: gör detta med IO.select
#        gets.to_s.chomp
#      }
      ack = readline.chomp
      @@server.inform "Client ack is: " << ack
      # server verifies that client parsed the number correctly
      if ack == expected
        say ok unless ok.nil?
        return true
      end         
      @@server.inform "Ack failed: Got %s, expected %s." % [ack, expected]     
    rescue TofProtocol::ERROR::Timeout => e #Timeout::Error
      @@server.inform "Got no ack. " + e.to_s
    end
    say err unless err.nil?
    false
  end
  
  def gets()
    @io.gets
  end
  def print(*args) @io.print(*args) end
  def flush() @io.flush end
  # send message to client
  def say(message)
    # add an "\r" in order to make output prettier
    # for windows users in telnet
      
    #read, write, error = IO::select(@io, @io, @io, 2) 
    #write.puts message << "\r"
    #timeout_puts(message+"\r", 1) 

    rwe = IO.select([], [@io], [], TofProtocol::TIMEOUT)
    unless rwe[1]
      raise TofProtocol::ERROR::Timeout, "Could not write to client..."
      return false
    end
    @io.puts(message << "\r")
    return true

    #@io.puts message << "\r"
  end
  alias << say
end
