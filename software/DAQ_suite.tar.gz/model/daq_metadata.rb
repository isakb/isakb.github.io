# Based on Egil's TofMetaData struct, modified by Isak

class DaqMetaData
  # length_constant is: ToF-length * sqrt(electron_mass/2)
  LENGTH_CONSTANTS = {
    :short               => 3438.0, # calibrated value of the short machine
    :long                => 9265.0, # calibrated value of the long machine
  }
  DEFAULTS = {
    #    :measurement_type    => nil, # ie :pepeco or :pepico
    :name                => "(New Measurement)",
    :sample_name         => "(unknown sample)",
    :description         => "",
    :comments            => "",
#    :trigger_type        => nil,
#    :lightsource_period  => 10000,
    :trigger_mode        => "COMMON_START",
    :trigger_period      => 10000,
    :trigger_rate        => 1000.0,
    :run_no              => -1,
    :excitation_energy   => 40.81, #eV
    :t_min               => 50,
    :t_max               => 10000,
    :t_res               => 1, # time resolution in ns    
    :t_diff_min          => 10, # minimum time difference between two electrons in ns
    :t_offset            => 0,
    :energy_offset       => 0,
    :acquisition_started => nil,
    :acquisition_ended   => nil,
    :length_constant     => LENGTH_CONSTANTS[:short]
  }
  
  attr_accessor :values
  def initialize(opts = {})
    @values = DEFAULTS.merge(opts)
    #Create getters and setters for each value
    @values.each { |k,v|
      self.class.send(:define_method, k, lambda {@values["#{k}".to_sym]})
      self.class.send(:define_method, "#{k}=", lambda {|val| @values["#{k}".to_sym]=val})
    }
  end
  def each() @values.each {|i| yield i} end
  def [](i) @values[i] end
  def []=(i,val) @values[i] = val end
#  def to_yaml(opts={}) @values.to_yaml(opts) end
end