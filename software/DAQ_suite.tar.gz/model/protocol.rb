require 'singleton'

class String
  def wordwrap(width=70, indent="")
    gsub(/\t/,"    ").gsub(/.{1,#{width}}(?:\s|\Z)/) {
      ($& + 5.chr).gsub(/\n\005/,"\n").gsub(/\005/,"\n"+indent)
    }
  end    
end

class TofProtocol
  include Singleton
  
  MajorVersion = "0.7"
  
  TIMEOUT = 20 # after how many seconds shall client/server give up when waiting for server/client response
  
  @@CommandsLookup = nil
  
  module ERROR
    class Timeout < RuntimeError; end
    class Failure < RuntimeError; end
    class InvalidCommand < Failure; end
    class TransmitFailure < Failure; end
    class NoServerResponse < Failure; end     
  end
  
  
  # strings for cmd start
  def self.tdc_already_started() "ALREADY_STARTED" end
  def self.tdc_started() "STARTED" end
  def self.tdc_start_failure() "FAILED_TO_START" end
  
  # strings for cmd stop
  def self.tdc_stopped() "STOPPED" end

  # strings for cmd pause
  def self.tdc_paused() "PAUSED" end
    
  # strings for cmd clear
  def self.tdc_cleared() "CLEARED" end
    
  # string for cmd configure  
  def self.tdc_configured() "CONFIGURED" end
  def self.tdc_configure_failure() "FAILED_TO_CONFIGURE" end
  
  
  class Command
    attr_reader :handler, :description, :details, :parameters, :transmit_procedure, :responses
    def initialize(cmd, handler_function=nil, is_restricted = false, description = "", parameters = nil, transmit_procedure = nil, responses = nil)
      @cmd = cmd
      @handler = (handler_function or "cmd_#{cmd.downcase}")
      @is_restricted = is_restricted
      @description = description
      @details = details
      @parameters = parameters
      @transmit_procedure = transmit_procedure
      @responses = responses
    end
    def to_s() @cmd end
    alias to_str to_s 
    def restricted?() @is_restricted end
    def transmit_data(options) @transmit_procedure.transmit_data(options) end
    def explain()
      str = " #{@cmd}: " << @description << "\n"      
      str << "\n    This command is only available to master clients.\n" if restricted?      
      str << "\n" + @transmit_procedure.explain(@cmd, @parameters) unless transmit_procedure.nil?
      str << "\n" + explain_responses
      str << "\n" + explain_parameters
      str
    end
    def explain_parameters()
      return "" unless @parameters
      str = "\tParameters for #{@cmd}:\n\n"
      @parameters.each_with_index {|par,i|
        str << "\t$PARAMETER_%d" % (i+1)
        str << ": " + par.explain
        str << ("\n\t$PARAMETER_%d is required" % (i+1)) if par.required?        
        str << "\n\n"
      }
      str
    end
    def explain_responses()
      return "" unless @responses
      str = "\tPossible values of $STREAM (responses):\n"
      @responses.each {|key, resp|
        str << "\t  %-20s - on #{key}.\n" % resp
      }
      str
    end
  end
  
  class Parameter
    attr_reader :description, :default_value
    def initialize(name, description="", default_value=nil)
      @name = name
      @description = description
      @default_value = default_value
    end
    def to_s() required? ? @name : "["+@name+"]" end
    def required?() @default_value.nil? end
    def explain()
      str = "%s" % to_s
      str << " (default: #{@default_value.to_s})" unless required?
      str << "\n\t\t" << @description      
      str
    end
  end
  
  class TransmitProcedure
    attr_reader :type
    TransmitTypes = {
      :line => :type_line,
      :stream => :type_stream,
      :events => :type_events
    }
    def initialize(type=:none)
      @type = type
    end
    
    # Send data from server to client, with the right procedure depending
    # on the type of command this is.
    # This function is only to be called by server.
    def transmit_data(options = {:client => nil, :data => nil})
      raise "Invalid options" unless options[:client]
      return if @type == :none
        
      data = options[:data]
      client = options[:client]
      server = options[:server]
      
      case @type
        when :line; 
          client << data
          
        when :stream; #sends a bytestream to client with ack
          if data.nil? or data.length == 0
            client << TofProtocol.tx_no_data_server()
            raise ERROR::TransmitFailure unless client.ack?(TofProtocol.tx_no_data_client())
            return
          end
          #First tell client how many bytes it can expect
          len = data.length.to_s
          server.inform "Will try to send stream of #{len} bytes"
          client << TofProtocol.tx_bytes_server(len)      
          
          #Wait for client ack
          raise ERROR::TransmitFailure unless client.ack?(TofProtocol.tx_bytes_client(len),
            TofProtocol.server_ack(), TofProtocol.server_nack())
          
          #server now sends data stream. Client should read until the right amount is received.   
          server.inform "transmitting #{len} bytes..."      
          client.print data
          #client.flush #commented on Mar 31, 2008, trying to improve speed
          
          #server waits for client to ack the amount received
          raise ERROR::TransmitFailure unless client.ack?(TofProtocol.tx_bytes_client_ack(len),
            TofProtocol.tx_server_ok(), TofProtocol.tx_server_err())

          server.inform "Successfully sent stream of #{len} bytes"
      
          
        when :events;           
          if data.nil? or data.length <= 0
            client << TofProtocol.tx_no_data_server()
            raise ERROR::TransmitFailure unless client.ack?(TofProtocol.tx_no_data_client())
            return
          end
          # tell client how many entries the object has (it might not be as many as requested by client)
          # and how many bytes will be needed to send it:
          num_entries = data.length
          data = data.join
          num_bytes = data.length
          server.inform "Will try to send #{num_entries} events, in a stream of #{num_bytes} bytes"
          client << TofProtocol.tx_events_server(num_entries, num_bytes)          
          
          #Wait for client ack
          raise ERROR::TransmitFailure unless client.ack?(TofProtocol.tx_events_client(num_entries, num_bytes),
            TofProtocol.server_ack(), TofProtocol.server_nack())      
          
          #server now sends data stream. Client should read until the right amount is received.   
          server.inform "transmitting #{len} bytes..."    
          client.print data
          client.flush          
          
          #server waits for client to ack the amount received
          raise ERROR::TransmitFailure  unless client.ack?(TofProtocol.tx_bytes_client_ack(num_bytes),
            TofProtocol.tx_server_ok(), TofProtocol.tx_server_err())
          
          server.inform "Successfully sent stream of %d bytes" % len
          
        else
          raise ERROR::TransitFailure, "Invalid type of command."          
      end
    end

    def explain(cmd = "$COMMAND", params=nil)
      str = "    Command procedure:\n\n"      
      if params
        str << "    1. Client: #{cmd} "
        str << params.join(" ") + "\n"
      else 
        str << "    1. Client: #{cmd} \n"
      end
      str << "    2. Server: #{TofProtocol.cmd_ok(cmd)}\n"      
      if TransmitTypes[@type]
        str << self.send(TransmitTypes[@type], 3)
      end  
      str << "    # Server awaits next command from client...\n"
    end
    def type_line(i=3)
      str = ""
      str << "    #{i}. Server: $STREAM\n"
      str
    end
    def type_stream(i=3)
      str = ""
      str << "    # Server tells stream size (bytes):\n"
      str << "    #{i}. Server: #{TofProtocol.tx_bytes_server("$NUM_BYTES_TO_SEND")}\n"
      str << "    # Client acknowledges:\n"
      str << "    #{i+1}. Client: #{TofProtocol.tx_bytes_client("$NUM_BYTES_TO_GET")}\n"      
      str << "    # Server verifies client response\n"
      str << "    # if $NUM_BYTES_TO_SEND equals $NUM_BYTES_TO_GET:\n"
      str << "        #{i+2}. Server: #{TofProtocol.server_ack()}\n"      
      str << "        #{i+3}. Server: $TEXT_STREAM\n"
      str << "        # Client should read data from server until\n"
      str << "        # it has received $NUM_BYTES_TO_GET bytes.\n"
      str << "        #{i+4}. Client: #{TofProtocol.tx_bytes_client_ack("$NUM_BYTES_RECEIVED")}\n"
      str << "        # Server verifies client response\n"
      str << "        # if $NUM_BYTES_TO_SEND equals $NUM_BYTES_RECEIVED:\n"
      str << "            #{i+5}. Server: #{TofProtocol.tx_server_ok()}\n"
      str << "        # else:\n"
      str << "            #{i+5}. Server: #{TofProtocol.tx_server_err()}\n"
      str << "    # else:\n"
      str << "        #{i+2}. Server: #{TofProtocol.server_nack()}\n"
      str
    end
    def type_events(i=3)
      str = "    # if {there are more events to send}:\n"
      str << "        # Server tells how many events it will send\n"
      str << "        # and the stream size for the raw data (bytes):\n"
      str << "        #{i}. Server: #{TofProtocol.tx_events_server("$NUM_EVENTS_TO_SEND", "$NUM_BYTES_TO_SEND")}\n"
      str << "        # Client acknowledges:\n"
      str << "        #{i+1}. Client: #{TofProtocol.tx_events_client("$NUM_EVENTS_TO_GET", "$NUM_BYTES_TO_GET")}\n"      
      str << "        # Server verifies client response\n"
      str << "        # if {the numbers are equal}:\n"
      str << "            #{i+2}. Server: #{TofProtocol.server_ack()}\n"      
      str << "            #{i+3}. Server: $TEXT_STREAM\n"
      str << "            # Client should read data from server until\n"
      str << "            # it has received $NUM_BYTES_TO_GET bytes.\n"
      str << "            #{i+4}. Client: #{TofProtocol.tx_bytes_client_ack("$NUM_BYTES_RECEIVED")}\n"
      str << "            # Server verifies client response\n"
      str << "            # if $NUM_BYTES_TO_SEND equals $NUM_BYTES_RECEIVED:\n"
      str << "                #{i+5}. Server: #{TofProtocol.tx_server_ok()}\n"
      str << "            # else:\n"
      str << "                #{i+5}. Server: #{TofProtocol.tx_server_err()}\n"
      str << "        # else:\n"
      str << "            #{i+2}. Server: #{TofProtocol.server_nack()}\n"
      str << "    # else:\n"
      str << "        # Server tells that no data is available\n"
      str << "        #{i}. Server: #{TofProtocol.tx_no_data_server()}\n"
      str << "        # Client acknowledges:\n"
      str << "        #{i+1}. Client: #{TofProtocol.tx_no_data_client()}\n"      
      str
    end
  end
  
  TransmitNothing = TransmitProcedure.new
  TransmitOneLine = TransmitProcedure.new :line
  TransmitRawEvents = TransmitProcedure.new :events
  TransmitByteStream = TransmitProcedure.new :stream
  
  Commands = {
    :help =>          Command.new("HELP", :cmd_help, false,
                                    "Show help. HELP $COMMAND gives help on how to use the command $COMMAND, if it is a valid command.",
                                    [Parameter.new("$COMMAND",                                                  
                                                  "If $COMMAND is a valid command, HELP $COMMAND " <<
                                                    "shows detailed help on how to use that command. " <<
                                                    "If $COMMAND is '*', help for all commands are given. " <<
                                                    "If $COMMAND is invalid, then HELP $COMMAND informs " <<
                                                    "that $COMMAND is not a command.",
                                                  "")],
                                    TransmitByteStream
                                    ),
                                    
    :quit =>          Command.new("QUIT", :cmd_quit, false, 
                                    "Terminate connection with server.",
                                    nil,
                                    TransmitNothing),
                                    
    :configure =>     Command.new("CONFIGURE", :cmd_configure, true, 
                                    "Configure settings for TDC card; time ranges, etc. ",
                                    [                                    
                                    Parameter.new("$T_MIN",
                                      "$T_MIN can be any integer between 0 and 65535 (unit: 0.5 ns). " <<
                                        "It configures the minimum valid delay for a hit. " <<
                                        "The TDC card will discard hits with shorter delay than $T_MIN.",
                                      "0 (Set by driver)"),
                                    Parameter.new("$T_MAX",
                                      "$T_MIN can be any positive integer between $T_MIN and 65535 (unit: 0.5 ns). " <<
                                        "It configures the maximum valid delay for a hit. " <<
                                        "The TDC card will discard hits with longer delay than $T_MAX.",
                                      "65535 (Set by driver)"),
                                    Parameter.new("$TRIGGER_RATE",
                                      "$TRIGGER_RATE can be any integer between 1 and 100000 (unit: Hz). " <<
                                        "It configures how often the driver will check the TDC card for new events. " <<
                                        "Ideally, it should be a multiple of the lamp pulse frequency (COM pulse rate). " <<
                                        "Suggestion: 4000 Hz is good if using a laser with pulse rate of 1000 Hz. " <<
                                        "Too high value will reduce performance. Too low value will increase number of missed events.",
                                      "? (Set by driver)"),
                                    Parameter.new("$COM_MODE",
                                      "$COM_MODE can be either COMMON_STOP or COMMON_START. " <<
                                        "It configures if the TDC card will use common stop or common start mode for triggering.",
                                      "COMMON_START (Set by driver)"),
                                    Parameter.new("$MAX_HITS_PER_CHANNEL",
                                      "$MAX_HITS_PER_CHANNEL can be any integer between 1 and 16. " <<
                                        "It configures how many hits the TDC card will accept per channel for each COM pulse.",
                                      "16 (Set by driver)"),
                                    ],
                                    TransmitOneLine,
                                    {:success => self.tdc_configured,
                                     :failure => self.tdc_configure_failure,}),
                                    
    :start =>         Command.new("START", :cmd_start, true, 
                                    "Starts the data gathering from TDC card.",
                                    [
                                    # first parameter can be used to specify how many COM EVENTS we want to get
                                    Parameter.new("$NUM_COM_EVENTS",
                                      "$NUM_COM_EVENTS can be any positive integer, or 0 for unlimited. " <<
                                        "If a limit is set, then the measurement will automatically stop " <<
                                        "when the number of COM signals reach the limit.",
                                      "0"),
                                    ],
                                    TransmitOneLine,
                                    {:success => self.tdc_started,
                                     :failure => self.tdc_start_failure,
                                     :already_started => self.tdc_already_started,}),
                                    
    :stop =>          Command.new("STOP", :cmd_stop, true, 
                                    "Stops data gathering from TDC card. ",
                                    nil,
                                    TransmitOneLine,
                                    {:success => self.tdc_stopped,}),
                                    
    :pause =>         Command.new("PAUSE", :cmd_pause, true, 
                                    "Pauses data gathering from TDC card. ",
                                    nil,
                                    TransmitOneLine,
                                    {:success => self.tdc_paused,}),
                                    
    :clear =>         Command.new("CLEAR", :cmd_clear, true, 
                                    "Clears the Measurement details. Should be sent before a new measurement is started.",
                                    nil,
                                    TransmitOneLine,
                                    {:success => self.tdc_cleared,}),

                                    
    :status =>        Command.new("STATUS", :cmd_status, false, 
                                    "Returns the status of the server. $STREAM = {the status of the server}.",
                                    nil,
                                    TransmitOneLine),
                                    
    :tdc_info =>      Command.new("TDC_INFO", :cmd_tdc_info, false,
                                    "Show information about the TDC module, details about the data from card, driver, etc.",
                                    nil,
                                    TransmitByteStream
                                    ),
                                    
    :test =>          Command.new("TEST", :cmd_test, false, 
                                    "Tests the communcation between server and client.",
                                    nil,
                                    TransmitNothing),
                                    
#    :read =>          Command.new("READ", :cmd_read, false, 
#                                    "Read events from server.",
#                                    [
#                                    # first parameter is what to read
#                                    Parameter.new("$TYPE",
#                                      "$TYPE - what to read"),
#                                    # second parameter is offset number of bytes
#                                    Parameter.new("$OFFSET",
#                                      "$OFFSET - the read start position, in the bytestream from TDC card.",
#                                      "0"),
#                                    # third parameter can tell how many of them to read (or all)
#                                    Parameter.new("$NUM_BYTES",
#                                      "$NUM_BYTES tells how many bytes to read.",
#                                      "{num bytes remaining in stream after $OFFSET}")
#                                    ],
#                                    TransmitByteStream),
                                    
                                    
#                                    
#    :read_raw =>      Command.new("READ_RAW", :cmd_read_raw, false, 
#                                    "Read raw TDC card data output.",
#                                    [
#                                    # first parameter is offset number of bytes
#                                    Parameter.new("$OFFSET",
#                                      "$OFFSET - the read start position, in the bytestream from TDC card.",
#                                      "0"),
#                                    # second parameter can tell how many of them to read (or all)
#                                    Parameter.new("$NUM_BYTES",
#                                      "$NUM_BYTES tells how many bytes to read.",
#                                      "{num bytes remaining in stream after $OFFSET}")
#                                    ],
#                                    TransmitByteStream),
                                    
#    :read_histogram => Command.new("READ_HISTOGRAM", :cmd_read_histogram, false, 
#                                    "Read histogram of flight-time/energy.",
#                                    nil,
#                                    TransmitByteStream),
                                    
#    :read_events =>   Command.new("READ_EVENTS", :cmd_read_events, false, 
#                                    "Read next events from the buffer of gathered events. NOTE: Deprecated!",
#                                    [
#                                    # first parameter can be used to only read i.e. SINGLES or DOUBLES
#                                    Parameter.new("$EVENT_TYPE",
#                                      "$EVENT_TYPE can be any of (ALL|SINGLES|DOUBLES|TRIPLES|QUADS)",
#                                      "ALL"),
#                                    # second parameter can tell offset
#                                    Parameter.new("$OFFSET",
#                                      "$OFFSET tells where to start in the event list. 0 = first event.",
#                                      "0"),
#                                    # thirs parameter can tell how many of them to read (or all)
#                                    Parameter.new("$NUM_LIMIT",
#                                      "$NUM_LIMIT tells how many events of type $EVENT_TYPE " <<
#                                        "to read from the server, and should be a positive integer " <<
#                                        "if you want to read at most $NUM_LIMIT number of events. " <<
#                                        "Note that the server might give you less events than you " <<
#                                        "asked for, if there are not enough events available. If you " <<
#                                        "don't give an upper limit, the server will just send as many " <<
#                                        "events as possible at the moment; all new events it has gathered " <<
#                                        "from the TDC card of the selected $EVENT_TYPE, since your last READ.",
#                                      "{num remaining}")
#                                    ],
#                                    TransmitRawEvents),
#                                    
    :read_buf =>            Command.new("READ_BUF", :cmd_read_buf, false, 
                                    "Read data from buffer.",
                                    [
                                    # first parameter can be used to only read i.e. SINGLES or DOUBLES
                                    Parameter.new("$BUFFER_TYPE",
                                      "$BUFFER_TYPE can be any of (SINGLES|DOUBLES|TRIPLES|TOF_HISTOGRAM|RAW)",
                                      "ALL"),
                                    # second parameter can tell offset
                                    Parameter.new("$OFFSET",
                                      "$OFFSET tells where to start in buffer. 0 = first byte.",
                                      "0"),
                                    # thirs parameter can tell how many of them to read (or all)
                                    Parameter.new("$NUM_LIMIT",
                                      "$NUM_LIMIT tells how many bytes in $BUFFER_TYPE " <<
                                        "to read from the server, and should be a positive integer " <<
                                        "if you want to read at most $NUM_LIMIT number of bytes. " <<
                                        "Note that the server might give you less bytes than you " <<
                                        "asked for, if the buffer is not filled up. If you " <<
                                        "don't give an upper limit, the server will send the whole buffer.",
                                      "{num bytes remaining}")
                                    ],
                                    TransmitByteStream)                                    

                                    
                                    
  }
  def self.prepared?() not @@CommandsLookup.nil? end
  def self.prepare
    # setup a hastable of commands as string mapping to the respective commands
    @@CommandsLookup = Hash.new()
    Commands.each_value { |cmd|
      @@CommandsLookup[cmd.to_s] = cmd
    }
    # get the current subversion revision for this file,
    # use "X" if svn info is not
    # a valid command on the OS, such as Windows.
    begin
      @@MinorVersion = IO.popen("svn info %s" % File.expand_path( __FILE__)).readlines[5].split[1]
    rescue
      @@MinorVersion = "X"
    end
  end
  
  #validates that the server has handler functions for all
  #commands in this protocol
  def self.validate_server(server)
    Commands.values.each do |cmd|
      case RUBY_VERSION.split('.')[0..1].join()
      #ruby 1.9:
      when "19"
        unless server.respond_to?(cmd.handler)
          raise NotImplementedError, 
            "Class #{self} doesn't implement a handler method #{cmd.handler} for command #{cmd}."
        end
        
      #ruby 1.8.6:
      when "18"
        server.instance_eval do
          unless methods.include?(cmd.handler.to_s)
            raise NotImplementedError,
                  "Class #{self} doesn't implement a handler method #{cmd.handler} for command #{cmd}."
          end
        end
      else
        raise "Ruby version is not 1.8 or 1.9!"
      end
    end
  end   
  
    
  def self.help(keyword=nil)
    if keyword
      return self.explain if keyword == '*' # all help at once
      Commands.each_value {|cmd|
        if cmd.to_s == keyword
          return cmd.explain.wordwrap(60, "\t")
        end     
      }
      return "Not a command: " << keyword + "\n"
    end
    str = ''
    str << "---------------\n"
    str << "TofProtocol #{MajorVersion}\n"
    str << "---------------\n"
    str << "Available commands and their meanings: \n"
    Commands.each_value {|p| str << " %09s:  %s\n" % [p, p.description]}
    str << "\n"
    str.wordwrap(60, "             ")
  end
  
  def self.explain
     self.explain_commands
  end
  
  def self.explain_commands
    str = "Command reference: \n\n"
    str << "[$PARAMETER] means that $PARAMETER is not required, and if omitted, " <<
            "its default value will be used instead.\n\n" <<
            "'#' Means that the rest of the line is a comment.\n\n"
    Commands.each_value {|cmd|
        str << cmd.explain
    }
    str.wordwrap(60, "\t")
  end 
  
  def self.has_cmd?(command)
    raise ArgumentError, "Symbol expected" unless command.kind_of?(Symbol)
    Commands.has_key?(command)
  end
  
  def self.cmd(command)
    return Commands[command] if command.kind_of?(Symbol)    
    return @@CommandsLookup[command]
  end
    
  #used for cmd :read as the first parameter
  def self.buffer_types(type)
    case type
      when :singles, "SINGLES"; "SINGLES"
      when :doubles, "DOUBLES"; "DOUBLES"
      when :triples, "TRIPLES"; "TRIPLES"
      when :delays, "DELAYS"; "DELAYS"
      when :tof_histogram, "TOF_HISTOGRAM"; "TOF_HISTOGRAM"
      when :raw_buf, "RAW"; "RAW"
      else raise "Wrong buffer type" #"*" #any
    end
  end

  #------------------
  # Protocol strings:
  #------------------
  
  # The message the server greets new clients with when they connect
  def self.client_connect_message()
    self.welcome_message() + "\n" + self.version_info()    
  end  
  def self.welcome_message() "HELLO, Welcome to ToF server" end
  def self.version_major() "#{MajorVersion}" end
  def self.version_minor() "#{@@MinorVersion}" end
  def self.version_info() "#Protocol version: #{MajorVersion}.#{@@MinorVersion}" end
  def self.version(message=self.protocol_info())
      # extract major and minor versions from a version_info string
      version = message.split[2]
      return {:major => version[0..2],
              :minor => version[4..-1]}
  end
    
  def self.cmd_ok(command) "#{command} ACCEPTED" end
  def self.cmd_restricted(command) "#{command} RESTRICTED" end
  def self.cmd_err(command) "IMPOSSIBLE" end
    
    
  # strings for transmit_data
  def self.tx_no_data_server() "NO_DATA" end
  def self.tx_no_data_client() "NO_DATA" end    
    
  def self.tx_bytes_server(num_bytes) "SEND #{num_bytes}" end  
  def self.tx_bytes_client(num_bytes) "GET #{num_bytes}" end  
  def self.tx_bytes_client_ack(num_bytes=nil) "GOT #{num_bytes}" end 
  
  def self.tx_server_ok() "DONE" end
  def self.tx_server_err() "FAILED" end
    
  def self.server_ack() "ACK" end
  def self.server_nack() "ERR" end
    
  def self.tx_events_server(num_events, num_bytes) "SEND #{num_events} #{num_bytes}" end 
  def self.tx_events_client(num_events, num_bytes) "GET #{num_events} #{num_bytes}" end
  
end

TofProtocol.prepare unless TofProtocol.prepared?

if __FILE__ == $0  
  puts TofProtocol.help  
  puts "Demonstration:\n\n"
  puts TofProtocol.help("HELP")  
  puts TofProtocol.help("STATUS")  
  puts TofProtocol.help("READ")
  puts TofProtocol.help("BADCMD") 
  
  puts "Protocol self explanation:"
  puts TofProtocol.explain
  
  
  document_text =<<EOF
ToF Client/Server protocol version #{TofProtocol.version_major()}
Development version, revision #{TofProtocol.version_minor()}
--------------------------------------
Description of symbols in this text:
$VAR            = some variable, substitute with appropriate text
(Action)        = Some action, Action, should happen
Server: text1   = Server sends the string "text1" to client
Client: text2   = Client sends the string "text2" to server

Note:   After the string, there is a newline to indicate end of message.
    This should be ignored by client, and also by server.
    Howerver, when sending binary data, newline characters might
    be part of the data stream. In this case, the server will
    first tell the client how many bytes it is going to send,
    so the client can parse the data correctly.

The connection should be made in Telnet mode, and most of the
commands and responses are possible to easily understand just
by reading them from a console.

For testing purposes, you can therefore connect to the server
using a telnet client, and type commands and read responses.
(Note that binary responses will be more difficult to understand.)

Typical chain of events:

1. (Client connects to server)
2. Server: #{TofProtocol.welcome_message()}
3. (Client disconnects if greeting not correct)
4. Server: #{TofProtocol.version_info()}
5. (Client verifies protocol major version and disconnects if incorrect.)

Note:
  The major version is #{TofProtocol.version_major()}, and the server is at revision #{TofProtocol.version_minor()}.
  (If the server is running on a computer that doesn't have
  subversion installed, the version will be shown as: #{TofProtocol.version_major()}.X.)
  Protocol should not change between major versions, even if revisions differ.
  
  However, because of human error, the protocol might accidentally be changed
  between revisions, so if you see a higher revision number than expected,
  and the protocol doesn't work as you expected, something has probably changed,
  and needs to be reversed, or major version should be incremented.

6. Client: $COMMAND $PARAMETER_1 $PARAMETER_2 ... $PARAMETER_N
7a) Server: #{TofProtocol.cmd_ok("$COMMAND")}
7b) Server: #{TofProtocol.cmd_err("$COMMAND")}
7c) Server: #{TofProtocol.cmd_restricted("$COMMAND")}

Note:
  The client sends a command, $COMMAND, to the server, where $COMMAND
  must be one of the accepted commands described below. The server
  replies according to (7a) if the command is valid.
  
  If the command is invalid, server sleeps for 1 second, and
  then replies according to (7b). (The short sleep is a security
  so the client doesn't just flood the server with invalid commands
  without realizing there is an error.)

  If the command is restricted, and the client is not a master client,
  the server replies according to (7c) and does not execute it.
  
  The parameters, which are optional, are separated by space,
  and depend on which $COMMAND is given. More details are available
  in the section Command reference below.  
  
  In this version of the protocol, the client must be certain to
  give valid parameters, since the server does not check them.
  
  Example1: A valid request
  -------------------------
  (Client connected to server while no other clients were connected,
  and is therefore master client.)
  Client: #{TofProtocol.cmd(:start)}
  Server: #{TofProtocol.cmd_ok(TofProtocol.cmd(:start))}
  
  Example2: An invalid request
  ----------------------------
  Client: SELFDESTRUCT
  (approximately 1 sec delay)
  Server: #{TofProtocol.cmd_err("SELFDESTRUCT")}

  Example3: A restricted request
  ------------------------------
  (Client connected to server while other client(s) were connected,
  and therefore has limited privileges.)
  Client: #{TofProtocol.cmd(:start)}
  Server: #{TofProtocol.cmd_restricted(TofProtocol.cmd(:start))}  
  
Note: Listen timeout is #{TofProtocol::TIMEOUT} seconds. If server waits
for more than this amount of time, client will lose it's connection.

------------------------------------------------------------
EOF
  
  DocFile = "../doc/protocol_%s.txt" % [TofProtocol.version_major()]
  begin
    f = File.open(DocFile, "w")  
    f.puts document_text
    f.puts TofProtocol.explain
    puts "Protocol command reference written into file: %s" % DocFile
  rescue EOFError
    puts "Could not document protocol command reference to file: %s" % DocFile
  ensure
    f.close if f
  end
  
end
