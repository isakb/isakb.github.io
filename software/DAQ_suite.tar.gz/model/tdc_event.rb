class Pos < Struct.new(:x,:y)
  def initialize(_x,_y)
#    x = _x.nil? ? 'X' : _x
#    y = _y.nil? ? 'Y' : _y
    super(_x,_y)
  end
  def to_s
    "[%s,%s]" % [x.to_s, y.to_s]
  end
  
end

class TDCEvent < Array  
  class EBuffer < RuntimeError; end
  attr_accessor :e_pos  # the position of the electron hit
  # The meanings of the different channels:
  # TODO: Make it possible to change at runtime...
  @@ch = {:electron_x => 0,
          :electron_y => 1,
          :electron => 5 }
  def initialize(buffer=nil)
    from_buf(buffer) if buffer
  end  
  # convert data from buffer into TDCHit objects belonging to this event
  def from_buf(buffer)
    num_hits = buffer[0]
    if buffer.length != num_hits * TDCHit::NUM_BYTES + 1
      raise TDCEvent::EBuffer, "Buffer is invalid, hex: " << buffer.gsub!(/./) {|s| ' 0x' + s[0].to_s(base=16)}      
    end
#    if num_hits > 16
#      raise TDCEvent::EBuffer, "Very many hits!"
#    end
    pos = 1
    num_hits.times do |hit|
      ch = buffer[pos]      
      if ch < 0 || ch > 8
        raise TDCEvent::EBuffer, ("ch %d is incorrect for buffer, hex: " % ch )<< buffer.gsub!(/./) {|s| ' 0x' + s[0].to_s(base=16)}
      end
      dly = buffer[pos+1, TDCHit::NUM_BYTES_DELAY].unpack("S").first.to_i      
      self << TDCHit.new(ch, dly)
      pos += TDCHit::NUM_BYTES
    end
    #classify
  end  
  
  def to_buf() "%c%s" % [self.length, self.inject("") {|ret, t| ret += t.to_buf}] end
  
  def ch() @@ch end    
    
  # classify this event as single, double or multiple hit, etc. 
  # TODO: More possible classifications
  # if the different channels have different meanings
  # i. e. if CH2 and CH3 are used for X and Y positioning
  # on the anode.
  def classify
    return 0 if self.empty?
    return @type if @type
    
    e, ex, ey = nil    

    # calculate how many hits got registered on each channel:
    to_remove = []
    num = Hash.new(0)
    self.each { |hit|
      case hit.channel
        when @@ch[:electron_x]; ex = hit.delay; to_remove << hit
        when @@ch[:electron_y]; ey = hit.delay; to_remove << hit
        when @@ch[:electron]; e = hit.delay; num[hit.channel] += 1
        else num[hit.channel] += 1
      end
    }
    
    to_remove.each {|i| self.delete i }
    return 0 if self.empty?
    
    if e
      # Calculate electron hit position (it is not sure that both x and y is known
      # and there might also be hits where no electron hit was detected, but
      # and x and/or y hit was detected anyway.
      ex -= e if ex
      ey -= e if ey
      @e_pos = Pos.new(ex, ey)
    end
    @type = num[@@ch[:electron]]
    return @type
  end

  #return array of all electron hits except position detection hits
  def electrons()
    arr = self.select {|hit| hit.channel == @@ch[:electron] }
    arr.each {|h| yield h } if block_given?
    arr
  end
  
  # representation for file: tab separated
  # example, if this is a single hit event with delay 123: "123"
  # if double hit with delay 123, 234: "123\t234"
  # if triple hit: "123\t234\t345" etc.
  def electrons_delays_to_s(separator="\t")
    self.electrons_delays().join(separator)
  end  
  def electrons_delays()    
    if block_given?
      e = self.electrons.select{|hit| yield(hit.delay) }
    else
      e = self.electrons
    end
    unless e.empty?
#      return e.collect{|hit| hit.delay }.sort
      return e.collect{|hit| hit.delay }.reverse # the TDC will return them in reverse time order...
    end
  end
  
  def to_s
    " " + classify.to_s + " hit at " + @e_pos.to_s + "\n" +
    "  " + join("\n  ")
  end
end

class TDCHit
  NUM_BYTES = 3
  NUM_BYTES_DELAY = 2
  attr_accessor :channel, :delay  
  def initialize(channel, delay) @channel = channel; @delay = delay end
  def to_s() "CH#{@channel} #{delay} ns/2"; end
  def to_buf() [@channel, @delay].pack("CS") end
end
