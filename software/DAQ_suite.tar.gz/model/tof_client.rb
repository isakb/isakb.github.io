#!/usr/bin/env ruby

# A module of ToF client functions

require 'thread'
#require 'base64'

$: << File.expand_path( File.dirname(__FILE__) + "/../")
require 'model/protocol'
require 'model/tdc_event'
require 'helper/statistics'
require 'client/model/tof_server_connection'

module TofClient

  @@num_clients = 0

  DEFAULT_HOST = "127.0.0.1"
  DEFAULT_PORT = "10001"

  MAX_NO_DATA_READS = 10 # if server has replied that no data is available, stop trying after this many read attempts.


  class EConnection < RuntimeError; end
  class ENoData < RuntimeError; end

  def self.get_host_port_from_argv(skip_default=false)
    (host, port = DEFAULT_HOST, DEFAULT_PORT) unless skip_default
    #check arguments
    ARGV.length.times do |i|
      case ARGV[i]
        when  /help/;
          puts "   usage: ruby #{__FILE__} [-host #{DEFAULT_HOST}] [-port #{DEFAULT_PORT}]"
          exit
        when /host/; host = ARGV[i+1] if ARGV[i+1]
        when /port/; port = ARGV[i+1].to_i if ARGV[i+1] and ARGV[i+1].to_i > 0
      end
    end
    return host, port
  end

  #To make sure we are talking to the correct server:
  ExpectedGreeting = TofProtocol.welcome_message()
  ExpectedProtocol = TofProtocol.version_info() + "df"
  ExpectedProtocolVersion = TofProtocol::MajorVersion

  attr_reader :listen_timeout

  attr_accessor :debug, :server

  def initialize(options = {:host=>nil, :port=>nil, :debug=>false, :debug_comm=>false}, do_connect=true)
    @id = @@num_clients += 1
    @debug = options[:debug]
    @fifo_buf = ""
    @listen_timeout = TofProtocol::TIMEOUT
    @s_cfg = {:host => (options[:host] or DEFAULT_HOST),
              :port => (options[:port] or DEFAULT_PORT),
              :debug => options[:debug],
              :debug_comm => options[:debug_comm],
              :client => self}
    @s_cfg[:do_connect] = do_connect
#    if do_connect
#      connect
#    else
#      @server = TofServerConnection.new(:do_connect => false)
#    end
    @server = TofServerConnection.new(@s_cfg)
    connect if do_connect
  end

  def connect_toggle()
    return disconnect if @server && @server.connected?
    connect()
  end

  def server_uri=(options = {:host=>nil, :port=>nil})
    p options
    if options.kind_of?(String)
      t=Hash.new(nil)
      # Parse a string as "address:port"
      t[:host] = options.split(":")[0]
      t[:port] = options.split(":")[1]
      options = t
    elsif options.nil?
      options = {}
    end
    @s_cfg[:host] = (options[:host] or DEFAULT_HOST)
    @s_cfg[:port] = (options[:port] or DEFAULT_PORT)
  end
  def server_uri() "%s:%s" % [@s_cfg[:host], @s_cfg[:port]] end

  def connect(options=nil)
    #options ||= @s_cfg
    begin
      #@server = TofServerConnection.new(options)
      @server.connect
      # Server response tells if we are connected to the correct server and assures that the correct protocol is used
      greeting = response

      inform "TofClient.server greeting: #{greeting}"
      raise TofServerConnection::EWrongServer, "Greeting from server is: %s, but client expected: %s" % [greeting, ExpectedGreeting] \
        unless greeting == ExpectedGreeting

      version_info = response
      p_version = TofProtocol.version(version_info)
      inform "Server is using protocol: %s, major version: %s, revision: %s" % [version_info, p_version[:major], p_version[:minor]]
      raise TofServerConnection::EWrongProtocol, "Server protocol version is: %s, but client is using: %s" % [p_version[:major], ExpectedProtocolVersion] \
        unless p_version[:major] == ExpectedProtocolVersion

    rescue Errno::EBADF, Errno::ECONNREFUSED => e
      #raise e, "Could not connect to (#{@s_cfg[:host]}:#{@s_cfg[:port]}). " << e if @debug
      raise EConnection, "Unable to connect: " << e
    rescue TofProtocol::ERROR::NoServerResponse => e
      #raise e, "No greeting from server - which we need to verify the server protocol etc. " << e if @debug
      raise EConnection, "Wrong protocol on server: " << e
    end
    return connected?
  end

  def disconnect()
    return false unless @server.connected?
    @server.stop if @server.state == :running
    @server.disconnect()
    return true
    #@server = nil
  end

  def connected?() @server.connected? end

  # returns response from server
  def response() @server.listen end

  # sends cmd to server
  def cmd(command, *params) @server.try_command(command, *params) end

  # print text to stdout
  def inform(text, always_show=false)
    return unless @debug or always_show
    #use different colors for different clients, since many clients may be used in one app.
    color = "\e[%sm" % (@id+29).to_s # see http://kpumuk.info/ruby-on-rails/colorizing-console-ruby-script-output/
    reset = "\e[0m"
    $stdout.puts color + text + reset
  end

  def on_server_disconnect()
    @server.state = :offline
    inform "Server went offline!"
  end

  def quit()
    self.disconnect
    inform "Quitting..."
  end

  def test_speed(repeat=100, &block)
    dbg = @debug
    @debug = false
    puts "Testing communication speed with server #{repeat} times."
    t = [].extend Statistics
    repeat.times do |i|
      if block_given?
        t0 = Time.now
        yield block.arity == 1 ? i : nil
        t << 1000 * (Time.now - t0) # convert s to ms
      else
        t0 = Time.now
        @server.test
        t << 1000 * (Time.now() - t0) # convert s to ms
        if i.modulo(repeat/10) == 0
          print "%d%%... " % [100*i/repeat]
          $stdout.flush
        end
      end
    end
    puts
    puts "Done."
    puts "Times were: (ms)"
    puts t.join(", ")
    #stats = {:max => t.max, :min => t.min, :mean => t.mean, :std_dev => t.std_dev}
    stats = [t.max, t.min, t.mean, t.std_dev]
    puts "Max: %.2f, Min: %.2f, Mean: %.2f, StdDev: %.2f (ms)" % stats
    @debug = dbg
    stats
  end


#  def read_raw_old(num=nil)
#    puts "Reading raw..." if @debug
#
#    @server.get_raw_by_cmd(TofProtocol.cmd(:read_events), TofProtocol.event_types(:any), num, "events") { |buf|
#      @fifo_buf << buf
#      puts "got one" if @debug
#    }
#
#    while @fifo_buf.length > 1 + TDCHit::NUM_BYTES do
#      nhits = @fifo_buf[0] || 0
#      begin
#        return if @fifo_buf.length < nhits * TDCHit::NUM_BYTES + 1  #raise RangeError, "Fifo Buffer needs more data!"
#        str = @fifo_buf.slice!(0..nhits * TDCHit::NUM_BYTES)
#        if str
#          yield TDCEvent.new(str)
#        end
#      rescue => e
#        raise e
#        exit
#      end
#    end
#
#  end

#  def read_doubles(num=nil)
#    @server.has_more_data = true
#    Thread.new do
#      count_failed_attempts = 0
#      offset = 0 # 0 # should be 0, but for debug I use a higher value
#      while @server.running? && @server.has_more_data?
#        #@server.get_by_cmd(:read_events, [TofProtocol.event_types(:doubles), offset, num]) { |buf|
#        @server.get_by_cmd(:read, [TofProtocol.event_types(:doubles), offset, num]) { |buf|
#          doubles << buf
#          offset += buf.length
#          p buf
#        }
##        @server.get_by_cmd(:read_raw, [offset, num]) { |buf|
##          sem.synchronize { @fifo_buf << buf }
##          offset += buf.length
##        }
#        sleep(sleeptime) unless sleeptime.nil?
#      end
#    end
#  end

  def each_event(num=0x8000, sleeptime=nil, &block)  #TODO: num as some default constant
    offset = 0 # 0 # should be 0, but for debug I use a higher value
    fifo_buf = ""
    while @server.running?
      unless @server.has_more_data?
        #TODO: Inform admin that hitrate has dropped to zero?
        $stderr.puts "There is no more data to get from the server!"
        sleep(0.5)
      end
      unless @server.get_by_cmd(:read_buf, [TofProtocol.buffer_types(:raw_buf), offset, num]) { |buf|
        fifo_buf << buf.to_s
        unless fifo_buf.length > TDCHit::NUM_BYTES
          puts "fifo buf has too little data, size: #{@fifo_buf.length}" if @debug
          next
        end
        offset += buf.length
        while fifo_buf.length > TDCHit::NUM_BYTES
          nhits = fifo_buf[0]
          break if nhits.nil? or fifo_buf.length <= nhits * TDCHit::NUM_BYTES
          str = fifo_buf.slice!(0..(nhits * TDCHit::NUM_BYTES))
          next if str.nil?# or str.length <= TDCHit::NUM_BYTES # let fifo_buf fill up first
          yield TDCEvent.new(str)
        end

      }
        sleep(0.5) # if no data was available
      end
      sleep(sleeptime) unless sleeptime.nil?
    end
    puts "No more data to get from server" if @debug
  end



#  def each_event_previous_version(num=4096, sleeptime=nil, &block)  #TODO: num as some default constant
#    # Lite buggig...
#    @server.has_more_data = true
#    sem = Mutex.new
#    Thread.abort_on_exception = true
#    fill_fifo_thread = Thread.new {
#      offset = 0 # 0 # should be 0, but for debug I use a higher value
#      while @server.running? && @server.has_more_data?
#        #@server.get_by_cmd(:read_events, [TofProtocol.event_types(:any), offset, num]) { |buf|
#        @server.get_by_cmd(:read_buf, [TofProtocol.buffer_types(:raw_buf), offset, num]) { |buf|
#          #buf = Base64.decode64(buf)
#          sem.synchronize {
#            @fifo_buf << buf
#            offset += buf.length
#
#            #File.open("/dev/shm/debug2.txt", "a") do |f| f.puts buf.dump end
#
#          }
#        }
##        @server.get_by_cmd(:read_raw, [offset, num]) { |buf|
##          sem.synchronize { @fifo_buf << buf }
##          offset += buf.length
##        }
#        sleep(sleeptime) unless sleeptime.nil?
#      end
#      puts "No more data to get from server" if @debug
#    }
#
#
#
#    analyser_thread = Thread.new {
#      str = false
#      begin
#        loop do
#          # wait until fifo buffer fills up before reading from it
#          while (sem.synchronize{@fifo_buf.length <= TDCHit::NUM_BYTES} && @server.running? && @server.has_more_data?)
#            puts "Waiting for @fifo_buf to fill up..." if @debug
#            sleep(1)
#          end
#          unless sem.synchronize{@fifo_buf.length > TDCHit::NUM_BYTES}
#            puts "fifo buf has too little data, size: #{@fifo_buf.length}" if @debug
#            raise TofClient::ENoData, "No more data available from server."
#          end
#          str = sem.synchronize{
#            nhits = @fifo_buf[0]
#            if nhits.nil? or @fifo_buf.length <= nhits * TDCHit::NUM_BYTES
#              false
#            else
#              @fifo_buf.slice!(0..(nhits * TDCHit::NUM_BYTES))
#            end
#          }
#          next unless str.is_a?(String)
#  #        next if str.nil?
#          yield TDCEvent.new(str)
#
#  #          begin
#  #            if @fifo_buf.length <= nhits * TDCHit::NUM_BYTES
#  #              #raise RangeError, "Fifo Buffer needs more data!"
#  #              sleep(0.05)
#  #              puts "@fifo_buf.length <= nhits * #{TDCHit::NUM_BYTES}, nhits = %d" % nhits if @debug
#  #              next
#  #            end
#  #            str = @fifo_buf.slice!(0..nhits * TDCHit::NUM_BYTES)
#  #            next if str.nil?
#  #            yield TDCEvent.new(str)
#  #            @prev_str = str
#  #          rescue
#  #            puts "nhits: %d" % nhits
#  #            puts "\n\nprev_str: "
#  #            begin @prev_str.each_byte {|b| print b, ' ' }
#  #            rescue
#  #            end
#  #            puts "\n\nstr: "
#  #            str.each_byte {|b| print b, ' ' }
#  #            raise
#  #            exit
#  #          end
#
#        end
#      rescue TofClient::ENoData => e
#        puts e.to_s if @debug
#      rescue => e
#        p str
#        raise e
#      end
#    }
#
#    fill_fifo_thread.join
#    analyser_thread.join
#
#  end

  def get_histogram(sleeptime=nil, &block)
    sem = Mutex.new
    Thread.new do
      while true
        @server.get_histogram { |buf|
          puts "got histogram" if @debug
        }
        sleep(sleeptime) unless sleeptime.nil?
      end
    end
  end

  def running?() @server.running? end

end

