#!/usr/bin/env ruby

# This file is based on code from: http://snippets.dzone.com/posts/show/1874

require 'thread'
require 'gtkglext'

$: << File.expand_path( File.dirname(__FILE__))
require 'vector'
require 'renderer'

class RGBA
  attr_accessor :r,:g,:b,:a  
	def initialize(r, g, b, a=1.0) @r, @g, @b, @a = r.to_f, g.to_f, b.to_f, a.to_f end  
end

class Graphics 
  attr_accessor :bgcolor
  def initialize(bg=nil, width=nil, height=nil)
    @bgcolor = (bg or RGBA.new(0,0,0,0))
    @width = width
    @height = height
  end
  def draw(renderer) end    
end

## -----------------------------------------------------------------------------
## A generic class for OpenGL application functions.
## -----------------------------------------------------------------------------
class GLRender
  
  include GLRenderPrimitives
  
  
  def initialize(xsize = 800, ysize = 600)
    @Xsize = xsize
    @Ysize = ysize
  end
  
  def bgcolor=(rgb)
    GL.ClearColor(rgb.r, rgb.g, rgb.b, rgb.a)
  end

  ## Initialise OpenGL state for 3D rendering.
  def init()
    GL.ShadeModel(GL::SMOOTH)
    #GL.Enable(GL::DEPTH_TEST)
    #GL.DepthFunc(GL::LEQUAL)
    # GL.ClearColor(@bgcolor.r, @bgcolor.g, @bgcolor.b, @bgcolor.a)
    #GL.Ortho(0, @Xsize, @Ysize, 0, 0, 1)
    #GL.Hint(GL::PERSPECTIVE_CORRECTION_HINT, GL::NICEST)
    true
  end

  ## Resize OpenGL viewport.
  def resize(width, height)
    GL.Viewport(0, 0, width, height)
    GL.MatrixMode(GL::PROJECTION)
    GL.LoadIdentity()
    GL.Ortho(-width.to_f()/2, width.to_f()/2, height.to_f()/2, -height.to_f()/2, 0, 1)    
    GL.MatrixMode(GL::MODELVIEW)
  end
  

  ## Render 2D OpenGL scene
  def draw(graphics)
    puts "renderer is drawing" if @debug
    self.bgcolor = graphics.bgcolor
    GL.Clear(GL::COLOR_BUFFER_BIT)
    GL.PushMatrix()
    
    graphics.draw(self)
    
    GL.PopMatrix()
    GL.Flush()
  end  
  
  protected  
  #used to make a bin in a histogram
  def _drawLine(bottom_left, top_right, bottomColor=nil, topColor=nil)
    b, t = bottom_left, top_right    
    glBegin(GL_QUADS)
      glVertex2f(b[0], b[1])
      glVertex2f(b[0], t[1])
      glVertex2f(t[0], t[1])
      glVertex2f(t[0], b[1])
    glEnd()
  end
  
  #used to make a bin in a histogram
  def _drawRectangle(bottom_left, top_right, bottomColor=nil, topColor=nil)
    b, t = bottom_left, top_right    
    glBegin(GL_QUADS)
      glVertex2f(b[0], b[1])
      glVertex2f(b[0], t[1])
      glVertex2f(t[0], t[1])
      glVertex2f(t[0], b[1])
    glEnd()
  end
  
  
end

## -----------------------------------------------------------------------------
## A GtkDrawingArea widget with OpenGL rendering capabilities.
## -----------------------------------------------------------------------------
class GLDrawingArea < Gtk::DrawingArea
  attr_accessor :graphics
  def initialize(width, height, gl_config=nil, bgcolor = RGBA.new(0,0,0,0), debug=false)
    gl_config ||= Gdk::GLConfig.new(Gdk::GLConfig::MODE_DEPTH |
                                  Gdk::GLConfig::MODE_DOUBLE |
                                  Gdk::GLConfig::MODE_RGBA)
    super()
    @debug = debug
    @render_mutex = Mutex.new
    @graphics = Graphics.new(bgcolor, width, height)
    set_size_request(width, height)
    set_gl_capability(gl_config)

    ## Create an OpenGL renderer instance.
    @render = GLRender.new(width, height)

    ## Signal handler for drawing area initialisation.
    signal_connect_after("realize") do
      gl_begin() { @render.init() }
    end

    ## Signal handler for drawing area reshapes.
    signal_connect_after("configure_event") do
      gl_begin() { @render.resize(allocation.width, allocation.height) }
    end

    ## Signal handler for drawing area expose events.
    signal_connect_after("expose_event") do
      refresh
    end
    
    def refresh()
      begin
        @render_mutex.synchronize {
          gl_begin() do
            @render.draw(@graphics)
          end
          gl_drawable.swap_buffers() if gl_drawable.double_buffered?
        }
      rescue TypeError => e
        puts "@render is destroyed. " << e
      end
    end
    
    def bgcolor=(rgb)
      @render.bgcolor=rgb
    end

    ## Add mouse button press/release signal event handlers
    add_events(Gdk::Event::BUTTON_PRESS_MASK |
               Gdk::Event::BUTTON_RELEASE_MASK)

    signal_connect_after("button_press_event") { button_press_event() }
    signal_connect_after("button_release_event") { button_release_event() }
  end

  def gl_begin()
    gl_drawable.gl_begin(gl_context) { yield }
  end

  def button_press_event()
    puts "button_press_event" if @debug
    true
  end

  def button_release_event()
    puts "button_release_event" if @debug
    true
  end
end

## -----------------------------------------------------------------------------
## Application GUI Main Window Class
## -----------------------------------------------------------------------------
class AppWindow < Gtk::Window
  attr_reader :gl_area

  def initialize(title, width, height, gl_config=nil, debug=false)
    p title
    p width
    super(title)
    @debug = debug
    ## Connect signals to handle keyboard user input.
    signal_connect_after("key_press_event") { key_press_event() }
    signal_connect_after("key_release_event") { key_release_event() }

    ## Create our GL drawing area widget.
    @gl_area = GLDrawingArea.new(width, height, gl_config, debug)
    @gl_area.graphics = Graphics.new(nil, width, height)
    add(@gl_area)
    show_all()
  end

  def key_press_event()
    puts "key_press_event " if @debug
    true
  end

  def key_release_event()
    puts "key_release_event" if @debug
    true
  end
end

## -----------------------------------------------------------------------------
## Application Class
## -----------------------------------------------------------------------------
class GtkGLApp
  attr_reader :window

  def initialize(title, width, height, bpp, debug=false)
    @debug = debug
    ## Initialise Gtk[GLExt] library.
    Gtk.init()
    Gtk::GL.init()

    ## Obtain a valid OpenGL context configuration.
    gl_config = Gdk::GLConfig.new(Gdk::GLConfig::MODE_DEPTH |
                                  Gdk::GLConfig::MODE_DOUBLE |
                                  Gdk::GLConfig::MODE_RGBA)

    ## Create application main interface window.
    @window = AppWindow.new(title, width, height, gl_config, debug=@debug)

    @window.signal_connect_after("delete_event") do
      puts "Closing application." if @debug
      @window.destroy()
      Gtk.main_quit()
    end
  end

  def main()
    Gtk.main()  ## Enter into Gtk's main event processing loop.
    true
  end
end

## -----------------------------------------------------------------------------
## Application Entry Point
## -----------------------------------------------------------------------------
if $0 == __FILE__
  ## Create new application context.
  context = GtkGLApp.new("Gtk GL Application", 800, 600, 16)
  context.main()  ## Enter into the main execution loop.
end

