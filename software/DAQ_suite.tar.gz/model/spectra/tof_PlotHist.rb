
#This class provides an interface between histograms and plots. It keeps track
#of if it is up to date and where the data are saved to disk. 
class Plot2DHist
    
    # [data_to_plot] is the method to call to retrieve data i.e @spectrum.method("doubles_time") for doubles_time
    #
    # [file]            is the file for the histogram output
    # [spacings= "uniform"] (not implemented)
    def initialize(data_to_plot, file, spacings= "uniform")
        if data_to_plot.class != Method
            raise TypeError, "data_to_plot must be a function " + 
                    "i.e. [1,2,3].method(\"sort\")"     
        end
        @data_to_plot = data_to_plot 
        @spacings = spacings
        @hist = nil
        @file = file 
        @updated = false
        @rescale = false#true#false
    end
    
    attr_reader :file, :hist, :rescale
    attr_accessor :updated
    
    def rescale=(bool)
        @updated = false
        @rescale = bool
    end
    
    def calculate(bin_spec=[])
        bin_spec.flatten!
        if  @updated and (bin_spec == [] or  @hist.eqv_binspec?(bin_spec))
            puts "NB! Calling without argument replots rather than setting bin_spec to default value. To get default value pass \"nil\"" if bin_spec == []
        else
            #We need to make the histogram
            bin_spec = nil if bin_spec == [nil]
            @hist = Tof_2Dhist.new(@data_to_plot.call(), bin_spec, @file.path, @spacings )
            if @rescale
                p "rescaling to enhance weak features"
                @hist.rescale{|z| Math.sqrt(Math.log(z+1))}
            end
            #save hist in file and point the tofplot_file to it
            @hist.save_as_file
            @updated = true
         end
         @tofplot_file = @file
    end
    
    def eql?(o)
        o.is_a?(Plot2DHist) && @file == o.file
    end
    
    def hash
        @file.path.hash
    end
end

class Plot1DHist < Plot2DHist

    
    def calculate(*bin_spec)
        bin_spec.flatten!
#        p bin_spec
        if  @updated and (bin_spec == [] or  @hist.eqv_binspec?(bin_spec))
            puts "NB! Calling without argument replots rather than setting bin_spec to default value. To get default value pass \"nil\"" if bin_spec == []
        else
            p "#{bin_spec} in Plot1DHist" if $DEBUG
            bin_spec = nil if bin_spec == [nil] or bin_spec == []
            @hist = Tof_1Dhist.new(@data_to_plot.call(), bin_spec, @file.path, @spacings )
            @hist.save_as_file
            @updated = true
        end
        @tofplot_file = @file
    end
    
    def eql?(o)
        o.is_a?(Plot1DHist) && @file == o.file
    end 
end
