#Handles communication with Gnuplot using popen (requires UNIX-like platform). Mix-in this module to get basic functionality. The plotclass needs to provide it's own +plot+ method and, at least for multiplot plots, a +replot+ method. The replot method (if available) is called by the module's +tof_gnuplot_save_as_png+-method.


module Tof_gnuplot

#-------------------------- Gnuplot interface --------------------------------
  def cmd(cmd)
    @gnu_pipe = nil unless defined? @gnu_pipe
    @gnu_pipe = IO.popen("gnuplot","r+") if @gnu_pipe == nil
    @gnu_pipe.write(cmd + "\n")
  end

  def prompt
      str = nil
      print "gnu_prompt, \"quit\" to end>>"
      # flush STDIN and read from it?
      while str = gets #ends on ^D
          str = str.to_s
          if str =~ /exit|quit/
            break
          end
          #puts "cmd: #{str}"
          print "gnuplot> "
          cmd(str)
      end
  end

  def close
      if @gnu_pipe
      @gnu_pipe.close
      @gnu_pipe = nil
        else
            p "The connection to gnuplot has already been closed or was never opened"
        end
  end


  def replot
    cmd("replot")
    #puts "If you wish to restore plot try +reset_plot+ or +remove_fwhm_from_plot+"
  end

    def listen_to_gnuplot
    @gnu_pipe.readline
  end

    def get_var(var)
      cmd "set print \"-\""
    cmd(" if (exists(\"#{var}\")) print #{var} ; else print \"None\" \n")
    result=listen_to_gnuplot
    unless result == "None"
        result = result.to_f
        else
            result=nil
        end
    cmd "set print \n"
    result
  end

# - - - - - - - - - - Wrap Gnuplot functions - - - - - -  - - - - -
  def xrange(*args)
    args.flatten!
    cmd("set xrange [#{args[0]}:#{args[1]}]")
  end
  def yrange(*args)
    args.flatten!
    cmd("set yrange [#{args[0]}:#{args[1]}]")
  end
  def cbrange(*args)
    args.flatten!
    cmd("set cbrange [#{args[0]}:#{args[1]}]")
  end
  def grid_on
    cmd("set mytics 5 \n set grid ytics xtics")
    replot
  end
  def grid_on_mxtics
    cmd("set mxtics 5 \n set grid xtics ytics mxtics")
    replot
  end
  def grid_on_mytics
    cmd("set mytics 5 \n set grid ytics xtics mytics")
    replot
  end
  def grid_on_no_mtics
    cmd("set grid ytics xtics nomytics nomxtics")
    replot
  end




  def grid_off
    cmd("unset grid")
    replot
  end
#-------------------- save ------------------------------------------
  #def Tof_gnuplot.save_png(file_name)
  def  tof_gnuplot_save_as_png(file_name)
    #Saves current plot as png - overwrites existing file
    cmd = "set terminal push \n"
    cmd += "set terminal png \n"
    cmd += "set output \"#{file_name}\" \n"
    cmd(cmd)
    replot()
    puts "image saved as \"#{file_name}\""
    cmd( "set terminal pop \n")

  end
#module_function :cmd,  :close, :replot

end
