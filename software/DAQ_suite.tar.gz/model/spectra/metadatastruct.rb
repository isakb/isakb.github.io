#Stores information about an measurement. Among other things the values saved
# in .PAR files by the GTAUGER programs
class TofMetaData
     DEFAULTS =
   {
    :label               => "", #displayed in graphs. Maybe I'll remove this one
#    :measurement_type    => nil, # ie :pepeco or :pepico
    :comments            => "",
    :trigger_type        => nil,
    :lightsource_period  => 10000,
    :run_no              => -1,
    :excitation_energy   => 10000, #eV
    :t_min               => 0,
    :t_max               => nil,
    :time_resolution     => 1, #ns
    :sample_name         => "unknown",
    :t0                  => 0,
    :e0                  => 0,
    :total_runtime       => nil,
    :aquisition_date     => nil,
    :eventsum            => nil,
    :single_time_offset  => 0,
    :length_const        => 3438.0 # This is the calibrated value of the
                                   # short machine
  }

  #Create an TofMetaData instance. Examples
  # m = TofMetaData.new # creates an instance with default values
  # m = TofMetaData.new(:t0 => 270) #  creates an instance with default values,
  #                                    except for t0
  def initialize(opts = {})
    @values = DEFAULTS.merge(opts)
    #Create getters and setters for each value
    @values.each do |k,v|
      #getters
      self.class.send(:define_method, k, lambda {@values["#{k}".to_sym]})
      #setters
      self.class.send(:define_method, "#{k}=", lambda {|val| @values["#{k}".to_sym]=val})
    end
  end


  def each
    @values.each {|i| yield i}
  end

  #TODO: Borde trigger_type ändra lightsource_period automatiskt?
end

if __FILE__ == $0
  require "yaml"
  puts TofMetaData.new(:t0 => -22, :comments => "Enkelt test").to_yaml
end
