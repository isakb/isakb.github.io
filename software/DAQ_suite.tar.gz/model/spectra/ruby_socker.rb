#require 'mathn'
#$:.unshift [".", "/opt/local/lib/ruby/1.8", "/opt/local/lib/ruby/1.8/i686-darwin8.9.1", "/opt/local/lib/ruby/site_ruby", "/opt/local/lib/ruby/site_ruby/1.8", "/opt/local/lib/ruby/site_ruby/1.8/i686-darwin8.9.1", "/opt/local/lib/ruby/vendor_ruby", "/opt/local/lib/ruby/vendor_ruby/1.8", "/opt/local/lib/ruby/vendor_ruby/1.8/i686-darwin8.9.1"]
#$:.flatten!
require "yaml"
require "gsl"
include GSL
class Fixnum

  def add(var)
    p "Warning obsolete" 
    self + var
  end

end
class Float

  def add(var)
    p "Warning obsolete"
    self + var
  end

end


class Array
  #method to display contents of Array
  def look
    self.each do |i|
      if i.kind_of?(Array)
        print "["
        i.each {|j| print "[ #{j} ]"}
        print "]\n"
      else
        puts "[ #{i} ]"
      end
    end
    true
  end
  def minus!(var)
    p "Warning obsolete"
    puts "Use .add! instead"
    self.collect!{|i| i-var}
  end
  def multiply(var)
    p "Warning obsolete"
    self.collect{|i| i*var}
  end
  def multiply!(var)
    p "Warning obsolete"
    self.collect!{|i| i*var}
  end
  alias :mul :multiply
  alias :mul! :multiply!


  def sum
    inject( nil ) { |sum,x| sum ? sum+x : x.to_f } # added .to_f
                                                # to avoid summing arrays
                                        #instead of taking the sum of the array!

  end
  def mean
      sum.to_f / self.size
  end
  def add(var)
    p "Warning obsolete"
  #Assumes we are dealing with numbers
    if var.is_a?(Array)
      if var.length==self.length
        sum = Array.new
        self.each_index{|k| sum[k] = self[k]+var[k]}
        return sum
      else
      raise "Arrays do not have same length"
      end
    elsif var.kind_of? Numeric
      self.map{|i| i+ var}
    else
      raise "Could not add var to Array"
    end
  end
  def add!(var)
  #Assumes we are dealing with numbers
    if var.is_a?(Array)
      if var.length==self.length
        #sum = Array.new
        self.each_index{|k| self[k] = self[k]+var[k]}
        #self=sum
      else
      raise "Arrays do not have same length"
      end
    elsif var.kind_of? Numeric
      self.map!{|i| i+ var}
    else
      raise "Could not add var to Array"
    end
  end

end

# Serialization support

# A yaml utility routine to make the output prettier
# http://snowplow.org/martin/narray/narray-yaml.rb
module YAML
  class YIArray < Array
    yaml_as "tag:yaml.org,2002:seq"
    def to_yaml_style; :inline; end
  end

  def YAML.inline_array(arr)
    if Array === arr[0] then
      arr.map {|s| inline_array(s)}
    else
      YIArray.new.concat(arr)
    end
  end
end

class GSL::Vector
  def length
    self.len
  end

  # Add support for Marshal
  def _dump(depth)
    #Convert to array
    Marshal.dump(self.to_a)
  end

  def Vector._load(obj)
    #Convert back to GSL::Vector
    Marshal.load(obj).to_gslv
  end

  # Add support for YAML
    yaml_as("tag:usxs.fysik.uu.se,2007:tof/gsl::vector")
    def to_yaml( opts = {} )
      YAML::quick_emit( self.object_id, opts ) do |out|
        out.map(taguri) do |map|
          map.add('data', YAML::inline_array(to_a))
        end
      end
    end

    def self.yaml_new(klass, tag, val)
      result = Vector.alloc val['data']
    end
end
class GSL::Histogram
    def _dump(depth)
        #convert to vectors
        ranges = Vector.alloc self.range
        values = Vector.alloc self.bin
        Marshal.dump([ranges,values])
    end
    def Histogram._load(obj)
        a = Marshal.load(obj)
        ranges,values = a[0..1]
        h = Histogram.alloc ranges
        values.each_index do |i|
            h.increment( (ranges[i] + ranges[1+i])/2.0 , values[i] )
        end
        h
    end
end
class GSL::Histogram2d
    def _dump(depth)
        #convert to vectors
        xranges = Vector.alloc self.xrange
        yranges = Vector.alloc self.yrange
        values = Vector.alloc self.bin
        Marshal.dump([xranges, yranges,values])
    end
    def Histogram2d._load(obj)
        a = Marshal.load(obj)
        xranges, yranges,values = a[0..2]
        h = Histogram2d.alloc xranges, yranges
        nx = xranges.len - 1
        ny = yranges.len - 1
        i=0
        0.upto nx-1 do |x|
            0.upto ny-1 do |y|
                h.increment(xranges[x..x+1].mean, yranges[y..y+1].mean, values[x+y+i])
            end
            i+= ny-1
        end
        h
    end
end

#class Tof_1Dhist
    ##Marshals an Tof_1Dhist object.
    ##NB! Any file connected to the Tof_1Dhist object is lost
    #def _dump(depth)
        ##we save only the histogram data and throw away the File
        #hist = @h
        #Marshal.dump(hist)
    #end

    ##Unmarshals an Marshalled Tof_1Dhist object and returns it
    ##NB! Any file connected to the Tof_1Dhist object is lost
    #def Tof_1Dhist._load(obj)
        #hist = Marshal.load(obj)
        #Tof_1Dhist.new(hist)
    #end
#end

#class Tof_2Dhist
    ##Marshals an Tof_2Dhist object.
    ##NB! Any file connected to the Tof_2Dhist object is lost
    #def _dump(depth)
        ##we save only the histogram data and throw away the File
        #hist = @h
        #Marshal.dump(hist)
    #end

    ##Unmarshals an Marshalled Tof_2Dhist object and returns it
    ##NB! Any file connected to the Tof_2Dhist object is lost
    #def Tof_2Dhist._load(obj)
        #hist = Marshal.load(obj)
        #Tof_2Dhist.new(hist)
    #end
#end

# marshal the whole irb session!
# call with list = loval_variables
# to do: make it work
def save_irb_session(list)
    my_irb_session={}
    rejected_list = []
    list.each do |var|
    # p var


       if eval(var).respond_to? "_dump"
            my_irb_session[var] = eval(var)
       else
           rejected_list << var
       end
    end
    p "The following objects vere rejected:", rejected_list
  Marshal.dump my_irb_session
end
