#require 'mathn'
require "gsl"
class Fixnum

	def add(var)
		self + var
	end

end
class Float

	def add(var)
		self + var
	end

end


class Array
	#method to display contents of Array
	def look
		self.each do |i|
			if i.kind_of?(Array)
				print "["
				i.each {|j| print "[ #{j} ]"}
				print "]\n"
			else
				puts "[ #{i} ]"
			end
		end
		true
	end
	def minus!(var)
		puts "Use .add! instead"
		self.collect!{|i| i-var}		
	end
	def multiply(var)
		self.collect{|i| i*var}		
	end
	def multiply!(var)
		self.collect!{|i| i*var}		
	end
	def sum
		inject( nil ) { |sum,x| sum ? sum+x : x.to_f } # added .to_f
																								# to avoid summing arrays
																				#instead of taking the sum of the array!

	end	
	def mean
			sum.to_f / self.size
	end
	def add(var)
	#Assumes we are dealing with numbers
		if var.is_a?(Array)
			if var.length==self.length
				sum = Array.new
				self.each_index{|k| sum[k] = self[k]+var[k]}
				return sum
			else
			raise "Arrays do not have same length"
			end
		elsif var.kind_of? Numeric
			self.map{|i| i+ var}
		else
			raise "Could not add var to Array"
		end	
	end
	def add!(var)
	#Assumes we are dealing with numbers
		if var.is_a?(Array)
			if var.length==self.length
				#sum = Array.new
				self.each_index{|k| self[k] = self[k]+var[k]}
				#self=sum
			else
			raise "Arrays do not have same length"
			end
		elsif var.kind_of? Numeric
			self.map!{|i| i+ var}
		else
			raise "Could not add var to Array"
		end	
	end
	
end
class GSL::Vector
	def length
		self.len
	end

	def _dump(depth)
		#Convert to array
		Marshal.dump(self.to_a)
	end

	def Vector._load(obj)
		#Convert back to GSL::Vector
		Marshal.load(obj).to_gslv
	end
end
class GSL::Histogram
    def _dump(depth)
        #convert to vectors
        ranges = Vector.alloc self.range
        values = Vector.alloc self.bin
        Marshal.dump([ranges,values])
    end
    def Histogram._load(obj)
        a = Marshal.load(obj)
        ranges,values = a[0..1]
        h = Histogram.alloc ranges
        values.each_index do |i|
            h.increment( (ranges[i] + ranges[1+i])/2.0 , values[i] )
        end
        h
    end
end
