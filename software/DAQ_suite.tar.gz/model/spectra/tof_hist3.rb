require "ruby_socker"
require "gsl"
require 'tempfile'
require 'tof_save.rb'
require "tof_gnuplot"
require 'tof_1d_hist' # 1D histogram class

include GSL
#include GSL::Histogram - Changed wrapper from ruby/gsl to rb-gsl

# The Tof_2Dhist provides an interface for the 2d histogram in the gsl package. It also handles data storage and  prints to a file in a format that gnuplot understands. Histograms can be made with uniform spacing or with a polynomial and subsets of the histogram may be retrieved. The variable @h is an gsl::histogram and gsl methods may be called by calling +h.gslhistmethod+
class Tof_2Dhist
    include Tof_gnuplot
    
    DEFAULT_BINNING = 270
   
    def initialize(data, bin_spec=nil,file_path=nil, \
                 spacing = "uniform")#, histogram_script="gsl")
        #puts "New Tof_2Dhist object with #{spacing} spacing"
        #create a tmpfile and save data into it
        if file_path==nil
                @tmpfile=Tempfile.new("tof_hist_data_for_gnuplot")
                #@path =@tmpfile.path 
        else
                #create file 
                @tmpfile=File.new(file_path,"w+")
                #@path = file_path
        end
        
        @h=nil #the histogram
        #p bin_spec
        bin_spec = nil if bin_spec == [] 
        if bin_spec
            #create histogram and add data
            check_binspec( data, bin_spec, spacing)
        elsif data
            #guess bin_spec and add data
            guess_binspec(data)
        else
            raise ArgumentError, "You must specify at least data or bin_spec", caller
        end
    end
    attr_accessor :h #when the necessary methods are defined this can be removed
    
    def path
        @tmpfile.path
    end
    
    #Plots the histogram using gnuplot.
    def plot
        p "plotting 2Dhist" if $DEBUG
        save_as_file
        rgb="21,22,23"
        cmd = "set pm3d map  \n set palette rgbformulae #{rgb} \n"
        cmd += "splot \"#{path}\" using 1:3:5\n"
        cmd(cmd)
    end
    
    def xrange
        @h.xrange
    end
    
    def yrange
        @h.yrange
    end
    
    def nx
        @h.nx
    end
    
    def ny
        @h.ny
    end
    
    def xmax
        @h.xmax
    end
    def ymax
        @h.ymax
    end
    def xmin
        @h.xmin
    end
    def ymin
        @h.ymin
    end
    def xbins # alias for #nx
        @h.nx
    end
    def ybins
        @h.ny
    end
    
    def reset
    	@h.reset
    end
    
    def bin_spec
        [xmin,xmax,ymin,ymax,xbins,ybins]
    end
    
    #Returns the sum of the elements. Negative values are included.
    def sum
        @h.sum
    end
    
    def eqv_binspec?(other)
        if other.is_a?(Array)
            if other.length == 6
                return other == bin_spec
            elsif other.length == 4
                return [xmin, xmax, ymin, ymax] == other        
            end
        elsif other.respond_to? "bin_spec"
            return bin_spec == other.bin_spec
        else
            raise TypeError, "Expected array or Tof_2DHist", caller
        end
    end
    
    def eqv_range?(other)
        if other.is_a?(Array)
            return other == [xrange, yrange]
        elsif other.respond_to? "xrange"
            return [xrange(), yrange()] == [other.xrange, other.yrange]
        else
            raise TypeError, "Expected Array or Tof_2DHist", caller
        end
    end
    
    
       
        
	def ==(o)
	    return false unless o.class == self.class 
        if eqv_binspec?(o.bin_spec)
            return @h.bin == o.h.bin
            #each_with_indices do |val,i,j|
                #return false if val != o[i,j]
            #end
            #return true
        end
        return false
	end

	def -(o)
		if o.kind_of? Numeric
			h2 = Tof_2Dhist.new(nil, [xrange(), yrange()])
			self.each_with_ranges do |val,rx, ry| 
				h2.increment(rx, ry, val -o)
			end
		elsif o.kind_of?  Tof_2Dhist
			if eqv_range?( o ) #    eqv_binspec?(o.bin_spec)
				h2 = Tof_2Dhist.new(nil, [xrange(), yrange()])
				self.each_with_indices do |val,i,j | 
					rx, ry = @h.get_xrange(i).mean, @h.get_yrange(j).mean
					h2.increment(rx, ry, val - o[i,j])
				end
			else
				raise IndexError,"Histograms do not have same ranges", caller
			end
		elsif o.class==GSL::Histogram2d  
			raise TypeError,"unsupported"
		else
			raise TypeError, "unknown format"
		end
		h2
	end	
	
	def +(o)
        self.-(-o)
    end

	def *(o)
		if o.kind_of? Numeric
			h2 = Tof_2Dhist.new(nil, [xrange, yrange])
			self.each_with_ranges do |val,rx, ry| 
				h2.increment(rx, ry,val*o)
			end
		else
			raise TypeError, "unsupported format", caller
		end
		h2
	end

    def /(o)
        if o.kind_of? Numeric
            self.*(1.0/o)
        else
            raise TypeError, "unsupported format", caller
        end
    end

    
    
    def uniform_ranges?
        r = Vector.alloc xrange
        r2 = r.duplicate
        r2.shift
        r.pop
        r3 = r-r2
        if  (r3-r3[0]).sum.abs < r3[0].abs/1e10
            r = Vector.alloc yrange
            r2 = r.duplicate
            r2.shift
            r.pop
            r3 = r-r2
            return (r3-r3[0]).sum.abs < r3[0].abs/1e10
        else
            return false
        end
    end
    
    # extracts a sub-2dhistogram. The limits/ranges are inclusive
    # i.e. extracting the xrange 0 to 2 from a histogram with x-binning
    # [0,1), [1,2), [2,3)  incudes all the three bins.
    #
    #changed to The lower limit is closed, the upper open
    def sub(*ranges)
            ranges.flatten!
            xrange,yrange = ranges[0..1], ranges[2..3]
            # alias of 
            return extract_rectangular_sub_histogram(xrange,yrange)
    end
    
 #    Selects a subset of the histogram, keeping the resolution.
    def extract_rectangular_sub_histogram_old(xrange,yrange)
            puts "  extract_rectangular_sub_histogram"
            # has not been tested properly        
            
            raise(RuntimeError , "Not implemented for non-uniform histograms", caller) unless uniform_ranges?
      
            #h is the original histogram
            
            #find the indices, catch out of range, this solution is ugly
            # the binsize is constant I suppose this breaks down for neagtive numbers
            s = @h.get_xrange(@h.nx-1)
            xbinsize = s[1] - s[0]
            s = @h.get_yrange(@h.ny-1)
            ybinsize = s[1] - s[0]
            
            
            if xrange[0] < @h.xmin
                puts "   Warning: xmin out of range"
                xrange[0] = @h.xmin#+xbinsize * 0.001 # it would be nicer to just set the index to zero
            end
            if xrange[1] > @h.xmax
                puts "   Warning: xmax out of range"
                #puts xrange[1] , @h.xmax
                xrange[1] = @h.xmax - xbinsize * 0.001
            end
            if yrange[0] < @h.ymin
                puts "   Warning: ymin out of range"
                yrange[0] = @h.ymin #+ ybinsize * 0.001
            end
            if yrange[1] > @h.ymax
                puts "   Warning: ymax out of range"
                yrange[1] = @h.ymax - ybinsize * 0.001
            end
                       
            # if min > max for x or y it will crash
            
            min = @h.find(xrange[0],yrange[0])        
            max = @h.find(xrange[1],yrange[1])        
            #find the corresponding ranges
            xbin_min = @h.get_xrange(min[0]).min
            xbin_max = @h.get_xrange(max[0]).max
            ybin_min = @h.get_yrange(min[1]).min
            ybin_max = @h.get_yrange(max[1]).max

            #No of bins
            range = (max.add( min.multiply(-1))) # verkar vara dags att fixa en b�ttre syntax
            #instanciate new histogram
            
            puts max
            puts min
            range.look
            
            h2 = Histogram2d.alloc(range[0]+1, range[1]+1)## Hist2Dnew(range[0]+1, range[1]+1) #not tested!
            
            h2.set_ranges_uniform(xbin_min, xbin_max,ybin_min, ybin_max)
            #Add data
            # equivalent to for-loops
            min[0].upto(max[0]) do |i|
                    min[1].upto(max[1]) do |j|
                        #puts "i,j = #{i} #{j}"
                        #puts 
                        var= @h.get(i,j)
                        x_val = @h.get_xrange(i).mean
                        y_val = @h.get_yrange(j).mean
                        #puts x_val, y_val
                        h2.accumulate(x_val,y_val,var)
                end
            end
            #puts h2.class
            #return Tof_2Dhist object
            h3 = Tof_2Dhist.new(h2)
            return h3
        #else
            
        #end
    end
    
    def extract_rectangular_sub_histogram(xranges,yranges)
        #1. check ranges
        #2. find ranges from old hist
        #3. copy values
        #1.
        xm, xM = xranges[0], xranges[1] 
        ym, yM = yranges[0], yranges[1] 
        #2.
        xm = xmin if xm < xmin
        ym = ymin if ym < ymin
        ixm = @h.find(xm,ym)[0]
        iym = @h.find(xm,ym)[1]
        begin
            ixM = @h.find(xM,ym)[0]
            #did the user ask for the limit xM or inside a bin?
            ixM +=1 if xM > @h.get_xrange(ixM)[0]
        rescue GSL::ERROR::EDOM
            ixM = @h.nx
        end
        begin
            iyM = @h.find(xm,yM)[1]
            iyM +=1 if yM > @h.get_yrange(iyM)[0]
        rescue GSL::ERROR::EDOM
            iyM = @h.ny
        end

        # ranges are inclusive, see comment for sub method
        xranges = xrange().to_a[ixm..(ixM)] 
        yranges = yrange().to_a[iym..(iyM)]
        #p xranges, yranges
        #3.
        raise ArgumentError, "The histogram with the selected ranges contain no bin", caller if (ixm ==ixM or iym == iyM)
        h2 = Histogram2d.alloc(xranges, yranges)
        h3 = Tof_2Dhist.new(h2)
        #h3.each_with_indices do |val, ix, iy|
           # #find the corresponding index in @h
            #ix += ixm
            #iy += iym    
            #value = @h[ix,iy]
            #rx = @h.get_xrange(ix).mean
            #ry = @h.get_yrange(iy).mean
            #h3.increment(rx,ry, value)
        #end
        
        ixm.upto(ixM-1) do |i| 
            iym.upto(iyM-1) do |j| 
                value = @h.get(i,j)
                rx = @h.get_xrange(i).mean
                ry = @h.get_yrange(j).mean
                
                h3.increment(rx,ry, value)
            end
        end
        
        h3
    end
    def save_as_file(output_path=nil)
            #puts "  save_as_file"
            #myarr= convert_gsl_hist_to_gnuplot_format
#                save_gsl_hist_in_gnuplot_format
            @h.fprintf path                
            #puts myarr.size
            #save to file
#                if output_path == nil
#                        output_path = @path
#                 end
#                 #        output_path="tof_hist_output.txt"
#                 puts "saved as #{output_path}"
#                 save_asciifile(myarr.transpose, output_path, header="", columnNames="")
#                 return output_path
    end
        
    # Adds data to the histogram. Despite the name the data is not
    # ordered in a queue. The data can be of the formats
    # * Array - in the form [[x1, x2, x3], [y1, y2, y3]]
    # * Tof_2Dhist
    # * GSL::Histogram2d
    # * nil - Nothing is added
    def push(data)
        if data
            if data.class == Array
                    v0=Vector.alloc data[0]
                    v1=Vector.alloc data[1]
                    @h.increment v0,v1
            elsif data.class == self.class
                data.each_with_ranges do |val, rx, ry|
                    increment( rx, ry, val)
                end
            elsif data.class == GSL::Histogram2d 
                0.upto(data.nx-1) do |i| 
                    0.upto(data.ny-1) do |j| 
                        val , rx, ry = data.get(i,j), data.get_xrange(i).mean, data.get_yrange(j).mean
                        increment( rx, ry, val)
                    end
                end
            else
                raise TypeError, "Expected Array of the form [[x1,x2,x3], [y1,y2,y3]]", caller
            end
        end
    end
        
    def increment(*args)
        @h.increment(*args)
    end
    
    def [](i,j)
        @h[i,j]
    end
    
    def get_xrange(i)
        @h.get_xrange(i)
    end
    
    def get_yrange(i)
        @h.get_yrange(i)
    end
    
    #Returns a 1d histogram by projecting on the x-axis.
    #If +bins+ is specified the returned histogram will have uniform spacing    
    def project_on_x(m=nil,xM=nil,bins=nil)
            if m or xM or bins
                m = xmin unless m
                xM = xmax unless xM
                #Check if ranges are ok
                if m < xmin
                    puts "   Warning: min out of range"
                    m =xmin
                end
                if xM > xmax
                    puts "   Warning: max out of range"
                    xM =xmax
                end
                
                min = @h.find(m,ymin)[0]
                max = @h.find(xM*0.999, ymin)[0]
                
                if bins #does not support non-uniform hist
                    #bins = max  - min +1 unless bins
                    
                    #no_out_of_range =0        

                    hist  = Histogram.alloc(bins)##Hist.new(bins)
                    hist.set_ranges_uniform(m,xM)
                    
                    #project        
                    min.upto(max) do |i|
                        a=0
                        coord = @h.get_xrange(i).mean
                        0.upto(ybins-1) do |j|
                            #puts @h.get(j,i)
                            #puts i,j
                            a += @h.get(i,j)
                        end
                        #puts "#{i} : #{a}"
                        begin
                            hist.accumulate(coord,a)
                        rescue RangeError  ##don't know what error rb-gsl will throw!!
                            #do nothing
                            #no_out_of_range+=1
                        end    
                    end
                    #puts "  #{no_out_of_range} data points were out of range"
                else
                    hist = @h.xproject(min,max)
                end
            else
                hist = @h.xproject
            end            
            x_proj = Tof_1Dhist.new(hist)
            
        end

    #Returns a 1d histogram by projecting on the y-axis.
    #If +bins+ is specified the returnde histogram will have uniform spacing    
    def project_on_y(ym=nil,yM=nil,bins=nil)
        if ym or yM or bins
            ym = ymin unless ym
            yM = ymax unless yM
            #Check if ranges are ok
            if ym < ymin
                puts "   Warning: min out of range"
                ym =ymin
            end
            if yM > ymax
                puts "   Warning: max out of range"
                yM =ymax
            end
            
            min = @h.find(@h.xmin,ym)[1]
            max = @h.find(@h.xmin, yM*0.999)[1]
            if bins
            #    bins = max  - min +1 unless bins
                no_out_of_range =0        

                hist  = Histogram.alloc(bins)##Hist.new(bins)
                hist.set_ranges_uniform(ym,yM)
                
                #project        
                min.upto(max) do |i|
                    a=0
                    coord = @h.get_yrange(i).mean
                    0.upto(xbins-1) do |j|
                        #puts @h.get(j,i)
                        a += @h.get(j,i)
                    end
                    #puts "#{i} : #{a}"
                    begin
                        hist.accumulate(coord,a)
                    rescue RangeError
                        #do nothing
                        no_out_of_range+=1
                    end    
                end
                puts "  #{no_out_of_range} data points were out of range"  
             else
                hist = @h.yproject(min,max)
            end
        else
            hist = @h.yproject
        end                    
        y_proj = Tof_1Dhist.new(hist)
    end
        
    
    #Yields the value of each bin	
	def each
		0.upto(xbins-1) do |i| 
		    0.upto(ybins-1) do |j| 
			    yield @h.get(i,j)
			end
		end
	end
    
    
    def each_with_indices
        0.upto(xbins-1) do |i| 
            0.upto(ybins-1) do |j| 
                yield @h.get(i,j),i,j
            end
        end
    end
    alias :each_with_indeces :each_with_indices
    
    def each_with_ranges
        0.upto(xbins-1) do |i| 
            0.upto(ybins-1) do |j| 
                yield @h.get(i,j), @h.get_xrange(i).mean, @h.get_yrange(j).mean
            end
        end
    end
    
    #Rescales the histogram by the expression given in the block,
    #i.e h.rescale{|z| z**2} replaces all the bin values by their 
    #squares
    def rescale! # this has turned out to be slow
        h2=Histogram2d.alloc(xbins,ybins)
        h2.set_ranges_uniform(xmin, xmax, ymin, ymax)
        each_with_ranges{|var,x,y| h2.increment(x,y, yield(var))}
        @h=h2
    end
    alias :rescale :rescale!
    
    def look
        each_with_indices{ |v,i,j| p "#{v} at #{i},#{j}"}
    end
    
    #Marshals an Tof_2Dhist object.
    #NB! Any file connected to the Tof_2Dhist object is lost
    def _dump(depth)
		Marshal.dump([@h, path])
	end
	
	#Unmarshals an Marshalled Tof_2Dhist object and returns it
    #NB! Any file connected to the Tof_2Dhist object is lost
	def Tof_2Dhist._load(obj)
		hist, old_path = Marshal.load(obj)
		p "This Tof_2Dhist object had the following path", old_path
		Tof_2Dhist.new(hist)
	end
    
    
private 

    def check_binspec( data, bin_spec, spacing)
        #bin_spec = [] if bin_spec == nil
        #check if uniform or given ranges
        if bin_spec.length ==2 or spacing != "uniform"
            #check that the bin_spec is alright and construct uneven histogram
            xrange, yrange = bin_spec
            xrange = Vector.alloc xrange
            yrange = Vector.alloc yrange
            @h= Histogram2d.alloc(xrange, yrange)
        else
            # we assume that at least xmin-ymax are specified and sensible
            xm, xM, ym, yM, xbin,ybin = bin_spec
            # if xbin and ybin are unspecified we must guess
            xbin = ybin = DEFAULT_BINNING unless xbin
            @h = Histogram2d.alloc(xbin, ybin)
            @h.set_ranges_uniform(xm, xM, ym, yM)
        end
        push(data)
    end
    
    def guess_binspec(data)
        #if data is of type histogram we are done!
        if data.class == GSL::Histogram2d
            @h=data
            return
        elsif
            data.class == self.class
            @h=data.h
            return
        end
        
        # calculate data limits, the max limits are increased 
        # to include the maximum values
        xM, yM = data.collect {|i| i.max}.mul(1.01)
        xm, ym = data.collect {|i| i.min}
        # fall back on default binning
        xbin = ybin = DEFAULT_BINNING
        @h = Histogram2d.alloc(xbin, ybin)
        @h.set_ranges_uniform(xm, xM, ym, yM)
        push(data)
    end
        
        ##To do: Drop support for     histogram_script, implement or drop spacing
         #def make_2d_histogram(data, bin_spec=nil, spacing="uniform")# histogram_script="gsl", spacing="uniform")
            ##Gives the possibility to choose between perlscript or gsl to compute\
            ##     histogram, default number of bins is 270 x 270
            #bin_spec = nil if bin_spec==[] or bin_spec==[nil]
            #if bin_spec==nil 
                    #max_x=max_y=min_x=min=y=xbin=ybin=nil
            #elsif bin_spec.length ==2 or spacing != "uniform"
                ##check that the bin_spec is alright and construct uneven histogram
                #xrange, yrange = bin_spec
                #xrange = Vector.alloc xrange
                #yrange = Vector.alloc yrange
                #@h= Histogram2d.alloc(xrange, yrange)
                #push(data)
                #return             
            #elsif bin_spec.length ==4
                #xbin=ybin=nil
                #min_x ,max_x, min_y, max_y = bin_spec
                    
            #elsif bin_spec.length == 6
                ##error check?
                #min_x ,max_x, min_y, max_y, xbin,ybin = bin_spec
            #else
                #puts "bin_spec= [min_x, max_x, min_y,max_y, binx = nil,biny =nil ]"
                #puts 'or nil for default'
                #raise "Wrong number of arguments." 
                ##max_x=max_y=min_x=min=y=binx=biny=nil
            #end
            
            #if max_x==nil
                ## calculate data limits
                #max_x, max_y = data.collect {|i| i.max}.add!(0.1)
                ##p data[1].size, data[1].class
                ##max_x = data[0].max.add 0.1
                ##max_y = data[1].max.add 0.1
                ##puts "max"
                ##puts max_x 
                ##puts max_y
            #end
            #if min_x ==nil
                #min_x, min_y = data.collect {|i| i.min}.add!(-0.0)
                #puts "#{min_x} min_x"
            #end
        
            ##maximum no of bins
            #if data.class == Array
                #length = data.collect {|i| i.length}.max
            #else
                #length = 0
            #end 
            #if xbin ==nil
                    #if length > 270*10 
                        ## find a binsize. Needs some more thinking
                        
##                                    xbin = (max_x - min_x).round #200-2#270
##                                    if xbin < 100
##                                            if xbin *2<100
##                                                xbin*= 2
##                                            end
##                                            xbin *=2
##                                    elsif xbin >300
##                                            if xbin/2 >300
##                                                    #To do: handle this 
##                                                    xbin /= 2
##                                            end
##                                            xbin /=2
##                                    end
                        #xbin = 270
                    #else
                        #xbin = 200#length/5
                    #end
            #end
            #if ybin ==nil
                    #if length > 270*10 
                        #ybin = 270
                    #else
                        #ybin = 200#length/5
                    #end
            #end
##                        puts "spec"
##                        bin_spec.look
            #bin_spec = [min_x, max_x, min_y, max_y,xbin,ybin] 
            ##output_path = make_2d_histogram_gls(data,bin_spec, spacing)
            #make_2d_histogram_gls(data,bin_spec, spacing)
            ##return output_path
        #end

        #def make_2d_histogram_gls(data,bin_spec, spacing="uniform")
            #puts "make 2d hist gls"
                ##@path = "myoutp"##############################################
                ##puts "bin_spec #{bin_spec.look}"
                #xm,xM,ym,yM,xbins,ybins = bin_spec
                #xm, xM = [xm, xM].sort
                #ym, yM = [ym, yM].sort
                #puts "bin_spec:"
                #bin_spec.look
                ##@bin_spec= bin_spec
                ##instanciate histogram
                #@h = Histogram2d.alloc(xbins, ybins)##Hist2D.new(xbins,ybins)
                ## set spacing
                #if spacing == "uniform"
                        #puts "   using uniform spacing"
                        #@h.set_ranges_uniform(xm, xM, ym, yM)
                #elsif spacing == "quadratic"
                        ## For the energies an equal spacing of the bins resuts in stripes since the limited resolution of the times is reflected in the possible energies. Below is a qd solution that makes the spacing quadratic. A better solution migth be to use a polynomial of second order. (B�rjade jobba p� detta p� datorn hemma.) For the times it is better to use a linear (uniform) spacing
                        #puts "   using quadratic spacing"
                        #xranges = Array.new
                        ##ranges[0] = xm
                        #for i in 0..xbins
                                #xranges[i] = i**2/(xbins.to_f)**2 * (xM-xm) + xm
                        #end
                        #yranges = Array.new
                        ##ranges[0] = xm
                        #for i in 0..ybins
                                #yranges[i] = i**2/(ybins.to_f)**2 * (yM-ym) + ym
                        #end
                
                        ##puts "xr, yr"
                        ##xranges.look
                        ##yranges.look
                        #@h.set_ranges(xranges, yranges)
                #end
                
                #push(data)                
        #end
            
        
        
##         def convert_gsl_hist_to_gnuplot_format()
##                 puts "  convert_gsl_hist_to_gnuplot_format"
##                 #get output from h - it must be possible to get it directly (via IOstr?)
##                 arr = Array.new
##                 begin
##                         #puts "opening pipe to get the histogram"
##                         #fread, fwrite = IO.pipe#("myfile","w")
##                         # piping doesn't work for large files, using the tmpfile instead
##                         #this seems risky and not very elegant
##                         begin
##                             f=File.open(@path,"w")
##                             @h.fprintf(f, "%g", "%g")
##                         ensure
##                             f.close
##                         end
##                         
##                         puts "#{@path}"
##                         puts "reading"
##                         dummy= Array.new
##                         @tmpfile.rewind
##                         @tmpfile.each do |line|
##                                 dummy = line.chomp.split( )
##                                 arr.push( dummy)
##                         end
##                         
##                         arr.collect! {|i| i.collect! {|j| j.to_f}} 
##                 end
##                 
##                 puts "convert to gnuplot format"
##                 #arr = get_arrays_within_array(arr,5) #want to keep newlines
##                 arr.map! do |i|
##                     unless i.empty? #newline? 
##                             [ (i[0] + i[1])*0.5 , (i[2] + i[3])*0.5, i[4] ]
##                     else
##                             [nil, nil, nil]
##                     end
##                 end
##                 puts "finished converting"
##                 #puts "+++"
##                 #arr.look
##                 return arr
##     end
    def save_gsl_hist_in_gnuplot_format() # not working yet!
        #set up xrange
        range = Vector.alloc @h.xrange
        range2= range.duplicate
        range.shift
        range2.pop
        xrange = (range+range2)/2
        #set up yrange
        range = Vector.alloc @h.yrange
        range2= range.duplicate
        range.shift
        range2.pop
        yrange = (range+range2)/2
        #retrieve bins
        bins = Vector.alloc @h.bin
        
        #we want to save in this format
        # xr1 yr1 b1
        # xr2 yr2 b2
        # .........
        s=""
        for i in 0...xrange.len
            s+= "#{xrange[i]}\t#{yrange[i]}\t#{bins[i]}\n"            
        end
        File.open(path, "w") do |file| 
            file.write s
        end
        return path
    end

      
        
end 

