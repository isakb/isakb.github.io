class CorruptDataError < RuntimeError; end
#class TimeConst
class EmptyDatasetError < RuntimeError; end
class FileNotFoundError < LoadError; end