 
require 'ruby_socker'
require "observer"

class BasicSpectrum
	include Observable
	#Last modified X
	def initialize(spectrum=nil,label=nil)
		@spectrum = Array.new 
		@label = label
		@spectrum = spectrum
	end	
	attr_accessor :spectrum, :label
end

class TofSingles < BasicSpectrum
	def initialize(singles=nil,\
									ring_period=nil,\
									exc_energy = nil,\
									t_max=nil, \
									run_no=nil ,\
									sample_name=nil, \
									path=nil,\
									t0=273, e0=0,\
									total_runtime=nil,\
									min_time_diff=nil,\
									label=nil)
									
		super(singles,label)
		@t_max = t_max
		@total_runtime = total_runtime
		@run_no = run_no
		@sample_name = sample_name
		@path = path
		@t0 = t0 
		@e0 = e0
		@lightsource_period = ring_period
		@excitation_energy = exc_energy
		@min_time_diff = min_time_diff
		# implement in initialize call?
		@length_const =  3438.0#3390.0
		@single_time=[]
		@single_energy=[]
		@single_energy_varied_binsize=[]
	end
	# fill in
	attr_reader :total_runtime, :run_no, :sample_name,:t0, :e0,:length_const
	attr_accessor :spectrum, :spectrum_length,  :path, :excitation_energy
	attr_writer  :spectrum_length
	
	def single_time
		#f�rv�ntar man sig inte att f� INTENSITETEN som fn av tiden? G�r om till ett tidshistoram!
		if @single_time==[]
			puts 'Assuming times = 0...@lightsource_period'
			times = (0...@lightsource_period).to_a
			raise "@length_const (D) must be a float." unless @length_const.is_a?(Float)
			times.map!{|i| i-@t0}
			
			lowest_time = @length_const/ Math.sqrt(@excitation_energy)
			puts lowest_time 
			counter=0
			@single_time = times.map do |i| 
	 			if i <= lowest_time
	   				i+= @lightsource_period
	   				counter+=1
	 			end
	 			i.to_f
			end
			puts "no_changed_singles = #{counter}"
		end
		#@spectrum
		return @single_time
	end

	#remove this fcn?
	def singles=(var)
		@spectrum = var
		@single_time=[]
		@single_energy=[]
		@singel_energy_varied_binsize=[]
	end
	
	def single_energy_varied_binsize
		if 	@single_energy_varied_binsize==[]
			#Use 1d histogram to store data
			#Set the time resolution to �0.5 * [time resolution]
			res=(single_time[1] - single_time[0]) * 0.5
					#energy ranges for each time
			#puts res
			#ranges=[]
	
			#i=0
			#puts "i",i
			ranges = single_time.map do |i|
				@length_const**2/(i - res)**2 + @e0
			end
			#puts "i",i
			#the last entry
			ranges << @length_const**2/(single_time.last + res)**2 + @e0
			#ranges.reverse!
			#puts ranges #,"i",i
			#create a 1d hist object
			@single_energy_varied_binsize = Tof_1Dhist.new(nil, ranges.sort ,nil,"uneven")
			#add data
			0.upto(@spectrum.length-1) do |i|
				#the index should be be straightforward to find
			#	puts i,0.5*(ranges[i]+ranges[i+1])
				@single_energy_varied_binsize.h.accumulate(0.5*(ranges[i]+ranges[i+1]), @spectrum[i] )
			end
		end
		return @single_energy_varied_binsize
	end
	
	
	# Find run number and sample
	def to_s
		return "Spectrum: Run No #{@run_no} on #{@sample_name}"
	end
	
end

#class that includes double excitations	,and singles 
class TofDoubles < TofSingles
	def initialize (doubles=nil,\
									singles=nil,\
									ringperiod=nil,\
									exc_energy = nil,\
									t_max=nil, \
									run_no=nil ,\
									sample_name=nil, \
									path=nil,\
									t0=-273, e0=0,\
									total_runtime=nil,\
									min_time_diff=nil,\
									label=nil)
		if label == nil and path != nil
			#path =~ Regexp.new('\w*\/\w*\/\w*\.')
			label = ".../" + path.split("/").to_s   #$&.chop
		end
		
		
		super(singles,ringperiod ,exc_energy, t_max,run_no,sample_name, \
										path, t0, e0, total_runtime,min_time_diff, label)
		puts " + New TofDoubles object"
		#obsolete:								
		#@doubles = doubles #as pairs [[fast, slow]_0,[fast, slow]_1]
		@double_time = Array.new  #As a row of fast and a row of slow compensated for t0 and ringperiod
		@double_energy = Array.new
		#@doubles= Array.new
		@doubles = doubles
	end
	#attr_writer  :double_time, :double_energy  #, :doubles
	
	def t0=(new_t0)
		#when resetting t0, double_times and double_energy needs to be recalculated
		@double_time = []
		@double_energy = []
		@single_time = []
		@single_energy=[]
		@singel_energy_varied_binsize=[]
		
		changed  # note that our state has changed
   		notify_observers("time","energy")
		@t0 = new_t0
	end
	def e0=(new_e0)
		#when resetting e0, ?double_times? and double_energy needs to be recalculated
		#@double_time = []
		@double_energy = []
		@single_energy=[]
		@singel_energy_varied_binsize=[]
		changed  # note that our state has changed
   		notify_observers("energy") #("time","energy")
		@e0 = new_e0
	end
	
	
	
	def double_time
		if @double_time == []
			@double_time[0] = doubles_fast.collect{|doubles| (doubles - @t0) }
			@double_time[1] = doubles_slow.collect{|doubles| (doubles - @t0) }
			# put the times on a scale that goes beyond ringperiod (relevant for data from Elands program where the data is saved mod ringp) and make sure that the second electron always comes after the first
			no_changed_pairs = 0
			double_t=@double_time.transpose
			#Electrons with an energy above the excitation energy are moved to next ringp
			# (otherwise use pair[0] < 0 for times below zero) 
			lowest_time = @length_const/ Math.sqrt(@excitation_energy)# - @e0)
			#puts lowest_time
			double_t.map! do |pair|
					if pair[0] < lowest_time
						pair.add! [@lightsource_period, @lightsource_period ]
						no_changed_pairs +=1
					end
					pair
				end
			puts "no_changed_pairs = #{no_changed_pairs }"
			@double_time=double_t.transpose
		end
		return @double_time
		
	end
	def doubles_fast
		fast = @doubles[0] #.collect
		#fast = @doubles.collect {|i| i[0]}
	end
	def doubles_slow
		slow = @doubles[1] #.collect
		#slow = @doubles.collect {|i| i[1]}
	end
	def total_double_energy
		self.double_energy.transpose.map{|i| i.sum}
	end
	
	
	def double_energy
		#"@double_energy = @length_const**2/(double_time-t0)**2"
		if @double_energy ==[]
			puts "  calculating energies"
			#handle case where t=0, there should be a faster way of doing this...
			double_t = double_time
			#puts "rr"
			
			no_of_zeroes=0
			double_t[0].collect! do |i| 
				if i ==0
					no_of_zeroes+=1
					i=1 
				end
				i
			end
			double_t[1].collect! do |i| 
				if i ==0
					i=1 
				end
				i
			end
			puts "number of zeroes = #{no_of_zeroes}"
			puts "WARNING!!!: lengthconst is not a float!" unless @length_const.is_a?(Float)
			
			@double_energy[0] = double_t[0].collect {|i| @e0 + @length_const**2 \
																															/( i)**2}
																															
			@double_energy[1] = double_t[1].collect {|i| @e0 + @length_const**2 \
																													/( i)**2}	
			#no of e that are too fast																						
			no=Array.new
			no = [0,0]
			for i in 0...@double_energy[0].length
				if @double_energy[0][i] > @excitation_energy
					@double_energy[0][i] = -1	
					no[0] += 1
					
				end
			end
			for i in 0...@double_energy[1].length
				if @double_energy[1][i] > @excitation_energy
					@double_energy[1][i] = -1
					no[1] += 1
				end
			end
			puts "no of e that are too fast [#{no[0]},#{no[1]}]"
		#	puts @double_energy[0][15].is_a?(Float)
		#puts @double_energy[1][15].is_a?(Float)
		#puts @double_energy[0][15].is_a?(Float)
		#@double_energy.look
		end
		
		return @double_energy
	end
	#put "!" on function names below?
	def select_sub_double_time(xrange, yrange)
		#make sure there is data (@double_time may be nil)
		data = double_time
		@double_time =  select_sub(data, xrange, yrange)
		@double_energy = []
		changed  # note that our state has changed
   		notify_observers("time","energy")
	end
	def select_sub_double_energy(xrange, yrange)
		data = double_energy
		@double_energy =  select_sub(data, xrange, yrange)
		changed  # note that our state has changed
   		notify_observers("energy")
	end
	def deselect_sub_double_time(xrange, yrange)
		data = double_time
		@double_time =  deselect_sub(data, xrange, yrange)
		@double_energy = []
		changed  # note that our state has changed
   		notify_observers("time","energy")
	end
	
	def select_sub_tot_e_vs_e2(xrange, yrange)
		#This fcn is different from the others since it returns the new values rather than changing an instance variable
		data = [double_energy[1] ,total_double_energy]
		
		changed  # note that our state has changed
   		notify_observers("total energy")
   		return select_sub(data, xrange, yrange) 
	end
	
	def restore_energy
		@double_energy = []
		changed  # note that our state has changed
   		notify_observers("energy")
	end

	
	def restore_time
		@double_time = []
		changed  # note that our state has changed
   		notify_observers("time","energy")
   		puts "The time has been restored but not the energy nor t0"
	end
	
	def restore
		restore_time
		restore_energy
		puts "Time and energy restored"
		puts "NB! t0 is not restored"
	end

private
	def select_sub(data,xrange, yrange)
			#Add error checking of the ranges
	
			arr=Array.new
			puts "selecting part of spectrum"					
			arr = data.transpose.map{|pair|
				if xrange[0] <=pair[0] and pair[0] < xrange[1]
						if yrange[0] <= pair[1] and pair[1] < yrange[1]
								 #pair.look
								 #puts "--"
								 pair
						end
				end
				
			}
			#puts "selecting finished"
			arr.compact!
			puts "#{arr.length} elements in new list, #{data[0].length} elements in old."
			#arr.look
			#puts "2"
			return arr.transpose
			
	end
	def deselect_sub(data,xrange, yrange) 
			#Add error checking of the ranges
			#a=b=0
			old_length=data[0].length
			arr = Array.new
			puts "deselecting part of spectrum"					
			arr = data.transpose.map{|pair|
				if xrange[0] <=pair[0] and pair[0] < xrange[1] and
						 yrange[0] <= pair[1] and pair[1] < yrange[1]
								 #pair.look
								 #puts "--"
								 #a+=1
								 [nil,nil]
						#end
					#puts pair
					#pair
						
				else
				#b+=1
				pair
				end
			}
			#puts "selecting finished"
			arr.reject!{|i| i==[nil,nil]}
			#antagligen g�r det snabbare om man returnerar nil och sedan anv�nder compact!
			#arr.look
			data = arr.transpose
			puts "#{data[0].length} elements in new list, #{old_length} elements in old."
			#arr.look
			#puts "2"
			return data
			
	end
	
	

end

#class that includes even more electrons
#class ManyElectronSpectrum <DoubleElectronSpectrum
#end
