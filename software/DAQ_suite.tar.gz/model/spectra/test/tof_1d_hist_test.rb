# test/tof_1d_hist_test.rb
# run 'ruby -w tof_1d_hist_test.rb' to test the class Tof_1Dhist


$:.push File.join(File.dirname(__FILE__), '..', 'src')
#require File.join(File.dirname(__FILE__), '..', 'src', 'tof_1d_hist.rb')
require 'tof_1d_hist.rb'
require 'test/unit'


class Tof_1DhistTest < Test::Unit::TestCase
	  DATA = [1,2,4,5,6,7,8,9,10,1,1,5,9,9,9]
	  BINSPEC = [0,10,10]
	  EXPECTED_BINNING = [0.0, 3.0, 1.0, 0.0, 1.0, 2.0, 1.0, 1.0, 1.0, 4.0]

	  def setup   
	    @hist = Tof_1Dhist.new(DATA,BINSPEC)
	  end

	  def test_bin_spec
	    assert_equal BINSPEC, @hist.bin_spec
	  end

	  def test_each_with_index
	    bins= Array.new(@hist.bins)
	    @hist.each_with_index{|var,i| bins[i]=var}
	    assert_equal EXPECTED_BINNING, bins
	  end
	  
	  def test_push
	    hist = Tof_1Dhist.new(DATA,BINSPEC)
	    hist.push DATA
	    bins= Array.new(hist.bins)
	    hist.each_with_index{|var,i| bins[i]=var/2.0}
	    assert_equal EXPECTED_BINNING, bins
	  end
	  
	  def test_equal
	    hist = Tof_1Dhist.new(DATA,BINSPEC)
	    assert( hist==@hist)
	  end
	  
	  def test_no_data
	    h1 = Tof_1Dhist.new(nil,BINSPEC)
	    h1.push DATA
	    assert( h1==@hist)
	  end
	  
	  def test_must_specify_data_or_bin_spec
	    assert_raise(ArgumentError) { Tof_1Dhist.new()}
	  end
	  
	  def test_sum
	    assert_equal DATA.length-1, @hist.sum #10 is out of range
	  end
	  
	  def test_push
	    assert_raise(TypeError) {@hist.push "str"}
	    assert_nothing_raised{@hist.push(nil)}
	    assert_nothing_raised{@hist.push(100)}
	    
	    hist = Tof_1Dhist.new(nil,BINSPEC)
	    hist.push @hist
	    assert_equal(hist, @hist)
	    
	    hist = Tof_1Dhist.new(nil,BINSPEC)
	    hist.push @hist.h
	    assert_equal(hist, @hist)
	  
	  
	  end
	  
	  def test_uniform_ranges
	    assert @hist.uniform_ranges?
	  end
	  
	  def test_marshal
        require "ruby_socker"
	    str= Marshal.dump(@hist)
	    assert_equal(@hist , Marshal.load(str) )
	  end
	  

end
