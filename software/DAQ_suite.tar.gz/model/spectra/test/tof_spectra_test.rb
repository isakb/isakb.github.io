$:.push File.join(File.dirname(__FILE__), '..', 'src')

require 'tof_spectra.rb'
require 'test/unit'

#doubles=pairs,
#singles,  
#ringperiod = METADATA.ring_period,
#exc_energy = METADATA.exc_energy,
#t_max = METADATA.t_max,  
#run_no = METADATA.run_no ,
#sample_name = METADATA.sample_name, 
#file_path = file_path,
#t0= t0*-1,  
#e0 = 0.35,
#total_runtime = total_runtime,
#min_time_diff = nil, 
#label = nil)

class TofDoublesTest < Test::Unit::TestCase
    SINGLES = Vector.linspace(0,800,801)
    DOUBLES = nil
    METADATA= nil
   
   
    def setup 
        @spectrum = TofDoubles.new(DOUBLES,
                                  SINGLES)
                                  
                                    
        
        
    end


end
