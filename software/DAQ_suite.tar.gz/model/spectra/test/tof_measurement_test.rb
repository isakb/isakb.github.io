$:.push File.join(File.dirname(__FILE__), '..')

require 'tof_measurement.rb'
require 'test/unit'
require "gsl"
###### from     http://rubyisawesome.com/2007/4/6/object-bypass   #####
# This allows you to be a good OOP citizen and honor encapsulation, but
# still make calls to private methods (for testing) by doing
#
#   obj.bypass.private_thingie(arg1, arg2)
#
# Which is easier on the eye than
#
#   obj.send(:private_thingie, arg1, arg2)
#
class Object
  class Bypass
    instance_methods.each do |m|
      undef_method m unless m =~ /^__/
    end

    def initialize(ref)
      @ref = ref
    end

    def method_missing(sym, *args)
      @ref.__send__(sym, *args)
    end
  end

  def bypass
    Bypass.new(self)
  end
end
# Jämför flyttal
class Float
  def approx(other, relative_epsilon=Float::EPSILON, epsilon=Float::EPSILON)
    difference = other - self
    return true if difference.abs <= epsilon
    relative_error = (difference / (self > other ? self : other)).abs
    return relative_error <= relative_epsilon
  end
end

class TofBasicSpectrumTest < Test::Unit::TestCase


  def test_initialize_sets_getters
    m = TofBasicSpectrum.new(nil, {:a=> "a", :b=>"b"})
    assert_equal "a", m.a
    assert_equal "b", m.b
  end

  def test_initialize_sets_setters
    m = TofBasicSpectrum.new(nil, {:a=> "a", :b=>"b"})
    assert_equal "A", m.a="A"
    assert_equal "B", m.b="B"
  end

  def test_initializes_correct_defaults
    m = TofBasicSpectrum.new(nil, {:a=> "a", :b=>"b"})
    TofMetaData::DEFAULTS.each do |key, val|
      assert_equal val, m.send("#{key}")
    end
  end

  def test_initializes_new_values
    val1, val2 = 23, 24
    m = TofBasicSpectrum.new(nil, {:t0=> val1, :run_no => val2})
    assert_equal m.t0, val1
    assert_equal m.run_no, val2
    assert_equal m.e0,  TofMetaData::DEFAULTS[:e0]
  end

end


class TofBasicPePeMeasurementTest < Test::Unit::TestCase

  def test_initializes_to_correct_defaults
    m = TofPePeMeasurement.new()#{:a => 2})
    #glass box test
    assert_equal(  {:doubles=>nil, :triples=>nil, :singles=>nil},
              m.bypass.instance_variable_get("@raw_data")  )
    TofMetaData::DEFAULTS.each do |key, val|
          assert_equal val, m.send("#{key}")
    end
  end

  def test_initializes_new_values
    val1, val2 = 23, 24
    m = TofPePeMeasurement.new(nil, {:t0=> val1, :run_no => val2})
    assert_equal m.t0, val1
    assert_equal m.run_no, val2
    assert_equal m.e0,  TofMetaData::DEFAULTS[:e0]
  end

  def test_calc_single_times_small_dataset
    t0 = 0 # t0 is assumed to be included in the hist
    p  = 107 #ns
    hist = [0,1,3,5,2,1,7] #(100..107 ns)
    m = TofPePeMeasurement.new({:singles => hist}, {:t0=> t0,
                                                #:lightsource_period => p,
                                                :single_time_offset => 100,
                                                :t_max => 107
                                                })
    #get the histogram
    res = m.single_time.to_a[0...hist.length]
    assert_equal(res , (hist).to_a)
  end

  def test_calc_single_times_bigger_dataset
    t0 = 0 # t0 is assumed to be included in the hist
    p  = 107 #ns
    hist = [-1,1,3,5,2,1,7] #(100..107 ns)
    100.times {hist.unshift 0}
    m = TofPePeMeasurement.new({:singles => hist}, {:t0=> t0,
                                                #:lightsource_period => p,
                                                :single_time_offset => 0,
                                                :t_max => 107
                                                })
    #get the histogram
    res = m.single_time.to_a#[0...hist.length]
    #range of lowest element
    r = m.single_time.get_range(0).mean
    r = r.to_i
    #p m.single_time.bin_spec
    #m = TofMetaData.new
    #lowest_time = m.length_const.to_f/ Math.sqrt(m.excitation_energy)
    r.upto(hist.size-1) do |i|
      #p "i=#{i}"
      a, b = res[i-r] , hist[i]
      #p " a, b = #{a}, #{b}"
      assert_equal(a, b)
      range =  m.single_time.get_range(i-r).mean
      assert_equal range, i
    end

  end

  def test_calc_single_times_data_below_lowest_energy
    t0 = 0 # t0 is assumed to be included in the hist
    p  = 107 #ns
    hist = [-1,1,3,5,2,1,7] #(100..107 ns)
    100.times {hist.push 0}
    m = TofPePeMeasurement.new({:singles => hist}, {:t0=> t0,
                                                :lightsource_period => p,
                                                :single_time_offset => 0,
                                                #:t_max => 107
                                                :time_resolution => 1
                                                })
    #get the histogram
    res = m.single_time.to_a#[0...hist.length]
    #range of lowest element
    r = m.single_time.get_range(0).mean
    r = r.to_i
#   p res
#   p m.single_time.bin_spec
    0.upto(r-1) do |i|
      j = p-r + i
      #p "i, j = #{i}, #{j}"
      a, b = res[j] , hist[i]
      #p " a, b = #{a}, #{b}"
      assert_equal(a, b)
      range =  m.single_time.get_range(j).mean
      #p range - 134
      assert range.approx(i+p)
    end
  end

  def test_error_when_no_singles_data
    m = TofBasicPePeMeasurement.new
    assert_raises(EmptyDatasetError){m.single_time}
  end

  def test_error_when_no_doubles_data
    m = TofBasicPePeMeasurement.new
    assert_raises(EmptyDatasetError){m.double_time}
  end

  def test_error_when_too_long_singles_data
    m = TofBasicPePeMeasurement.new({:singles => GSL::Vector.alloc( 100)}, {:lightsource_period => 10})
    assert_raises(CorruptDataError){m.single_time}
  end


  def test_single_energy
    #p "energy"
    time_scale = GSL::Vector.linspace(100,110,11)
    intensities = [1,3,5,7,8,9,11, 2, 4, -1,-5]
    m = TofPePeMeasurement.new({:singles => intensities}, {:t0=> 0,
                                                    :lightsource_period => 800,
                                                    :single_time_offset  => time_scale[0],
                                                    :t_max => 111,
                                                    :time_resolution => 1
                                                    })
    result =  m.single_energy
    t = m.single_time
    expected_energies = m.time_to_energy(time_scale).reverse
    expected_energies.each_index do |j|
      nrj = expected_energies[j]
      i = result.find( nrj)
      assert_equal intensities.reverse[j], result[i]
    end
  end
  
  def test_single_energy_compensated
    #p "energy comp"
    time_scale = GSL::Vector.linspace(100,110,11)
    intensities = [1,3,5,7,8,9,11, 2, 4, -1,-5]
    m = TofPePeMeasurement.new({:singles => intensities}, {:t0=> 0,
                                                    :lightsource_period => 800,
                                                    :single_time_offset  => time_scale[0],
                                                    :t_max => 111,
                                                    :time_resolution => 1
                                                    })
    result =  m.single_energy_varied_binsize_compensated_intensities
    # m.single_energy_varied_binsize.look
    #     m.single_energy_varied_binsize.bins.times{|i| p m.single_energy_varied_binsize.get_range(i).diff}
    #     exit
    #result.plot
    # m.single_energy_varied_binsize.plot
    t = m.single_time
    expected_energies = m.time_to_energy(time_scale).reverse
    rel_diff = []
    expected_energies.each_index do |j|
      nrj = expected_energies[j]
      i = result.find( nrj)
      r = result.get_range(i)
      width = r[1] - r[0]
      rel_diff[j] =  [intensities.reverse[j]/ result[i]*width ]
    end
      
  end

end


class TofPePeMeasurementTest < Test::Unit::TestCase
  def update(*args)
   # p "u"
   @u =  args
  end

  def test_restore
    @u = nil
    m = TofPePeMeasurement.new
    m.add_observer(self)
    m.restore
    assert @u
    @u = nil
    m.e0 = 1
    assert @u
    @u = nil
    m.restore
    assert @u
  end

  def test_restoring_t0_restores_singles_spectrum
    @u = nil
    m = TofPePeMeasurement.new({:singles => GSL::Vector.linspace(0,100,51)}, {:singles_time_offset => 100})
    spec1 = m.single_time
    m.add_observer(self)
    t0 = m.t0
    m.t0 = 1
    assert @u
    assert_not_equal spec1, m.single_time
    @u = nil
    m.t0 = t0
    assert @u
    assert spec1 == m.single_time
  end

end