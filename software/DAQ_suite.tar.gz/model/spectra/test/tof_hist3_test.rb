$:.push File.join(File.dirname(__FILE__), '..')

require 'tof_hist3.rb'
require 'test/unit'


class Tof_1DhistTest < Test::Unit::TestCase
    LINE_1 = [1,3,5,7]
    LINE_2 = [9,11,13,17]
    LINE_3 = [19,23,29,37]
    
    XMIN = 0
    XMAX = 4
    BINS = 4
    RES = 1
    UNIFORM_RANGE_1 = linspace(XMIN,XMAX,5)
    UNIFORM_RANGE_2 = linspace(0,3,4)

    INCREASING_RANGE_1 = [0,1,2,4,8]
    INCREASING_RANGE_2 = [0,3,6,12]
    
    
    l1= [0, 1,1,1, 2,2,2,2,2, 3,3,3,3,3,3,3]
    l1y = []
    l1.length.times {l1y.push(0)}
    l2 = []
    LINE_2.each_with_index{|item, i| item.times {l2.push( UNIFORM_RANGE_1[i] ) } }
    l2y =[]
    l2.length.times {l2y.push(1)}
    
    l3 = []
    LINE_3.each_with_index{|item, i| item.times {l3.push( UNIFORM_RANGE_1[i] ) } }
    l3y =[]
    l3.length.times {l3y.push(2)}
    
    DATA_X = [l1,l2,l3].flatten!
    DATA_Y = [l1y,l2y,l3y].flatten!
    DATA = [DATA_X, DATA_Y]
    
    BINSPEC = [XMIN, XMAX, 0, 3, BINS, 3 ]
    
    
    #expected binning:
    BINNING_STR = "" +
    "2-3   |     19     23       29      37     \n" +
    "1-2   |     9      11       13      17     \n" +
    "0-1   |     1      3        5       7      \n" +
    "      |----------------------------------  \n" +
    "            0-1     1-2     2-3     3-4    \n" 
  
  
    BINNING = Matrix.alloc( LINE_1, LINE_2, LINE_3 ) 


    def setup   
        @hist = Tof_2Dhist.new(nil,[UNIFORM_RANGE_1, UNIFORM_RANGE_2])
        @hist2 = Tof_2Dhist.new(nil,[INCREASING_RANGE_1, INCREASING_RANGE_2])
        #fill with test data
        #iterate over y
        yrange=[]
        0.upto(@hist.ybins-1) do |j|
            yrange[j] =  @hist.get_yrange(j).mean
        end
        #iterate over x
        0.upto(@hist.xbins-1) do |i| 
            rx=@hist.get_xrange(i).mean
            @hist.increment(rx,yrange[0], LINE_1[i])
            @hist.increment(rx,yrange[1], LINE_2[i])
            @hist.increment(rx,yrange[2], LINE_3[i])
    end

        #same thing for hist2
        yrange=[]
        0.upto(@hist2.ybins-1) do |j|
           yrange[j] =  @hist2.get_yrange(j).mean
        end
        #iterate over x
        0.upto(@hist2.xbins-1) do |i| 
            rx=@hist2.get_xrange(i).mean
            @hist2.increment(rx,yrange[0], LINE_1[i])
            @hist2.increment(rx,yrange[1], LINE_2[i])
            @hist2.increment(rx,yrange[2], LINE_3[i])
        end
    end
    
    def test_bin_spec
	    assert_equal BINSPEC, @hist.bin_spec
    end
    
    def test_create_using_binspec
        h= Tof_2Dhist.new(DATA, BINSPEC)
        assert_equal h , @hist
    end
    
    def test_binning
        # the each method iterates over y as the innner loop
        # i.e the column of BINNING
        expected = []
        BINNING.each_col {|i| expected << i.to_a}
        expected.flatten!
        
        binning=[]
        @hist.each {|i| binning << i}
        assert expected == binning
        #p expected, binning
        
    end
    
    def test_sub
        # test to take a sub off all
        # (sub limits are inclusive (or closed) ) 
        h = @hist.sub BINSPEC
        assert_equal h, @hist
        
        #test too large limits
        h = @hist.sub [-1,100,-1,100]
        assert h== @hist
        
        
        h = @hist.sub [1,2,1,2]
        binning=[]
        h.each {|i| binning << i}
        assert_equal binning , [11]
        
        h = @hist.sub [1,2.1,1,5]
        binning=[]
        h.each {|i| binning << i}
        assert_equal binning , [11,23,13,29]
        
        #p "---------------"
        #h = @hist.sub [2,4,1,2]
        #h.look
        #p "++++++++++++++++++"
        assert_raise(ArgumentError) {@hist.sub [3,3,1,2]}
        #h.look
         #p "++++++++++++++++++"
        #h = @hist.sub [0,1.5,1,2]
        #h.look
        #assert true
        #puts BINNING_STR
    end

    #def test_each_with_index
        #bins= Array.new(@hist.bins)
        #@hist.each_with_index{|var,i| bins[i]=var}
        #assert_equal EXPECTED_BINNING, bins
    #end
	  
	  
	  def test_no_data
	    h1 = Tof_2Dhist.new(nil,BINSPEC)
	    h1.push(DATA)
	    #h1.look
	    assert_equal( h1, @hist)
	  end
	  
	  def test_unequal
	    assert_equal(false, @hist == @hist2)
	  end
	  
	  def test_must_specify_data_or_bin_spec
	    assert_raise(ArgumentError) { Tof_2Dhist.new()}
	  end
	  
	  #def test_sum
	    #assert_equal DATA.length-1, @hist.sum #10 is out of range
	  #end
	  
	  def test_push
	    assert_raise(TypeError) {@hist.push "str"}
	    assert_nothing_raised{@hist.push(nil)}
	    assert_nothing_raised{@hist.push([100,100])}
	    
	    hist = Tof_2Dhist.new(nil,BINSPEC)
	    hist.push @hist
	    assert_equal(hist, @hist)
	    
	    hist = Tof_2Dhist.new(nil,BINSPEC)
	    hist.push @hist.h
	    assert_equal(hist, @hist)
	  end
	  
	  def test_uniform_ranges
	    assert @hist.uniform_ranges?
	  end
	  
	  def test_marshal
        require "ruby_socker"
	    str= Marshal.dump(@hist)
	    assert_equal(@hist , Marshal.load(str) )
	  end


end
