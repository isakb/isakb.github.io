require "tof_spectra.rb"
require "gsl"
include GSL
# TofDoubles arguments
#doubles=nil,\
#singles=nil,\
#ringperiod=1000000,\
#exc_energy = nil,\
#t_max=nil, \
#run_no=nil ,\
#sample_name="", \
#path=nil,\
#t0=-273, e0=0,\
#total_runtime=nil,\
#min_time_diff=nil,\
#label=nil


class DynamicTof2DHist < Tof_2Dhist
    
    #returns the data to plot as a string(!)
    def plotdata
        #there must be a better way for this but for testing it should work
        #save_as_file()
        #v= Vector.filescan(path())
        #x = ( ( v[0] + v[1] )/2.0 ).to_a
        #y = (( v[2] + v[3] )/2.0 ).to_a
        #val = ( v[4] ).to_a
        #m =Matrix.alloc x,y,z
        data=""
        #p "open dtafile"
        #f = File.open(path,"r") 
        #str=f.readlines
        ##p str
        #f.close
        #p "closed file"
        #str
        p Time.now
        p bin_spec
        #Mimic each_with_ranges
        0.upto(xbins-1) do |i| 
            0.upto(ybins-1) do |j| 
                data +="#{@h.get(i,j)} #{@h.get_xrange(i).mean} #{@h.get_yrange(j).mean}\n"
            end
            data += "\n"
        end
        
        #each_with_ranges do |xr, yr, val|
            #data += "#{xr} #{yr} #{val}\n"
        #end
        p Time.now
        data
    end
end
#singles_spec = [start, end] (resolution is given by internal constant)
#doubles_spec = [t1_start, t1_end, t2_start, t2_end]
class DynamicTofSpectrum < TofDoubles
    include Tof_gnuplot
    
    attr_accessor :singles_spec, :doubles_spec, :plot_dynamic
    
    def initialize(  singles_spec,
                    doubles_spec,
                    exc_energy, #
                    multiples_spec=nil, 
                    length_const =  3438.0, 
                    ringperiod=1000000,
                    run_no=nil , #
                    sample_name="",  #
                    path=nil,
                    t0=-273, e0=0, ##
                    total_runtime=nil,
                    min_time_diff=nil,
                    label=nil)
        
        #save parameters
        
        @singles_spec = singles_spec
        @doubles_spec = doubles_spec
        @length_const = length_const.to_f
        
        #parameters for TofDouble
        single_time_starts_at = @singles_spec[0]
        t_max = @singles_spec[1]
        
		# set up singles, we need a vector with zeroes
        singles = Vector.alloc( @singles_spec[1] - @singles_spec[0] +0).to_a
        
        # Doubles need not to be set up but w'll have to catch errors if
        #we try to plot empty arrays
        doubles = []
        
        #Structure for dynamic spectra
        dynstrukt = Struct.new(:double_time, :double_energy, :tot_e_vs_e2, :active)
        
        #The double time hist
        @dynamic = dynstrukt.new(DynamicTof2DHist.new(nil, @doubles_spec) )
        

                    
        super(  doubles,
                singles,
                ringperiod,
                exc_energy ,
                t_max,
                run_no,
                sample_name,
                path,
                t0, e0,
                total_runtime,
                min_time_diff,
                label,
                single_time_starts_at)
                
        #call to initialize
        single_time
        
        #The double energy hist
        r=@dynamic.double_time.xrange
        p r
        xranges = time_to_energy(r)
        r=@dynamic.double_time.yrange
        yranges = time_to_energy(r)
        @dynamic.double_energy = DynamicTof2DHist.new(nil, [xranges.reverse, yranges.reverse] )
        #fixa: lämplig uplösning för tot_e_vs_e2
        @dynamic.tot_e_vs_e2 = DynamicTof2DHist.new(nil,[yranges.min, yranges.max,
                            yranges.min + xranges.min, yranges.max+ xranges.max, 150,150]  )
    
        
        #testing: make time hist active
        @dynamic.active = @dynamic.double_time
        
        #set up plot
        cmd "set pm3d map corners2color c1"
        cmd "set term x11"
        cmd "unset key"
        #no plot unless user opens widget
        @plot_dynamic=false
        
        #try to use x11 as gnuplot terminal
        #@doubles_time_hist.cmd "set term x11"
        @single_time.cmd "set term x11"
        
        
    end
#----------------------------singles
    
    #start off by creating a vector of zeroes to set up the singles-times
    #then add data using a push method
    
    #should data be buffered?
    #en fördel är att man slipper räkna ut saker som kan visa sig tunga
    #en nackdel är att programmet kan hacka till när det laddar in en stor buffer
    #-vi väntar med buffrar så länge
    
    
    #increments the time histogram at the specified times.
	# push_singles(560) will increase the bin at 560 by one.
	# MAYBE!-push_singles(560, 5) will increase the bin at 560 by five.
	# NO! push_singles([560,580],[1,4]) will increase the bin at 560 by one and 580 by four.
	# push_singles(1dhist) will increase by using the 1dhist.
	def push_singles(args)
		@single_time.push args
		
		#update energy array?, set it to []?
		#@updated= 
	end
	
	#expecting [[fast], [slow]]
	def push_doubles(fast_and_slow)
	    #1. save into spectrum
	    #2. push into histgram for plotting
	    #2b. push inte energy histograms
	    
	    #1.
	    p "push D"
	    fast = Vector.alloc fast_and_slow[0]
	    slow = Vector.alloc fast_and_slow[1]
	    unless @double_time ==[]
            @double_time[0] += fast
            @double_time[1] += slow
	    else
            @double_time= [fast, slow]  
        end
        #2.
        p "D..."
        #@doubles_time_hist.push [fast, slow]
        @dynamic.double_time.push [fast, slow]
        p "D....."
        #2b
        e1, e2 = time_to_energy(fast), time_to_energy(slow)	
        @dynamic.double_energy.push [e1, e2]
        p "D......."
        e_tot = e1 + e2
        @dynamic.tot_e_vs_e2.push [e2, e_tot]
        
        
	end
	
	def clear #skriv om det är för klumpigt!
		
		#@doubles_time_hist.reset
		@dynamic.each{|histogram| histogram.reset}
		@double_time=[]
		@single_time.reset
		#call to initialize
        #single_time

		changed  # note that our state has changed
   		notify_observers("time","energy")
   		p "cleared spectra"
	end
    
    def active=(arg)
        case arg
        when /single time/
            p "not implemented"
        when "double time"
            @dynamic.active = @dynamic.double_time
        when /double energy/
            @dynamic.active = @dynamic.double_energy
        when /tot_e vs e2/
            @dynamic.active = @dynamic.tot_e_vs_e2
        else
            p "not implemented"
        end
    end
    
    def active
        p "not implemented"
    end
    
    def plot_active
        return false unless @plot_dynamic
        p "plot Active"
        cmd "splot \'-\' u 1:3:5"
        begin
            @dynamic.active.h.fprintf @gnu_pipe
        rescue
            p  "Error when plotting", $!
            p @gnu_pipe.closed?
        end
        cmd "e"
        p "sent e"
    end



end
