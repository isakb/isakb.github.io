require "metadatastruct"

#Johns program sparar data på olika sätt. Här är ett försök att räkna
#ut viket program av GTAUGER 5-7 som skapat filerna och läsa in dem.
class TofFile
  class << self
    def load_all_files(path)
      #assume version 5
      Gtauger5Load.load_all_files(path)
    end
  end
end

class GtaugerLoadAbstract
  class << self
    #Parses measurement info saved by the GTAUGER*.BAS program in ".PAR" files.
    #The PAR-file contains metadata of the measurment.
    #The method will take away any file anding in -file_path- and add .PAR.
    #Hence the method can be called with any file ending and it will still lok for a .PAR file.
    #Returns an TofMetaData instance
    def load_PAR_new(file_path)


      # the PAR - file has the following data. Default values are specified in the Metadatastruct.
#      #Run Number
#      run_no = -1
#      #Excitation energy
#      exc_e = 10000
#      #Target molecule
#      sample_name = ""
#      #jt0 - t0
#      t0 = -270 # this is since the PAR-file and gtauger.bas uses this sign convention
#      #totdur -
#      total_runtime =nil
#      #date
#      time = nil
#      #eventsum
#      eventsum =nil

      metadata = TofMetaData.new

      # check if there is a PAR - file
      # construct path
      file_path_PAR = file_path.split('.')
      file_path_PAR.pop
      file_path_PAR = file_path_PAR.join('.') + ".PAR"

      if File.exist?(file_path_PAR)
        File.open(file_path_PAR,"r") do |file|
          begin
            puts "  Reading PAR-file"
            #Run Number
            metadata.run_no = file.gets.to_i
            #Excitation energy
            metadata.excitation_energy = file.gets.to_f
            #Target molecule
            metadata.sample_name = file.gets.chomp
            #jt0 - t0
            metadata.t0 = file.gets.to_f
            #totdur -
            metadata.total_runtime = file.gets.to_f
            #Date
            date = file.gets.split("-")
            # rearrange to day-month-year
            day = date[1]
            date[1]=date[0]
            date[0]=day
            #time
            time = file.gets.split(":")
            #create array with the date and time
            time = date.reverse + time
            #NB! This assumes that the current time-zone equals the time zone of the measurment
            time = Time.local(*time)
            metadata.aquisition_date = time

            #puts time
            #Eventsum
            metadata.eventsum = file.gets.to_i



          rescue
            p $!, caller
            raise LoadError, "Error reading PAR file"
          end
        end #do
      else
        puts "Could not find #{file_path_PAR}: The PAR-file stores info about the spectrum"
      end#if file exists
      return metadata
    end

    def load_PAR(file_path)
      # the PAR - file has the following data
      #Run Number
      run_no = -1
      #Excitation energy
      exc_e = 10000
      #Target molecule
      sample_name = ""
      #jt0 - t0
      t0 = -270 # this is since the PAR-file and gtauger.bas uses this sign convention
      #totdur -
      total_runtime =nil
      #date
      time = nil
      #eventsum
      eventsum =nil

      # check if there is a PAR - file
      # construct path
      #file_path =~ Regexp.new('\.')
      file_path_PAR = file_path.split('.')
      file_path_PAR.pop
      file_path_PAR = file_path_PAR.join('.') + ".PAR"

    #  file_path_PAR = $`
    #  file_path_PAR += ".PAR"
      if File.exist?(file_path_PAR)
          File.open(file_path_PAR,"r") do |file|
            begin
              puts "  Reading PAR-file"
              #Run Number
              run_no = file.gets.to_i
              #Excitation energy
              exc_e = file.gets.to_f
              #Target molecule
              sample_name = file.gets.chomp
              #jt0 - t0
              t0 = file.gets.to_f
              #totdur -
              total_runtime = file.gets.to_f
              #Date
              date = file.gets.split("-")
              # rearrange to day-month-year
              day = date[1]
              date[1]=date[0]
              date[0]=day
              #time
              time = file.gets.split(":")
              #create array with the date and time
              time = date.reverse + time
              #NB! This assumes that the current time-zone equals the time zone of the measurment
              time = Time.local(*time)
              #puts time
              #Eventsum
              eventsum = file.gets.to_i



            rescue
              raise "Error reading file"
            end
          end #do
        else
          puts "Could not find #{file_path_PAR}: The PAR-file stores info about the spectrum"
          #[-1,-1,-1,-1,-1,-1,-1]
          #return false
        end#if file exists

        return [run_no, exc_e, sample_name, t0, total_runtime, time, eventsum]



    end


    def load_SPC(file_path)
      puts "* load_SPC"
      #Add error checking!
      arr = self.load_spectrum_from_file(file_path)
      arr=self.get_arrays_within_array(arr).flatten!
      # the first line contains the maximum time
      t_max = arr[0]
      #delete the first line
      arr.shift
      #check if the length is correct
      unless arr.length ==t_max
        raise LoadError( "Wrong length of singles spectrum")
      end
      return arr, t_max
  end


    def load_PRS(file_path)
      #puts "load_doubles"
      #Add error checking!
      arr=load_spectrum_from_file(file_path)
      arr = get_arrays_within_array(arr,2)
      arr= arr.transpose
      # Some of Johns programmes saves pairs as t2, t1 instead of t1,t2.
      # We want ascending duration
       p arr[0].size
      if arr[0][0] > arr[1][0]
          a= arr[0]
          arr[0]=arr[1]
          arr[1]=a
      end
      # elementary error checking
      unless arr[0].length ==arr[1].length
        raise LoadError, "File containing the doubles is corrupt"
      end
      arr
    end

    #Loads triples from the specified path, usually *.SAN
    def load_triples(path)
      arr=load_spectrum_from_file(file_path)
      arr = get_arrays_within_array(arr,3)
      arr= arr.transpose
      # Some of Johns programmes saves pairs as t2, t1 instead of t1,t2.
      # We want ascending duration
      arr.sort!

      # elementary error checking
      unless arr[0].length ==arr[1].length
        raise LoadError, "File containing triples is corrupt"
      end
      arr
    end



    def load_spectrum_from_file(file_path) # this is too slow!
      # !!!This can be improved by using GSL::Vector.filescan(filename) !!!
      puts "* load_spectrum_from _file"
      #Last modified 20 feb 2007
      arr=Array.new
      #test if file exists ? It is perhaps better to raise an error instead?
      if File.exist?(file_path)
        File.open(file_path,"r") do |file|
          begin
            dummy= Array.new
            file.each do |line|
              dummy = line.chomp.split( )
              arr.push( dummy)
            end
            #convert to floats!
            #NB! Does not check what the file contains

            #It would be good to rewrite this to check for
            #the content of each line (using regexp). Currently all text
            # including comments beginning with an # are loaded
            # as zeroes(!)
            arr.collect! {|i| i.collect! {|j| j.to_f}}
            #print to console
            #arr.each {|i| puts "[ #{i} ]"}
          return arr
          rescue
            raise LoadError, "Error reading file"
          end
        end
      else
        puts "Error: The file #{file_path} does not exist"
        raise FileNotFoundError
      end
    end

    #Selects the subarrays in the array ARR which themselves have the
    #length WANTED_LENGTH, returs an empty array if no elements can be found
    def get_arrays_within_array(arr, wanted_length=1)
        puts "  get_arrays..."
      newarr=Array.new
      newarr=arr.select {|i| i.length == wanted_length }
    end

  end
  end
#end

#Loads the files created by the GTAUGER5.BAS program
class Gtauger5Load < GtaugerLoadAbstract
  class << self
    #Loads the spectrum of the electron pairs (stored in ".PRS" -files) and
    #loads the run-parameters from the ".PAR" file with the same name in the
    #same directory. If no ".PAR"-file is found a t0 of 270 ns is assumed.
    #The data is stored in an TofDoubles object which is returned
    def load_all_files(file_path)
      puts "* load_gtauger5"
      #Load the pair data
      #to do: check file ending
      basename = File.basename(file_path).split('.')
      dir = File.dirname(file_path)
        basename.pop
        basename = basename.join('.')
        basename = File.join(dir, basename)
        path1 =basename + ".SPC"
        path2=basename + ".PRS"
        p path2
      begin
        ring_p =1000000 #we ought to use t_max for this but this should work as well
        singles, ring_p =load_SPC(path1)
      rescue LoadError
        singles = nil
      end
      begin
        pairs=load_PRS(path2)
      rescue LoadError
        pairs = nil
      end
      raise NameError, "Measurement not found" if not pairs and not singles
      [singles, pairs]
    end


    def load_all_files_to_TofDoubles(file_path)
      singles , pairs = load_all_files(file_path)
      run_no, exc_e, sample_name, t0, total_runtime, time, eventsum = load_PAR(file_path)
      #puts "  Guessing ringperiod 800 ns, e0 0.35 eV" unless ring_p
      ring_p = 800
      mySpec=TofDoubles.new(doubles=pairs,
                singles,
                ringperiod = ring_p,
                exc_energy = exc_e,
                t_max = nil,
                run_no = run_no ,
                sample_name = sample_name,
                file_path = file_path,
                t0= t0*-1,
                e0 = 0.35,
                total_runtime = total_runtime,
                min_time_diff = nil,
                label = nil)
      return mySpec
    end

    def load_all_files_to_TofMeasurement(file_path)
      singles , pairs = load_all_files(file_path)
      metadata = load_PAR_new(file_path)
      mySpec= TofMeasurement.new({:singles => singles, :doubles => pairs}, metadata)
    end

  end
end


def load_gtauger5(file_path)
  puts "Please use Gtauger5Load.load_all_files_to_TofDoubles(path) instead!"
  Gtauger5Load.load_all_files_to_TofDoubles(file_path)
end


