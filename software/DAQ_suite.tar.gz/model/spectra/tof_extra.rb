#require "tof_spectra"
require "tof_measurement"
module Marshal
#  REMOVE_OBSERVERS_FROM_THEESE = [ TofSingles, TofBasicSpectrum ]
  class << self
    alias :olddump :dump
    def dump(obj,*args)
    if [ TofSingles, TofBasicSpectrum ].include? obj.class
#    if REMOVE_OBSERVERS_FROM_THEESE.include? obj.class
       observers = obj.instance_variable_get("@observer_peers").dup
       obj.delete_observers
    end
    s=olddump(obj,*args)
    observers.each{|i| obj.add_observer(i)} if [ TofSingles, TofBasicSpectrum ].include? obj.class
    s
    end
  end
end
