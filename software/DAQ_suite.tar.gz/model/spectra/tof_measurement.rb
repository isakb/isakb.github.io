#!/usr/bin/env ruby
me = File.dirname(__FILE__)
$: << me unless $:.include?(me) # pga eclipse

require 'ruby_socker'
require "observer"
require "gsl"
require "tof_extra"
require "metadatastruct"
require "tof_errors"
require "tof_1d_hist"
include GSL

#Handles raw data and basic file managment
class BasicSpectrum
  include Observable
  def initialize(data = {})
    @raw_data = data
    #Används den här?
    #@updated = true # is spectrum up to date?
  end

  def save_as_binary_file(path)
    File.open(path, "w") do |file|
    Marshal.dump(self,file)
  end

#  def save_as_yaml
#    #to do
#  end

end
  # To load file:
  #f = File.open("myfile")
  #spectrum=Marshal.load(f)
  #f.close

end

#Handles metadata
class TofBasicSpectrum < BasicSpectrum

  attr_accessor :metadata
  def initialize(data = {}, metadata = TofMetaData.new)
    #if the metadata isn't of class TofMetaData chances are that some of the
    # parameters need to bes set to their default values
    metadata = TofMetaData.new(metadata) unless metadata.kind_of? TofMetaData
    @metadata = metadata
    super(data)

    #Create getters and setters for the metadata entries
    @metadata.each do |k,v|
      # create the getter that returns the metadata variable
      self.class.send(:define_method, k, lambda {@metadata.send("#{k}")})
      # create the setter that sets the metadata variable
      self.class.send(:define_method, "#{k}=", lambda do |val|
        @metadata.send("#{k}=", val)
        #notify observers
        state_changed("time")# syntax may change later.
      end)
    end
  end



# def file_name
#    File.basename @path
#  end
#
#  def dirname
#    File.dirname @path
#  end


#    def length_const=(val)
#      @length_const=val.to_f
#    end
#
    # Find run number and sample
  def to_s
    return "Spectrum: Run No #{@run_no} on #{@sample_name}"
  end

  def time_to_energy(times)
    if times.respond_to?("**")
      energies = @metadata.length_const**2 / times**2 + @metadata.e0
    else
      energies = @metadata.length_const**2 / times.square + @metadata.e0
    end
  end
  private
  def state_changed(*args)
    changed
    notify_observers(*args)
  end
end

#Handles basic functionality such as calculating energies. No selection of sub-set etc
class TofBasicPePeMeasurement < TofBasicSpectrum
  # data defaults to {:singles => nil, :doubles => nil, :triples=> nil}
  # metadata defaults to TofMetaData.new. Ie the default values of the TofMetdData
  # class
  def initialize(data = nil, metadata = nil)
    data = data || {:singles => nil, :doubles => nil, :triples=> nil}
    metadata = metadata || TofMetaData.new
    super(data, metadata)
    @times = {:singles => nil, :doubles => nil, :triples=> nil}
    @energies = {}
  end

  #Returns a Tof_1Dhist containing the single times, compensated for t0
  def single_time
    unless @times[ :singles ]
      raise EmptyDatasetError, "No singles loaded!" unless @raw_data[ :singles ] # Another option is to return nil
      times = []
      time_zero= @metadata.single_time_offset.to_i
      t_max = @metadata.t_max || @metadata.lightsource_period
      #Möjlig bugg här. är osäker på om det skall vara ...t_max.
      times[0] =  (time_zero...(t_max)).to_a.collect{|i| i- @metadata.t0 }
      times[1] =  @raw_data[ :singles ].to_a
      #check if data length matches light-period
      period , datalen = times[0].size , times[1].size
      if period != datalen
        puts "Warning: The singles Array is shorter than specified!"
        #presumably the data is shorter. Else:
        raise CorruptDataError, "Single data excedes given lightsource period!" if period < datalen
        #dont't pad with zeroes - reduce the length of times[0] instead!
#        (period-datalen).times { times[1] << 0 }
        times[0] = times[0][0...datalen]
        t_max = times[0][-1]
      end
      #calculate how fast the electron can possibly be
      #counter=0
      times= times.transpose
      times.each do |pair|
         if pair[0] <= lowest_time
            pair[0] += @metadata.lightsource_period
       #     counter+=1
         end
      end
      #puts "no_changed_singles = #{counter}"

      #convert to histogram
      #We want to have 1 ns resolution (or specified) from the lowest time (given
      # by D/sqrt(hv) ) to the maxmum time given by the ring period + 1
      res = @metadata.time_resolution
      hres= res.to_f/2
      #We want to have a histogram that includes all measured times, but one that
      # isn't unnecessarily big. The lowest time:
      lt = [lowest_time.to_i, @metadata.single_time_offset.to_i].max
      #We don't really need the whole period if the data is shorter
      ringp = t_max
     min, max = lt - hres, lowest_time.to_i + ringp + hres
      bin_spec = [min, max, ((max-min)/res).to_i]
      @times[ :singles ] = Tof_1Dhist.new(nil, bin_spec)
      times.each do |pair|
        @times[ :singles ].increment( pair[0], pair[1])
      end
    end

    return @times[ :singles ]
  end

  #Returns a histogram with the single ionisation spectrum.
  # the sizes of the bins reflects the varying resolution (full resolution is kept)
  def single_energy_varied_binsize
    unless @energies[ :singles ]
      #Use 1d histogram to store data

      ranges = single_time.range.collect do |i|
        @metadata.length_const**2/(i)**2 + @metadata.e0
      end

      @energies[ :singles ] = Tof_1Dhist.new(nil, ranges.sort ,nil,"uneven")
      #add data
      single_time.each_with_ranges do |val,t|
        energy= time_to_energy(t)
        @energies[ :singles ].increment(energy, val)
      end
    end
    return @energies[ :singles ]
  end
  alias :single_energy :single_energy_varied_binsize
  #Egentligen vill man nog ha ett histogram antingen med fix binsize
  #(så att man ser korrekt intensitet) eller åtminståne kompensera för
  #storleken på binsen så att arean bevaras eller nåt sånt
  
  def single_energy_varied_binsize_compensated_intensities
    non_comp = single_energy_varied_binsize
    #normalize so that the middle bin keeps it's value
    middle_bin = non_comp.bins/2
    middle_range = non_comp.get_range(middle_bin)
    middle_width = middle_range[1] - middle_range[0]
    comp = Tof_1Dhist.new(nil, non_comp.range)
    non_comp.each_with_index do |val, index|
      range = non_comp.get_range(index)
      width = range[1] - range [0]
      comp.increment(range.mean, val*middle_width/width)
    end
    comp
  end
  #Returns an array containing two GSL::Vectors
  #[fast_electrons , slow_electrons]
  def double_time
    unless @times[ :doubles ]
     doubles = @raw_data[ :doubles ]
     t0 = @metadata.t0
     @times[ :doubles ] = [nil,nil]
     raise EmptyDatasetError, "No doubles loaded!" unless doubles  # Another option is to return nil
     @times[ :doubles ][0] = Vector.alloc doubles[0].collect{|fast| (fast - t0) }
     @times[ :doubles ][1] = Vector.alloc doubles[1].collect{|slow| (slow - t0) }
     # put the times on a scale that goes beyond ringperiod (relevant for
     # data from Eland's program where the data is saved mod ringp) and
     # make sure that the second electron always comes after the first
     #no_changed_pairs = 0
     #Electrons with an energy above the excitation energy are moved to next ringp
     # (otherwise use pair[0] < 0 for times below zero)
     t1 = @times[ :doubles ][0]
     t2 = @times[ :doubles ][1]
     lightsource_period = @metadata.lightsource_period
     p lightsource_period
     t1.each_index do |i|
       if t1[i] < lowest_time
         t1[i] += lightsource_period
         t2[i] += lightsource_period
         #no_changed_pairs +=1
       end
     end
     #puts "no_changed_pairs = #{no_changed_pairs }"
     end
     return @times[ :doubles ]
  end

  def lowest_time
    @metadata.length_const.to_f/ Math.sqrt(@metadata.excitation_energy)
  end

  #Returns an Array with two GSL::Vectors containing the energies
  # [fast, slow]
  def double_energy
    #"@double_energy = @length_const**2/(double_time-t0)**2"
    unless @energies[ :doubles ]
      puts "  calculating energies" if $DEBUG
      double_t = double_time
      @energies[ :doubles ] = []
      @energies[ :doubles ][0] = time_to_energy( double_t[0] )
      @energies[ :doubles ][1] = time_to_energy( double_t[1] )
    end
    return @energies[ :doubles ]
  end

  # Returns the total kinetic energy of each pair as a GSL::Vector
  def total_double_energy
    e1, e2 = double_energy[0..1]
    # check if user has selected a sub-region in the tot_e_vs_e2-map
    # this is not pretty, but might work.
    sub = nil
    if defined? @sub_tot_e_vs_e2_range
      sub = @sub_tot_e_vs_e2_range
    end
    if sub
      data = [double_energy[1],(e1+e2)]
      select_sub(data, sub[0], sub[1])
      return data[1]
    else
      return (e1+e2)
    end
  end


  #Returns an Array of two GSL::Vectors containing
  # [energy of 2nd electron , total energy ]
  def tot_e_vs_e2
    sub = nil
    if defined? @sub_tot_e_vs_e2_range
      sub= @sub_tot_e_vs_e2_range
    end
    if sub
      e1, e2 = double_energy[0..1]
      data = [double_energy[1],(e1+e2)]
      return select_sub(data, sub[0], sub[1])
    else
      #self.double_energy.transpose.collect{|i| i.sum}
      e1, e2 = double_energy[0..1]
      return e2, e1+e2
    end
  end

  def label
    "LABEL"
  end

end

#Handles selections (subsets)
#Ska kanske byta namn till TofPePe ? Stöder bara elektroner..
class TofPePeMeasurement < TofBasicPePeMeasurement
  def initialize(*args)
    super(*args)
    @sub_sets = {}
  end

  def restore_time
    state_changed("time","energy")
    puts "The time has been restored but not the e0 nor t0"
  end

  def restore
    restore_time
  end
  private
  def clear_subsets
    @subsets = {}
  end
  def state_changed(*args)
    changed
    notify_observers(*args)
#   notify_observers("debug")
    # Det här är lite väl mkt, men borde funka som en första implementering
    # throw away obsolete data
    @times = {}
    @energies = {}
    clear_subsets()
  end
end


if __FILE__ == $0
  class Klass
    def initialize
      @m = TofPePeMeasurement.new({:singles => [1,3,5]}, {:single_time_offset => 100})
      @m.add_observer(self)
    end

    def run
#      p @m.t0
      p @m.single_time.find_max_pt_in_range( 0, 1000)
      @m.t0=-5
#      p @m.t0
      p @m.single_time.find_max_pt_in_range( 0, 1000)
#      @m.single_time.look
      @m.restore
#      p @m.t0
    end

    def update(*args)
      p "Updated", args
    end
  end

  k = Klass.new
  k.run
end
