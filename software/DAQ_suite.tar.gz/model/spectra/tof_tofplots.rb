path_to_model = File.expand_path( File.dirname( __FILE__))

$:<< path_to_model unless $:.find{|i| i == path_to_model}



require 'tempfile'
require 'tof_hist3.rb'
require 'tof_save.rb'
require 'tof_load.rb'
require 'tof_spectra.rb'
#require "tof_dynamicspectrum"
require 'ruby_socker.rb'
require 'tof_gnuplot.rb'
require 'tof_PlotHist'
require "gsl"

class TofPlots
  include Tof_gnuplot

  #Initialises a new instance, -spectrum- should be of class TofDoubles.
  def initialize(spectrum, file_base_name=nil, spacings=["uniform","uniform"])
    #@gnu_pipe = IO.popen("gnuplot","r+")
    #create histograms and put them into files
    @spectrum = spectrum # for references to labels etc
    @spectrum.add_observer(self) #listen to changes in spectrum


    # Each histogram has an associated file, whish is assumed to be in the same
    # "state" as the histogram (updated at the same time). The file @tofplot_file
    # is used for plotting, it is simply pointing to the relevant file which is
    # associated with a histogram

    if file_base_name==nil
      @double_time_hist_file = Tempfile.new("tof_d_t")
      @double_energy_hist_file =Tempfile.new("tof_d_e")
      @tot_e_hist_file  =Tempfile.new("tof_tot_e")
      @double_ionization_hist_file  =Tempfile.new("tof_ioniz")
      #file for gnuplot, various graphs
      @tofplot_file = Tempfile.new("tof_plot")
      @tot_e_vs_e2_hist_file = Tempfile.new("tof_tot_e_vs_e2")
      @single_time_hist_file  =Tempfile.new("tof_s_t")
      @single_energy_hist_file  =Tempfile.new("tof_s_e")
    else
      #create files
      #TO DO !!!
    end
    #make sure there is a spacing specified for both maps
    spacings[1] = spacings[0] if spacings.length < 2
    @spacings =spacings
    #set up plot-histograms
    @histograms = Hash.new
    @histograms["double_time"]=Plot2DHist.new(@spectrum.method("double_time"),
                  @double_time_hist_file)
    @histograms["double_energy"]=Plot2DHist.new(@spectrum.method("double_energy"),
                  @double_energy_hist_file)
    @histograms["tot_e_vs_e2"]=Plot2DHist.new(@spectrum.method("tot_e_vs_e2"),
                  @tot_e_vs_e2_hist_file)
    @histograms["tot_e"]=Plot1DHist.new(@spectrum.method("total_double_energy"),
                  @tot_e_hist_file)
    @histograms["single_time"]=Plot1DHist.new(@spectrum.method("single_time"),
                  @single_time_hist_file)
    @histograms["single_energy"]=Plot1DHist.new(@spectrum.method("single_energy"),
                  @single_energy_hist_file)





    @tofplot_file_contains =[] #["name", "kind"]
    @terminal_no = 0
    #@plotready == false
    #@gnu_pipe = nil
    @title = nil
    #@plotready_tot_e_vs_e2 = false
    #@updated_hists = [] #ex ["double_time","tot_e"]
  end
  attr_accessor :title
  attr_reader :terminal_no, :histograms, :spectrum, :updated_hists, :tofplot_file_contains
  # :tot_e_vs_e2_hist, , :, :double_time_hist, :double_energy_hist, :tot_e_hist, :double_ionization_hist


#-------------------- Listen to changes in spectrum ---------------------
  #For private use. Listens to changes in the spectrum
  def update(*args)
    puts "Notified of changes: #{args}"
    #@plotready_trio = false
    if args.find{|i| i=="time"}
      #everything needs to be updated
      #@updated_hists = []

      @histograms.each_value{|i| i.updated = false}

      #@updated_hists.reject!{|i| i == "time"}
      #energy is also out of date, trust that spectrum sends an "energy" update?
      #@updated_hists.reject!{|i| i == "energy"}
    end
    if args.find{|i| i=="energy"}

#      @updated_hists.reject!{|i| i == "double_energy"}
#      @updated_hists.reject!{|i| i == "tot_e"}
#      @updated_hists.reject!{|i| i == "tot_e_vs_e2"}
      @histograms["double_energy"].updated = false
      @histograms["tot_e"].updated = false
      @histograms["tot_e_vs_e2"].updated = false
      @histograms["single_energy"].updated = false

    end
    if args.find{|i| i=="total energy"}

#      @updated_hists.reject!{|i| i == "tot_e"}
#        @updated_hists.reject!{|i| i == "tot_e_vs_e2"}
    end


    # to do: handle trio


#    puts @updated_hists.inspect
  end



#------------------------ Access spectrum ---------------------

  def t0
    @spectrum.t0
  end
  def e0
    @spectrum.e0
  end
  def t0=(var)
    @spectrum.t0=var
    #@plotready_trio = false
    #puts "t0 changed"
    #set_histograms
  end
  def e0=(var)
    @spectrum.e0=var
    #@plotready_trio = false
    #set_histograms
  end

  #selects times in range t1m,t1M,t2m,t2M
  def select_sub_double_time(*args)#(xrange, yrange)
    args.flatten!
    xrange =args[0..1]
    yrange =args[2..3]
    @spectrum.select_sub_double_time(xrange, yrange)
    #@plotready_trio = false
  end
  def select_sub_double_energy(*args)
    args.flatten!
    xrange =args[0..1]
    yrange =args[2..3]
    @spectrum.select_sub_double_energy(xrange, yrange)
    #@plotready_trio = false
  end

  def select_sub_tot_e_vs_e2(*args)
    args.flatten!
    xrange =args[0..1]
    yrange =args[2..3]
    @spectrum.select_sub_tot_e_vs_e2(xrange, yrange)
  end

  def restore_tot_e_vs_e2
      @spectrum.restore_tot_e_vs_e2
  end

  def deselect_sub_double_time(*args)#(xrange, yrange)
    xrange =args[0..1]
    yrange =args[2..3]
    @spectrum.deselect_sub_double_time(xrange, yrange)
    #@plotready_trio = false
  end
  def restore_energy
    @spectrum.restore_energy
    #@plotready_trio = false
  end

  def restore_time
    @spectrum.restore_time
    #@plotready_trio = false
  end
  #Restores the energy  and time data (they may have been changed for instance by calling a select_sub method). Does not change the value of t0.
  def restore
    @spectrum.restore
    #@plotready_trio = false
  end





  #Replots the last plot, using the same chain of commands. (ie does not send "replot" to gnuplot.)
  def reset_plot
    #find out what kind of plot to replot
    if @tofplot_file_contains[1] == "2D"
      remove_fwhm_from_plot
      replot_spectrum ""#(cmd)
    elsif @tofplot_file_contains[1] == "3D"
      replot_map ""#(cmd)
    else
      #Assume plot trio?
      puts "warning: not implemented, or there was a bug; check +tofplot_file_contains+"
    end
  end



#-------------------------- select --------------------------------

  #def select_sub_tot_e_vs_e2(xrange, yrange, bin_spec=nil)

    #data = @spectrum.select_sub_tot_e_vs_e2(xrange, yrange)
    ##puts data.class
    #@tot_e_vs_e2_hist = Tof_2Dhist.new(data, bin_spec,file_path=@tofplot_file.path, spacing = "uniform", histogram_script="gsl")
    #@tot_e_vs_e2_hist.save_as_file
    #@updated_hists << "tot_e_vs_e2"
  #end



#-------------------------- math --------------------------------
  # Calculates the FWHM of a peak in a 1d histogram (using its built-in method, see -Tof_1Dhist.fwhm-). specify x-min, x-max and background level. -tag_no- is optional, it is the number of the tag in the plot. To plot a new fwhm on the same peak and remove the old tag, call with the tag_no of the old tag.
  def plot_fwhm_tot_e(range1,range2,backgrnd = 0,tag_no=nil)
    range=Array.new
    range[0..1] = range1, range2
    x0_left,x0_right, xm, max,y0, backgrnd =@tot_e_hist.fwhm(range,backgrnd )
    #test if plot exists -- Add flag
    #implement tag hash?"
    fwhm = (100*(x0_right - x0_left)).round.to_f/100
    begin
      unless tag_no
        @tags.push "FWHM = #{fwhm}"
        tag_no = @tags.length
      else
        @tags[tag_no]= "FWHM = #{fwhm}"
      end
    rescue NameError
      @tags=Array.new
      unless tag_no
        @tags.push "FWHM = #{fwhm}"
        tag_no = @tags.length
      else
        @tags[tag_no]= "FWHM = #{fwhm}"

      end
    end
    #NB! Need to fix arrow enumeration
    cmd="set arrow #{tag_no} from #{xm},#{backgrnd} to #{xm}, #{max} heads \n"
    cmd+= "set arrow #{tag_no+10} from #{x0_left},#{y0} to #{x0_right}, #{y0} heads \n"

    cmd += "set label #{tag_no} \"#{@tags.last}\" at #{xm},#{max *1.1} rotate\n "
    cmd +="replot \n"
    cmd(cmd)
    return tag_no
  end

  def remove_fwhm_from_plot
    cmd = "unset arrow \n unset label"
    cmd(cmd)
    @tags =nil
  end

#-------------------------- Save ------------------------------
  #Saves the current spectrum as a .png file. If no file-name is specified the file will have the same name as the title of the plot and the same path as the spectrum (if any).
  def save_as_png(file_name=nil)
    # find another test!
    #    if @updated_hists.empty?
    #      puts "Warning: This function saves the last plot, but there is no updated histogram"
    #    end
    if @tofplot_file_contains.empty?
      raise "No data in plot"
    end
    #Find filename
    if file_name == nil
      @spectrum.path =~ Regexp.new('\w*\.')
      basename = $`+ $&.chop
      basename += " (#{@title})" + '.png'
    else
      #add error checking?
      basename=file_name
    end
    tof_gnuplot_save_as_png(basename)

  end
#-------------------------- extra fcns --------------------------------

  def debug_help
    load 'debug_help.rb'
  end

#-------------------------- accessors --------------------------------
  def path
    puts @tofplot_file.path
  end


#-------------------------- 2D data --------------------------------

  def calculate_single_energy(*bin_spec)
    @histograms["single_energy"].calculate(bin_spec)
  end

  def plot_single_energy(*bin_spec)
    @tofplot_file = calculate_single_energy(*bin_spec)
    @tofplot_file_contains =["single energy", "2D"]
    plot_spectrum
  end

  def calculate_single_time(*bin_spec)
    @histograms["single_time"].calculate(bin_spec)
  end

  def plot_single_time(*bin_spec)
    @tofplot_file = calculate_single_time(*bin_spec)
    @tofplot_file_contains =["single time", "2D"]
    plot_spectrum
  end


  def calculate_tot_e(*bin_spec)
    bin_spec.flatten!
    #bin_spec = [0,100,500] if bin_spec ==[nil]
    @histograms["tot_e"].calculate(bin_spec)
  end

  def plot_tot_e(*bin_spec)
    @tofplot_file = calculate_tot_e(*bin_spec)
    @tofplot_file_contains =["tot_e", "2D"]
    plot_spectrum
  end

#-------------------------- 3D data --------------------------------

  def plot_double_energy(*bin_spec)
    @tofplot_file = calculate_double_energy(*bin_spec)
    @tofplot_file_contains =["double_energy", "3D"]
    plot_map
  end

  def calculate_double_energy(*bin_spec)
    @histograms["double_energy"].calculate(bin_spec)
  end

  #Plots the time coincidence map. bin_spec is x_min, x_Max, y_min, y_Max [, x_bins, y_bins]
  def plot_double_time(*bin_spec)
    @tofplot_file = calculate_double_time(*bin_spec)
    @tofplot_file_contains =["double_time", "3D"]
    plot_map
  end

  def calculate_double_time(*bin_spec)
    @histograms["double_time"].calculate(bin_spec)
  end

  def plot_tot_e_vs_e2(*bin_spec)
    @tofplot_file = @histograms["tot_e_vs_e2"].calculate(bin_spec)
    @tofplot_file_contains =["tot_e_vs_e2","3D"]
    plot_map
  end
# - - - - - - - - - - - trio - - - -- - - - - - - - - -
#def plot_trio # obsolete
#  #set histograms
#  #time
#  if not @updated_hists.find{|i| i=="double_time"}
#      #need to make histogram
#      @double_time_hist = Tof_2Dhist.new(@spectrum.double_time,bin_spec=nil, @double_time_hist_file.path, @spacings[0])
#      #save hist in file and point the tofplot_file to it
#      @double_time_hist.save_as_file
#      @updated_hists << "double_time"
#  end
#
#  #double_energy
#  if not @updated_hists.find{|i| i=="double_energy"}
#      #need to make histogram
#      @double_energy_hist = Tof_2Dhist.new(@spectrum.double_energy,bin_spec=nil, @double_energy_hist_file.path, @spacings[1])
#      #save hist in file and point the tofplot_file to it
#      @double_energy_hist.save_as_file
#      @updated_hists << "double_energy"
#  end
#
#  #ionization energy
#  if not @updated_hists.find{|i| i=="ionization energy"}
#    tot_e= @spectrum.total_double_energy
#    double_ionization = tot_e.map{|i| @spectrum.excitation_energy - i}###
#    @double_ionization_hist = Tof_1Dhist.new(double_ionization,
#                    [450,610],@double_ionization_hist_file.path)
#
#    @double_ionization_hist.save_as_file
#    @updated_hists << "ionization energy"
#  end
#  #plot using multiplot
#  cmd("set terminal push")
#  cmd = "set terminal aqua 1 title \"#{@spectrum.path}\" size 800 1200 \n"
#  replot_trio(cmd)
#  #pop terminal
#  cmd("set terminal pop")
#  #cmd("set terminal aqua 0") #Mac os x specific
#end



#--------------- Private methods -----------------------
private
  def plot_spectrum
    #clean up @updated_hists
#    @updated_hists.uniq!
    unless @spectrum.label
      title = @spectrum.path
    else
      title = @spectrum.label
    end
    #cmd = "set terminal aqua #{@terminal_no} title \"#{title}\" \n"
    cmd =""
    replot_spectrum(cmd)
  end


  def replot_spectrum(cmd)
    #remove_fwhm_from_plot
    cmd += "unset pm3d \n"
    #cmd += "set title \"#{@title}\" \n"
    #cmd += "set key noautotitle title \" #{@spectrum.to_s.chomp}  (#{@spectrum.excitation_energy} eV, t0 = #{@spectrum.t0} ns) \" \n"
    #cmd += "unset key\n "#totitle\n "
    cmd += "plot  \"#{@tofplot_file.path}\" u 1:3 w l \n"
    cmd(cmd)
  end


  def plot_map(rgb="21,22,23")
    #clean up @updated_hists
    #@updated_hists.uniq!

    unless @spectrum.label
      title = @spectrum.path
    else
      title = @spectrum.label
    end
    #cmd = "set terminal aqua #{@terminal_no} title \"#{title}\" \n"
    cmd = ""
    replot_map(cmd, rgb)
    #p "regain cntrl"
  end


  def replot_map(cmd=nil, rgb="21,22,23")
    remove_fwhm_from_plot
    #cmd += "set title \"#{@title}\" \n"
    #cmd += "set key noautotitle title \" #{@spectrum.to_s.chomp}  (#{@spectrum.excitation_energy} eV, t0 = #{@spectrum.t0}  ns)\" \n"
    #cmd += "unset key \n"#;noautotitle \n"
    cmd += "set pm3d map  \n set palette rgbformulae #{rgb} \n"
    #p "starting gnuplot"
    #cmd += "splot \"#{@tofplot_file.path}\" using ($1+$2)/2:($3+$4)/2:5\n"#(sqrt(log($5+1))) \n"
    cmd += "splot \"#{@tofplot_file.path}\" using 1:3:5\n" # less accurate but faster
    #cmd += "set label
    #puts cmd
    cmd(cmd)
  end
#  - - - - - - - trio - - -
def replot_trio(cmd)
    puts "  plotting trio"
    #commands for the plots
    cmd1 = "set xrange [#{@double_time_hist.xmin}:#{@double_time_hist.xmax}] \n"
    cmd1 += "set yrange [#{@double_time_hist.ymin}:#{@double_time_hist.ymax}] \n"
    cmd1 += " set palette rgbformulae 30,31,32 \n"
    cmd1 += "splot \"#{@double_time_hist_file.path}\" using 1:2:(sqrt(log($3+1))) \n"

    cmd2 = "set xrange [#{@double_energy_hist.xmin}:#{@double_energy_hist.xmax}] \n"
    cmd2 += "set yrange [#{@double_energy_hist.ymin}:#{@double_energy_hist.ymax}] \n"
    cmd2 += "set origin 0,-0.05 \n"
    cmd2 += "set palette rgbformulae 30,31,32 \n"
    cmd2 += "splot \"#{@double_energy_hist_file.path}\" using 1:2:(sqrt(log($3+1))) \n"
    cmd3 = "plot  \"#{@double_ionization_hist_file.path}\" w l \n"



    #cmd += "set multiplot title \" #{@spectrum.to_s.chomp}  (#{@spectrum.excitation_energy} eV, t0 = #{@spectrum.t0} ns)\" \n"
    cmd += "set multiplot \n"#title \" #{@spectrum.to_s.chomp}  (#{@spectrum.excitation_energy} eV, t0 = #{@spectrum.t0} ns)\" \n"
    cmd += "set pm3d map \n"
    cmd += "set key off \n unset colorbox \n"
    #cmd += "set bmargin 0 ; set tmargin 0 \n"
    cmd += " set size 1,0.5 \n set origin 0,0.37 \n"
    end_cmd = "unset multiplot \n"
    end_cmd +="unset origin \n unset size"
    #puts cmd
    cmd(cmd)
    #puts "cmd1"
    #puts cmd1
    #gets
    cmd(cmd1)
    #puts "cmd2"
    #gets
    cmd(cmd2)
    #unset pm3d?
    #puts "cmd3"
    #gets
    cmd("set xrange [*:*] \n set yrange [*:*] \n set size 0.79,0.2 \n set origin 0.0805,0.79 \n")

    cmd(cmd3)
    cmd(end_cmd)






  end





end
