#!/usr/bin/env ruby 
require 'ruby_socker'
require "observer"
require "gsl"
require "tof_extra"
include GSL

class BasicSpectrum
  include Observable
  def initialize(spectrum=nil,label=nil)
    @spectrum = Array.new 
    @label = label
    @spectrum = spectrum
    @updated = true # is spectrum up to date?
  end  
  attr_accessor :spectrum, :label
end

class TofSingles < BasicSpectrum
  def initialize(singles=nil,\
                  ring_period=1000000,\
                  exc_energy = nil,\
                  t_max=nil, \
                  run_no=nil ,\
                  sample_name="", \
                  path=nil,\
                  t0=273, e0=0,\
                  total_runtime=nil,\
                  min_time_diff=nil,\
                  label=nil,
                  single_time_starts_at=0)
                  
    super(nil,label)
    @singles = singles
    @total_runtime = total_runtime
    @run_no = run_no
    @sample_name = sample_name
    @path = path
    @t0 = t0 
    @e0 = e0
    @t_max = t_max     
    @lightsource_period = ring_period
    @excitation_energy = exc_energy
    @min_time_diff = min_time_diff
    @single_time_starts_at = single_time_starts_at
    # implement in initialize call?
    @length_const =  3438.0#3390.0
    @single_time=[]
    @single_energy=[]
    @single_energy_varied_binsize=[]
    @TIME_RESOLUTION = 1 #ns
  end
  # fill in
  attr_reader :total_runtime,:t0, :e0,:length_const
  attr_accessor :spectrum, :spectrum_length,  :path, :excitation_energy, 
            :lightsource_period, :run_no, :sample_name,
            :single_time_starts_at
  attr_writer  :spectrum_length
  
  def t_max
     @t_max || @lightsource_period 
  end

  #Returns a Tof_1Dhist containing the single times, compensated for t0
  def single_time
    if @single_time==[]
      #puts 'Assuming times = 0...@lightsource_period'# this ougth to be a variable: run_time- it is! t_max !
      times = []
      time_zero= @single_time_starts_at.to_i
      times[0] =  (time_zero...(t_max)).to_a.collect{|i| i- @t0 }
      times[1] =  @singles
      if $DEBUG
        p time_zero
        p times[0].length#, times[0], @t0
        p times[1].length
        p t_max
      end
      
      lowest_time = @length_const/ Math.sqrt(@excitation_energy)
      puts lowest_time 
      counter=0
      times= times.transpose
      times.each do |pair| 
         if pair[0] <= lowest_time
             pair[0]+= @lightsource_period
             counter+=1
         end
      end
      puts "no_changed_singles = #{counter}"
      #convert to histogram
      #We want to have 1 ns resolution from the lowest time (given
      # by D/sqrt(hv) ) to the maxmum time given by the ring period + 1
      res = @TIME_RESOLUTION
      hres= res.to_f/2 
      lt = lowest_time.to_i
      ringp = t_max.to_i#@lightsource_period.to_i
      #p "----------"
      #p "t_max is #{@t_max}"
      #p "lightsource_period is #{@lightsource_period}"
      #p "----------"
      
      # det h�r �r kanske inte det b�sta ifall t_max < ring_p men 
      # alla h�ndelser borde komma med
      bin_spec = [lt + hres, lt + ringp + hres, ringp/res]
      @single_time = Tof_1Dhist.new(nil, bin_spec)
      times.each do |pair|
        @single_time.increment( pair[0], pair[1])
      end
    end
    
    return @single_time
  end


  #Returns a histogram with the single ionisation spectrum.
  # the sizes of the bins reflects the varying resolution (full resolution is kept)
  def single_energy_varied_binsize
    if   @single_energy_varied_binsize==[]
      #Use 1d histogram to store data
            
      ranges = single_time.range.collect do |i|
        @length_const**2/(i)**2 + @e0
      end
      
      @single_energy_varied_binsize = Tof_1Dhist.new(nil, ranges.sort ,nil,"uneven")
      #add data
      single_time.each_with_ranges do |val,t|
        #energy= @length_const**2/(t)**2 + @e0
        energy= time_to_energy(t)
        @single_energy_varied_binsize.increment(energy, val)
      end
    end
    return @single_energy_varied_binsize
  end
  alias :single_energy :single_energy_varied_binsize 
  
  def save_as_binary_file(path)
    File.open(path, "w") do |file|
      Marshal.dump(self,file)
    end  
  end
  
  def file_name
    File.basename @path
  end
  
  def dirname
    File.dirname @path
  end
  # To load file:
  #f = File.open("myfile")
  #spectrum=Marshal.load(f)
  #f.close
  
  def length_const=(val)
    @length_const=val.to_f
  end
  
  # Find run number and sample
  def to_s
    return "Spectrum: Run No #{@run_no} on #{@sample_name}"
  end
  
end

#class that includes double excitations  ,and singles 
class TofDoubles < TofSingles
  def initialize (doubles=nil,\
                  singles=nil,\
                  ringperiod=1000000,\
                  exc_energy = nil,\
                  t_max=nil, \
                  run_no=nil ,\
                  sample_name="", \
                  path=nil,\
                  t0=-273, e0=0,\
                  total_runtime=nil,\
                  min_time_diff=nil,\
                  label=nil,
                  single_time_starts_at=0)
    if label == nil and path != nil
      #path =~ Regexp.new('\w*\/\w*\/\w*\.')
      label = ".../" + path.split("/").to_s   #$&.chop
    end
    
    
    super(singles,ringperiod ,exc_energy, t_max,run_no,sample_name, \
        path, t0, e0, total_runtime,min_time_diff, label, single_time_starts_at)
    puts " + New TofDoubles object"
    @double_time = Array.new  #As a row of fast and a row of slow compensated for t0 and ringperiod
    @double_energy = Array.new
    @doubles = doubles
  end
  
  #set new t0
  def t0=(new_t0)
    #when resetting t0, double_times and double_energy needs to be recalculated
    @double_time = []
    @double_energy = []
    @single_time = []
    @single_energy=[]
    @single_energy_varied_binsize=[]
    
    changed  # note that our state has changed
    notify_observers("time","energy")
    @t0 = new_t0
  end
  def e0=(new_e0)
    #when resetting e0, ?double_times? and double_energy needs to be recalculated
    #@double_time = []
    @double_energy = []
    @single_energy=[]
    @single_energy_varied_binsize=[]
    changed  # note that our state has changed
    notify_observers("energy") #("time","energy")
    @e0 = new_e0
  end
  
  
  #Returns an array containing two GSL::Vectors
  #[fast_electrons , slow_electrons]
  def double_time
    if @double_time == []
      @double_time[0] = Vector.alloc doubles_fast.collect{|doubles| (doubles - @t0) }
      @double_time[1] = Vector.alloc doubles_slow.collect{|doubles| (doubles - @t0) }
      # put the times on a scale that goes beyond ringperiod (relevant for
      # data from Elands program where the data is saved mod ringp) and 
      # make sure that the second electron always comes after the first
      no_changed_pairs = 0
      #Electrons with an energy above the excitation energy are moved to next ringp
      # (otherwise use pair[0] < 0 for times below zero) 
      lowest_time = @length_const/ Math.sqrt(@excitation_energy)# - @e0)
      t1 = @double_time[0]
      t2 = @double_time[1]
      t1.each_index do |i|
        if t1[i] < lowest_time
          t1[i] += @lightsource_period
          t2[i] += @lightsource_period
          no_changed_pairs +=1
        end        
      end
      puts "no_changed_pairs = #{no_changed_pairs }"
    end
    return @double_time
    
  end
  
  #returns a GSL::Vector of the fast electron of each pair
  def doubles_fast
    fast = @doubles[0]
  end
  
  #returns a GSL::Vector of the slow electron of each pair
  def doubles_slow
    slow = @doubles[1]
  end
  
  def total_double_energy
    e1, e2 = double_energy[0..1]
    # check if user has selected a sub-region in the tot_e_vs_e2-map
    # this is not pretty, but might work.
    begin
      sub= @sub_tot_e_vs_e2_range
    rescue NameError
      sub= false
    end
    if sub
      data = [double_energy[1],(e1+e2)]
      select_sub(data, sub[0], sub[1])
      return data[1]
    else
      return (e1+e2)
    end
  end
  
  #Returns an Array of two GSL::Vectors containing 
  # [energy of 2nd electron , total energy ] 
  def tot_e_vs_e2
    begin
      sub= @sub_tot_e_vs_e2_range
    rescue NameError
      sub= false
    end
    
    if sub 
      e1, e2 = double_energy[0..1]
      data = [double_energy[1],(e1+e2)]
      return select_sub(data, sub[0], sub[1]) 
    else   
      #self.double_energy.transpose.collect{|i| i.sum}
      e1, e2 = double_energy[0..1]
      return double_energy[1], e1+e2 
    end
  end
  
  #Returns an Array with two GSL::Vectors containing
  # [fast, slow]
  def double_energy
 //   # "@double_energy = @length_const**2/(double_time-t0)**2" 
    if @double_energy ==[]
      puts "  calculating energies"
      double_t = double_time
      
      #Testing for zeroes should not be necessary??
  
      puts "WARNING!!!: lengthconst is not a float!" unless @length_const.is_a?(Float)
      
      @double_energy[0] = time_to_energy( double_t[0] )        
      @double_energy[1] = time_to_energy( double_t[1] )
      
    end
    return @double_energy
  end

  #put "!" on function names below?
  
  def select_sub_double_time(xrange, yrange)
    #make sure there is data (@double_time may be nil)
    data = double_time
    @double_time =  select_sub(data, xrange, yrange)
    @double_energy = []
    changed  # note that our state has changed
       notify_observers("time","energy")
  end
  def select_sub_double_energy(xrange, yrange)
    data = double_energy
    @double_energy =  select_sub(data, xrange, yrange)
    changed  # note that our state has changed
       notify_observers("energy")
  end
  def deselect_sub_double_time(xrange, yrange)
    data = double_time
    @double_time =  deselect_sub(data, xrange, yrange)
    @double_energy = []
    changed  # note that our state has changed
    notify_observers("time","energy")
  end
  
  def select_sub_tot_e_vs_e2(xrange, yrange)
    changed  # note that our state has changed
    notify_observers("total energy")
    data = [double_energy[1] ,total_double_energy]
    
    @sub_tot_e_vs_e2_range= [xrange, yrange]
  end
  
  def restore_energy
    @double_energy = []
    @sub_tot_e_vs_e2_range = nil
    changed  # note that our state has changed
    notify_observers("energy")
  end
  
  def restore_tot_e_vs_e2
    @sub_tot_e_vs_e2_range= false
    changed  # note that our state has changed
    notify_observers("total energy")
  end
  
  def restore_time
    @double_time = []
    changed  # note that our state has changed
     notify_observers("time","energy")
     puts "The time has been restored but not the energy nor t0"
  end
  
  def restore
    restore_time
    restore_energy
    restore_tot_e_vs_e2
    puts "Time and energy restored"
    puts "NB! t0 is not restored"
  end

private
  def select_sub(data,xrange, yrange)
      #Add error checking of the ranges
  
      arr=Array.new
      puts "selecting part of spectrum"  
      #fulkhack...
      data[0]= data[0].to_a
      data[1]= data[1].to_a
      p data[0].length
      
      #can easily be rewritten using reject...        
      arr = data.transpose.collect{|pair|
        if xrange[0] <=pair[0] and pair[0] < xrange[1]
            if yrange[0] <= pair[1] and pair[1] < yrange[1]
                 #pair.look
                 #puts "--"
                 pair
            end
        end
        
      }
      #v0=Vector.alloc data[0]
      #v1=Vector.alloc data[1]
      
      ##arr= [v0, v1].transpose!
      ##v0i=v0.where{|i| xrange[0] <= i and i < xrange[1]}
      ##v1i = v1.where{|i| yrange[0] <= i and i < yrange[1]} 
      
      ##test xrange
      #v0i = v0.ge xrange[0]
      #v0i2 = v0.lt xrange[1]
      #v0i = v0i.and v0i2
      
      
      #puts "selecting finished"
      arr.compact!
      puts "#{arr.length} elements in new list, #{data[0].length} elements in old."
      raise RangeError if arr.length== 0
      #if arr.length == 0     # This feeds nonsense data to the program and it is probably better 
        #v = Vector.alloc [-1]  # to just stop if the user selects an empty set
        #return [v,v] 
      #end
      arr = arr.transpose
      data[0] = Vector.alloc arr[0]
      data[1] = Vector.alloc arr[1]
      return data
      
  end
  def deselect_sub(data,xrange, yrange) 
      #Add error checking of the ranges
      #a=b=0
            #fulhack...
      data[0]= data[0].to_a
      data[1]= data[1].to_a

      old_length=data[0].length
      arr = Array.new
      puts "deselecting part of spectrum"          
      arr = data.transpose.collect{|pair|
        if xrange[0] <=pair[0] and pair[0] < xrange[1] and
             yrange[0] <= pair[1] and pair[1] < yrange[1]
                 #pair.look
                 #puts "--"
                 #a+=1
                 [nil,nil]
            #end
          #puts pair
          #pair
            
        else
        #b+=1
        pair
        end
      }
      #puts "selecting finished"
      arr.reject!{|i| i==[nil,nil]}
      #antagligen g�r det snabbare om man returnerar nil och sedan anv�nder compact!
      #arr.look
      data = arr.transpose
      puts "#{data[0].length} elements in new list, #{old_length} elements in old."
      #arr.look
      #puts "2"
      return data
      
  end
  
  def time_to_energy(times)
    if times.respond_to?("**")
       energies = @length_const**2 / times**2 + @e0
    else
      energies = @length_const**2 / times.square + @e0
    end
  end
  

end

#class that includes even more electrons
#class ManyElectronSpectrum <DoubleElectronSpectrum
#end
if __FILE__ == $0
  require 'tof_tofplots'
  file_path = "/Volumes/filer/jobb/BESSY_mars_07/bessydata/o2d/O2D24.PRS" 
  #file_path2  = "../debug/dummyspec.PRS"
  ##file_path1  = "../debug/O2D24.SPC"
  #file_path1  = "../../../testdata/O2D24.SPC"
  #puts "....loading file"
  #spectrum = load_gtauger5(file_path2)
#  plotobj = TofPlots.new(load_gtauger5(file_path2))
  #plotobj.select_sub_double_time [500,600],[0,5000]
#  plotobj.plot_double_time
#  sleep 20
#  plotobj.restore
#  plotobj.plot_double_time(500,600,0,10000,50,100)
#  plotobj.plot_double_time([500,600,0,10000,50,100])
#  plotobj.plot_double_energy
#  plotobj.plot_tot_e_vs_e2 [0,20,15,40]
  
#  sleep 30
#  
#  plotobj.plot_tot_e nil
#  gets
#  plotobj.plot_tot_e [0,50,40]
#  singl, ringp = load_SPC(file_path1)
#  spectrum=TofDoubles.new(    doubles=nil,
#                  singles=singl,
#                  ringperiod=ringp,
#                  exc_energy = 605,
#                  t_max=nil, 
#                  run_no=nil ,
#                  sample_name="", 
#                  path=nil,
#                  t0=273, e0=0,
#                  total_runtime=nil,
#                  min_time_diff=nil,
#                  label=nil)

  
#  plotobj=TofPlots.new(spectrum)
  plotobj=TofPlots.new(load_gtauger5(file_path))
  #plotobj.spectrum.excitation_energy = 605
  plotobj.t0 = 270
  plotobj.e0 = -0.64
  plotobj.plot_tot_e_vs_e2 0,40,0,40,200,200
  gets
  plotobj.plot_double_time
  gets
  plotobj.plot_tot_e 0,100,400
  gets
#  sleep 20
end
