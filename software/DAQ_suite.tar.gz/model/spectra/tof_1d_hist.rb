path_to_model = File.expand_path( File.dirname( __FILE__))

$:<< path_to_model unless $:.find{|i| i == path_to_model}

require "gsl"
require 'tempfile'
require 'tof_save.rb'
require 'tof_load.rb'
require "tof_gnuplot"
#require 'stringio'
include GSL
#include GSL::Histogram

#A class that makes it easier to work with GSL histograms. The save_as_file method stores the histogram in a format suitable for Gnuplot.
class Tof_1Dhist
    include Tof_gnuplot

    DEFAULT_BINNING = 270

    #Arguments:
    # arr -      the data that will be stored imediately. If You want to create an
    #            empty histogram call with arr=nil. arr and bin_spec cannot be nil
    #            at the same time.
    # bin_spec - specifies [min,max, no of bins] for uniform spacings (see
    #            +spacings+).
    #            To specify a non-uniform histogram let +bin_spec+= [[r0, r1, r2, ...]]
    #            or set +spacing+ to "variable"
    # file_path - leave as nil unless you want to specify a file name. Relevant
    #            when plotting or when saving data to file. If no filename is
    #            given a tempfile is used.
    # spacing   - Defines the spacings of the histogram i.e the binsizes. Default
    #            is uniform, otherwise the ranges of each bin must be specified
    def initialize(data, bin_spec=nil,file_path=nil, spacing="uniform")
        if not data and not bin_spec
            raise ArgumentError, "You must give a data set or specify ranges (bin_spec)",caller
        end

        #create file
        if file_path==nil
            @tmpfile=Tempfile.new("tof_hist_data_for_gnuplot")
        else
            #create file NB! overwites already existing file
            @tmpfile=File.open(file_path,"w+")
        end

        @h=nil #the histogram
        p bin_spec if $DEBUG
        #bin_spec = nil if bin_spec == []
        if bin_spec
            #create histogram and add data
            check_binspec( data, bin_spec, spacing)
        elsif data
            #guess bin_spec and add data
            guess_binspec(data)
        else
            raise ArgumentError, "You must specify at least data or bin_spec", caller
        end


    end

    attr_accessor :h #when the necessary methods are defined this can be removed
   # attr_reader :path


    def path
        @tmpfile.path
    end

    # wrap some Hist functions
    
    #maximum value of ranges ie maximum range
    def max
        @h.max
    end
    def min
        @h.min
    end
    def bins
        @h.bins
    end
    #Maximum value of bin
    def max_val
      @h.max_val
    end

    def sum
        @h.sum
    end

    def reset
      @h.reset
    end

    def bin_spec
        return [@h.min,@h.max,@h.bins]
    end

    def eqv_binspec?(other)
        if other.is_a?(Array)
            if other.length == 3
                return other == bin_spec
            elsif other.length == 2
                return [min, max] ==other
            end
        elsif other.respond_to? "bin_spec"
            return bin_spec == other.bin_spec
        else
            raise TypeError, "Expected Array or Tof_1DHist", caller
        end
    end

    def eqv_range?(other)
        if other.is_a?(Array)
            return other == range
        elsif other.respond_to? "range"
            return range() == other.range
        else
            raise TypeError, "Expected Array or Tof_1DHist", caller
        end
    end

    def range
        @h.range
    end

    def find(x)
      @h.find(x)
    end

    def uniform_ranges?
        r = Vector.alloc range
        r2 = r.duplicate
        r2.shift
        r.pop
        r3 = r-r2
        return (r3-r3[0]).sum.abs < r3[0].abs/1e10
    end

    def increment(*args)
        @h.increment(*args)
    end

    def -(o)
    if o.kind_of? Numeric
      h2 = Tof_1Dhist.new(nil, range() )
      self.each_with_ranges do |val,r|
        h2.increment(r, val -o)
      end
    elsif o.kind_of?  Tof_1Dhist
      if eqv_binspec?(o.bin_spec)
        h2 = Tof_1Dhist.new(nil, range() )
        self.each_with_indices do |val,i |
          r = @h.get_range(i).mean
          h2.increment(r, val - o[i])
        end
      else
        raise IndexError,"Histograms do not have same ranges", caller
      end
    elsif o.class==GSL::Histogram
      raise TypeError, "not implemented"
    else
      raise TypeError, "unsupported format"
    end
    h2
  end

    def +(o)
        self.-(-o)
    end

    def *(o)
        if o.kind_of? Numeric
      h2 = Tof_1Dhist.new(nil, range)
      self.each_with_ranges do |val,r|
        h2.increment(r,val*o)
      end
    else
      raise TypeError, "unsupported format"
    end
    h2
    end

    def /(o)
        if o.kind_of? Numeric
            self.*(1.0/o)
        else
            raise TypeError, "unsupported format"
        end
    end

    def ==(o)
        return false unless o.class == self.class
        if eqv_binspec?(o.bin_spec)
            return @h.bin == o.h.bin
        else
            return false
        end
    end

    #Displays the contents of the histogram
    def look
        each_with_index {|v,i| p "#{v} at #{i} (#{get_range(i).mean })"}
    end

    def push(data)
        if data
            if data.class == self.class
                data.each_with_ranges do |val, rx|
                    increment( rx, val)
                end
            elsif data.class == GSL::Histogram
                0.upto(data.bins-1) do |i|
                    val , rx = data.get(i), data.get_range(i).mean
                    increment( rx, val)
                end
            else
                @h.increment(data)
            end
        end
    end

    def plot
        save_as_file
        cmd("plot \"#{path}\" u 1:3 w l")
    end

    #Saves the mean value of the range of each bin and the value of the bin. -NO!
    # I.E. in a format suitable for gnuplot
    def save_as_file(output_path=nil)
        #puts "  save_as_file"
        #save to file
        if output_path == nil
            output_path = path
        end

        #access data, it would (perhaps) be faster to use gsl's bult in fprintf?
        #val=[]
        #range =[]
        #each_with_ranges do |v,r|
        #  val << v
        #  range << r
        #end
        f = File.open(output_path,"w")
        @h.fprintf(f,"%g", "%g")
        f.close

        #save_asciifile([range, val], output_path)
        return output_path
    end

    # return types:
    # * false or "Tof_1Dhist"   - returns a Tof_1Dhist
    # * "Hist"                  - return gsl::Histogram
    # * "exclamation"           - same as ::sub!
    def sub(range,return_type =false)

        if range[0] < @h.min
                    puts "   Warning: min out of range"
                    range[0] =@h.min
        end
        if range[1] >= @h.max
                    puts "   Warning: max out of range"
                    range[1] =@h.max*0.999 #will fail for small bins
        end
        min = @h.find(range[0])
        max = @h.find(range[1])
        bins = max  - min +1
        xmin = @h.get_range(min).min
        xmax = @h.get_range(max).max

        h2 = Histogram.alloc(bins)
        h2.set_ranges_uniform(xmin,xmax)
        #puts h2.min, h2.max, h2.bins
        #add data
        min.upto(max) do |i|
            var =  @h.get(i)
            x=@h.get_range(i).mean
            #puts i, x,var
            h2.accumulate(x,var)
          end
        #puts h2.class
        if return_type == "exclamation"
            @h=h2
            save_as_file
        elsif return_type == "Hist"
            #puts "fix this"
            #puts h2.class
            return h2
        else #tof hist
            h3=Tof_1Dhist.new(h2)
        end
    end
    def sub!(range)
        sub(range, "exclamation")
    end

    #quick fix
    def find_max_in_range(*range)
        range.flatten!
        h2= sub(range,"Hist")
#        i=find_bin_of_max_in_hist(h2)
#        h2.get(i)
        h2.max_val
    end
    def find_max_pt_in_range(*range)
        range.flatten!
        h2= sub(range,"Hist")
        i=find_bin_of_max_in_hist(h2)
        y=h2.get(i)
        x=h2.get_range(i).mean
        return x,y
    end



#-- -- --- --- --- --- --- ---Added ruby functionality- -- -- --- -- --- ---- --- --- --- -- --- ---- --
    def length
        bins
    end
    def size
        bins
    end
    def [](index)
        @h.get(index)
    end

    def get_range(i)
        @h.get_range(i)
    end

    #Yields the value of each bin
    def each
        0.upto(bins-1) do |i|
            yield @h.get(i)
        end
    end
    #Yields the value of each bin and the corresponding index
    def each_with_index
        0.upto(bins-1) do |i|
            yield @h.get(i),i
        end
    end
    #Yields the value of each bin and the mean value of the
    # corresponding range
    def each_with_ranges
        0.upto(bins-1) do |i|
            yield @h.get(i), @h.get_range(i).mean
        end
    end


    #returns the value of each bin in an array. Does not return
    #the ranges of the bins
    def to_a
        a=[]
        self.each_with_index{|val,i| a[i]=val}
        a
    end
    #returns the value of each bin and the mean value of the ranges of each bin in an array.
    #Returns [ranges, values]
    def to_a_with_ranges
        a=self.to_a
        r=[]
        0.upto(bins() -1) do |i|
            r[i] = @h.get_range(i).mean
        end
        return r,a
    end

    #Marshals an Tof_1Dhist object.
    #NB! Any file connected to the Tof_1Dhist object is lost
    def _dump(depth)
    Marshal.dump([@h, path])
  end

  #Unmarshals an Marshalled Tof_1Dhist object and returns it
    #NB! Any file connected to the Tof_1Dhist object is lost
  def Tof_1Dhist._load(obj)
    hist, old_path = Marshal.load(obj)
    p "This Tof_1Dhist object had the following path", old_path
    Tof_1Dhist.new(hist)
  end

#-------------------------------------------------------------------------



    def fwhm(range,backgrnd = 0)
        puts "Calculating FWHM. (Only rough calculation, no derivatives used.)"
        h2= sub(range,"Hist")
        #puts h2.class
        max = h2.max_val
        #puts "hh"
        #puts "max value ",max
        y0= 0.5 *(max-backgrnd) + backgrnd
        #puts "y0", y0
        #find corresponding bin
        #rignt side
        first_i = find_bin_of_max_in_hist(h2)
        last_i = find_below_val(h2,backgrnd + 0.2*y0, first_i)
        #puts "fI, fl"
        #puts first_i, last_i
        x0_right = find_crossing(h2,y0,first_i, last_i)
        #left side
        last_i = find_below_val(h2,backgrnd + 0.2*y0, first_i, "rev")
        #puts first_i, last_i
        x0_left = find_crossing(h2,y0,first_i, last_i)
        puts "FWHM = #{x0_right - x0_left}"
        xm= h2.get_range(first_i).mean
        #returns [x0_left,x0_right, x_coord of max ,y coor of  max, y0,background level]
        [x0_left,x0_right, xm, max,y0, backgrnd]


        #h2






    end
private

    def check_binspec( data, bin_spec, spacing)
        #bin_spec = [] if bin_spec == nil
        #check if uniform or given ranges
        if (bin_spec.length ==2 or bin_spec.length ==3) and spacing == "uniform"
            # we assume that at least min-max are specified and sensible
            xm, xM, xbin = bin_spec
            # if xbin is unspecified we must guess
            xbin = DEFAULT_BINNING unless xbin
            @h = Histogram.alloc(xbin)
            @h.set_ranges_uniform(xm, xM)
        else # bin_spec.length ==1 or spacing != "uniform"
            #check that the bin_spec is alright and construct uneven histogram
            if bin_spec.length ==1
                if bin_spec[0].kind_of? Array or bin_spec.kind_of? GSL::Vector
                    range = Vector.alloc bin_spec[0]
                else
                    raise ArgumentError, "You must specify more than one range", caller
                end
            else
                range = Vector.alloc bin_spec
            end
            @h= Histogram.alloc(range)
        #else
            ## we assume that at least min-max are specified and sensible
            #xm, xM, xbin = bin_spec
            ## if xbin is unspecified we must guess
            #xbin = DEFAULT_BINNING unless xbin
            #@h = Histogram.alloc(xbin)
            #@h.set_ranges_uniform(xm, xM)
        end
        push(data)
    end

    def guess_binspec(data)
        #if data is of type histogram we are done!
        if data.class == GSL::Histogram
            @h=data
            return
        elsif
            data.class == self.class
            @h=data.h
            return
        end

        # calculate data limits, the max limits are increased
        # to include the maximum values
        xM = data.max * (1.01)
        xm = data.min
        # fall back on default binning
        xbin = DEFAULT_BINNING
        @h = Histogram.alloc(xbin)
        #p xm, xM
        @h.set_ranges_uniform(xm, xM)
        push(data)
    end

    def find_bin_of_max_in_hist(hist)
#        max = hist.max_val
#        0.upto(hist.bins() -1) do |i|
#            if max ==  hist.get(i)
#                return i
#            end
#
#        end
        hist.max_bin
    end
    def find_below_val(hist,val, start_i=0,direction="fw")
#        max = hist.max_val
        #puts "find below", val
        if direction == "fw"
            start_i.upto(hist.bins() -1) do |i|
                if val >=  hist.get(i)
                    #puts "now i is ", i
                    return i
                end
                #puts i
            end
        elsif direction == "rev"
            start_i.downto(0) do |i|
                if val >=  hist.get(i)
                    #puts "now i is ", i
                    return i
                end
                #puts i
            end
            puts "Warning: Could not find lower limit"
            return 0
        end
    end

    def find_crossing(h2,y0, first_i, last_i)
        if first_i< last_i
            #puts "I"
            index = (first_i..last_i).to_a
        else
            #puts "II"
            #puts last_i,first_i
            index = (last_i..first_i).to_a.reverse
        end

        y = index.map{|i| h2.get(i)}
        #puts index
        #puts "y"
        #y.look
        #find the points on each side of y0
        y2=y.sort
        #puts "y2"
        #y2.look
        y_above = y2.reverse.find{|i| i<y0}
        y_below = y2.find{|i| i>y0}
        i_above = y.index(y_above)
        i_below = y.index(y_below)
        raise "Background is out of bounds" unless  i_above and i_below
        if first_i> last_i
            i_above *= -1
            i_below *= -1
        end
        #puts "i_a,b" ,i_above,i_below
        x_above = h2.get_range(i_above+first_i).mean
        x_below = h2.get_range(i_below+first_i).mean
        #puts "+++"
        #puts i_above,i_below,y_above,y_below,x_above,x_below
        #puts "---"
        #calculate x value of y0
        # eq of line y = k * x + m
        k = (y_above.to_f-y_below)/(x_above - x_below)
        m = y_above - k * x_above
        x0 = (y0 -m)/k
    end



end#class
