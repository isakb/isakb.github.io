class TofFile

  class << self

    def save_asciifile(data, path="tof_ascii_export.txt", header="", columnNames="", modifier = "w")
      #saves the data=[[a,b,c],[d,e,f]] as
      #a   d
      #b   e
      #c   f
      #Assumes the data is stored in an array where all the subarrays are of the same length
      puts "save_ascii"
      #data.look
      #remove this notification? 
      if File.exist?(path) and modifier =="w"
        then
        #ask the user?
        puts "The file #{path} will be overwritten!"
        puts ""
      end
      #add error checking
      
      saveFile = File.new(path,modifier)
      begin      
        saveFile.print header
        saveFile.print columnNames
        
        if data[0].is_a?(Array) or data[0].is_a?(GSL::Vector)   # check for sub array
          #p "haer"
          # gamla hederliga for-loopar...
          #convert to arrays
          data = data.collect{|sub_array| sub_array.to_a}
          
          for i in 0...data[0].length
            mystr = ""
            for j in 0...data.length #build up one row at a time
              mystr += "#{data[j][i]}  "
            end
            saveFile.puts mystr 
          end
        else
          # dump data as
          # [a1]
          # [a2]
          #saveFile.puts "Saved without subarrays"
          data.each {|i| saveFile.puts i}
        end       
      ensure
        saveFile.close
      end
    end
  end
end

def save_asciifile(*args)
  puts "Please use TofFile.save_asciifile() instead!"
  TofFile.save_asciifile(*args)
end
