
#$:.push "/Volumes/filer/ruby/tof_pgm/moduler/"
tof_path=nil
require 'tof_save.rb'
require 'tempfile.rb'
require 'ruby_socker'
require 'tof_gnuplot.rb'
require 'tof_1d_hist'





class ZoomPlot
		include Tof_gnuplot
		
		attr_reader :range, :x_sel, :y_sel, :window_id, :range_index,
					:reference_norm

					#:x, :y
		attr_accessor :shift_reference_x, :reference_bkg_k, :reference_bkg_m,
					  :show_reference, :normalise, :show_range
					  
		def initialize(data=nil, legend=nil, fillcolour=8)
			
			#We want to be able to listen to gnuplot hence the r+ modifier
			@gnu_pipe = IO.popen("gnuplot","r+")
			@plotfile=Tempfile.new("tof_viewspec_whole")
			@plotfile_sel=Tempfile.new("tof_viewspec_selected")
			@reference_file=Tempfile.new("tof_viewspec_ref")
			@fillcolour=fillcolour
			@shift_reference_x = 0
			@reference_bkg_k =  0
			@reference_bkg_m = 0
			@reference_norm = 1
			@show_reference = true
			@normalise=false
			@show_range = true
			@range=nil
			@x=nil
			@y=nil
			@x_r=nil
			@y_r=nil
			@x_r_prim=nil
			@y_r_prim=nil
			@reference_norm=1
			@window_id = nil
			
		#We want to store the data in an tof_Hist to use its functions???
		
		#find out if data is an array or an Tof_1d_hist or has a +tot_e_hist+
		#Array -> hist
		#hist ->hist
		if data
			self.data= data
		end
		
		#@myplot_sel=Tof_1Dhist.new(nil,[0,1,2] ,@plotfile_sel.path)
	
		
		#@plotready = false
		
		#legend
		#unless legend
			#if data.respond_to?("tot_e_hist")
			#@legend = "#{data.spectrum.to_s.chomp}  (#{data.spectrum.excitation_energy} eV, t0 = #{data.spectrum.t0} ns)"
		
			#end
		#end	
	end
	
	#Sets the data set. Data must have x and y column
	def data=(data)
		#different possibilities
		#[[x1,x2,x3,...],[y1,y2,y3,...]
		#[[x1,y1],[x2,y2,...]
		
		#Histogram
		if data.class==Tof_1Dhist
			x, y = data.to_a_with_ranges
			@x = Vector.alloc x
			@y = Vector.alloc y
		else
			#Arrays or Vectors
			data.transpose! if data[0].length==2
			@x= Vector.alloc data[0]
			@y= Vector.alloc data[1]
		end
		
		#Sort data
		i = @x.sort_index
		@x=@x.sort!
		@y=@y[i]
		
		#talk to gnuplot but the position is a bit unexpected...
		cmd "unset key"
		
		deselect!
	end
	
	def reference=(data)
		#different possibilities
		#[[x1,x2,x3,...],[y1,y2,y3,...]
		#[[x1,y1],[x2,y2,...]
		
	
		if data.class==Tof_1Dhist
			#Histogram
			@x_r, @y_r = data.to_a_with_ranges
		elsif data==nil
			@x_r=nil
			@y_r=nil
			return nil
		else
			#Arrays or Vectors
			data.transpose! if data[0].length==2
			@x_r= Vector.alloc data[0]
			@y_r= Vector.alloc data[1]
		end
		
		#Sort data
		i = @x_r.sort_index
		@x_r=@x_r.sort!
		@y_r=@y_r[i]
		
	end
	
	def remove_reference
		reference= nil
	end
	
	def range=(arg)
		select_range(arg)
	end
	
	#Selects part of the graph and fills the area under the selection.
	def select_range(*range)
		if @x
			@range = range.flatten[0..1]
			@range.sort!
			#check for bad limits
			#@range[0] = @x.min  if @range[0] < @min.min
			#@range[1] = @max.max  if @range[1] > @max.max
		
			#Select data (May be slow if unreasonalble long data sets)
			im=index_of @range[0]
			iM=index_of @range[1]
			@range_index= [im,iM]
			@x_sel=@x.subvector im, iM-im+1
			@y_sel=@y.subvector im, iM-im+1
			
		else
			puts "Warning: Empty plot"
		end
		
	end
	#Unselects the selection.
	def deselect!
		@range=nil
	end
	def path 
		return @plotfile.path ,@plotfile_sel.path
	end
	
	#plots the data
	def plot
		#by writing cleverer code one could avoid writing to the files all the time...
		y=@y
		y/=y.max if @normalise
		save_asciifile([@x.to_a, y.to_a] , @plotfile.path) # this can be improved
		#@myplot.save_as_file
		cmd = "plot \"#{@plotfile.path}\" w l lc 3"
		if @range and @show_range
			y=@y_sel
			y/=@y.max if @normalise
			save_asciifile([@x_sel.to_a, y.to_a], @plotfile_sel.path)
			cmd += ",  \"#{@plotfile_sel.path}\" w filledcurves y1=0 lc #{@fillcolour}"
		end
		if @x_r and @show_reference
			calculate_reference
			save_asciifile([@x_r_prim.to_a, @y_r_prim.to_a] , @reference_file.path)
			cmd += ",  \"#{@reference_file.path}\" w l lc 2"
		end
		cmd(cmd)
	end
	
	def set_terminal(terminal)
		cmd "set terminal #{terminal}"
	end
	
	#Sets the gnuplot terminal to external x11. +window_id+ must be in hex format
	def set_external_x11_terminal(window_id)
		@window_id=window_id
		cmd "set terminal x11 window \"#{window_id}\""
	end
	
	def index_of(val)
		(@x-val).abs.min_index
	end
	
	def y_of_index(i)
		@y[i]
	end
	def x_of_index(i)
		@x[i]
	end
	
	def max
		@y.max
	end
	
	def find_max(range=nil)
		range = @range unless range
		#or the whole spectrum if there is no range
		range = [@x[0], @x[-1]] unless range
		range.sort!
		i_low=index_of range[0]
		i_high=index_of range[1]
		ysub=@y.subvector( i_low, i_high-i_low)
		y=ysub.max
		i=ysub.max_index
		x=@x[i+i_low]
		return x,y
	end
	
	#def normalise=var
			
	#end
	
	
	def flush_gnu_pipe
		@gnu_pipe.flush
	end
	
	
	def reference_norm=(var)
		if var
			@reference_norm=var
		else
			if @y_r_prim
				@reference_norm = @y_r_prim.max
			elsif @x_r
				calculate_reference
				@reference_norm = @y_r_prim.max
			else
				@reference_norm=1
				p "Error: No available reference"
			end 
		end
	end
	
private 
	def calculate_reference	
		@x_r_prim = @x_r + @shift_reference_x
		@y_r_prim = (@y_r - (@x_r_prim * @reference_bkg_k +
						 @reference_bkg_m))/@reference_norm
	end
end
