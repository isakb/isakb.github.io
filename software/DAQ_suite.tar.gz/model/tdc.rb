#!/usr/bin/ruby

require 'timeout'
require 'zlib'

$: << File.expand_path( File.dirname(__FILE__) )
require 'tdc_event'

# fix backward compatibility with Ruby 1.8
if RUBY_VERSION[0,3] == "1.9"
  class IO
    alias readchar readbyte
  end
end

class TdcCard

  TIMEOUT = 1 # How many seconds to wait for data to be available before giving up

  attr_accessor :debug

  #exceptions
  class ENoDevice < RuntimeError; end
  class ENoComSignal < RuntimeError; end
  class ENotRunning < RuntimeError; end
  class EBusy < RuntimeError; end
  class ETimeout < RuntimeError; end

  #enumerables
  class TDCState
    CLEAN = 0     # When no data has yet been aquired from card
    STOPPED = 1   # When a measurement is stopped by the user
    STARTING = 2  # When a measurement is about to start
    RUNNING = 4   # When a measurement is started
    PAUSED = 8    # When a measurement is paused (can be resumed with a new start command)
    ENDED = 16    # When a measurement is ended due to EOF from TDC card (no more data is available)
  end
  class TDCMode
    COMMON_START = 0
    COMMON_STOP = 1
     #; enums %w(COMMON_START COMMON_STOP);
  end


  #subclass
  class Connection
    READ = "rb"
    WRITE = "wb"

    class NoConn < RuntimeError; end
    def initialize(device, mode=:read)
      @f = nil
      @dev = device
      @mode = case mode
        when :read; READ
        when :write; WRITE
        else raise "Wrong mode"
      end
    end
    def transaction
      #reading from a gzipped data file? (simulated data stream from TDC card)
      if @dev =~ /\.gz$/
        Zlib::GzipReader.open(@dev) {|gz| yield gz }
        return true
      end
      begin
        @f = File.open(@dev, @mode)
        raise TdcCard::ETimeout, "#{@dev} timed out" if not ready?
        yield @f
        return true
      rescue ETimeout
        # return false
      rescue Errno::EBUSY => e
        raise TdcCard::EBusy, "#{@dev} is in use: #{e}"
      ensure
        @f.close
        @f = nil
      end
      false
    end
    protected
    # check if data is available to read from card or if card
    # is ready to accept data depending on @mode.
    # will only wait for TdcCard::TIMEOUT seconds,
    # then default to return false
    def ready?()
      r, w, e = IO.select([@f],[@f],[@f], TdcCard::TIMEOUT)
      if @mode == READ
        return r != nil
      end
      w != nil
    end
  end

  DEFAULT_DEVICE = "/dev/tdc"

  @@num_instances = 0
  @max_delay              #2x max time in ns
  @max_hits_per_channel   #maximum no of hits per channel
  @com_mode               #common start or common stop?
  @events                 #array of events
  @use_card               #shall we communicate with tdc card?

  attr_accessor :max_delay

  attr_reader :device,          #path do device, i.e. /dev/tdc
              :state,           #current state of the TDC Card
              :num_com_events,  #number of com events
              :num_hits,        #number of registered hits
              :num_bad_events   #number of disregarded events due to bad hits

  def initialize(device_file=nil)
    @debug = false
    @state = TDCState::CLEAN
    @use_card = device_file.nil?
    device = (device_file or DEFAULT_DEVICE)
    unless File.exist?(device)
      msg = "File does not exist: " + device
      if @use_card
        msg <<  (". Note: tdcmod.ko module must be loaded in the kernel, and " <<
                "the /dev/tdc node must be created properly.")
        raise ENoDevice
      end
      raise(Errno::ENOENT, msg)
    end
    @@num_instances += 1
    if @@num_instances > 1
      raise "Too many instances. Only one instance of TDCCard allowed."
    end
    @device = device
    configure
    reset
  end

  def configure(options = {})
    options = {
      :max_delay => 0xffff, # not really used anymore, t_max is used instead...
      :max_hits_per_channel => 16,
      :com_mode => TDCMode::COMMON_STOP,
      :t_min => 0,
      :t_max => 0xffff,
      :trig_rate => nil
    }.merge(options)
    @max_delay = options[:max_delay]
    @max_hits_per_channel = options[:max_hits_per_channel]
    @com_mode = options[:com_mode]
    @t_min = options[:t_min]
    @t_max = options[:t_max]
    begin
      _instruct_card("set_config #{@max_delay}, #{@max_hits_per_channel}")
      _instruct_card("set_com_mode #{@com_mode.to_i}")
      _instruct_card("set_time_range #{@t_min}, #{@t_max}")
      _instruct_card("set_trigger_rate_hz #{options[:trig_rate]}") if options[:trig_rate]
    rescue => e
      raise e if @debug
      return false
    end
    return true
  end

  def reset
    @state = TDCState::STOPPED
    @num_com_events = 0
    @num_hits = 0
    @num_bad_events = 0
  end

  def running?
    @state == TDCState::RUNNING
  end

  # start data gathering
  def start(num_com_signals=0)
    @state = TDCState::STARTING
    _instruct_card("start %d" % num_com_signals)
    @state = TDCState::RUNNING
  end

  # stop data gathering
  def stop
    _instruct_card("stop")
    @state = TDCState::STOPPED
  end

  # pause data gathering
  def pause
    _instruct_card("pause")
    @state = TDCState::PAUSED
  end
  
  # clears all data and resets measurement details
  def clear    
    _instruct_card("clear")
    @state = TDCState::CLEAN
  end

  # the status of the TDC card
  def status
    case @state
      when TDCState::CLEAN then "CLEAN"
      when TDCState::STOPPED then "STOPPED"
      when TDCState::STARTING then "STARTING" # if the card is starting up, getting ready to run
      when TDCState::RUNNING then "RUNNING"
      when TDCState::PAUSED then "PAUSED"
      when TDCState::ENDED then "ENDED"
      else "N/A"
    end
  end

  def each_event(file=nil, &block)
    file ||= @device
    conn = Connection.new(file, :read)
    return conn.transaction {|f|
      begin
        loop {
          num_hits = f.readchar
          break unless num_hits
          com_event = TDCEvent.new("%c%s" % [num_hits, f.read(num_hits*TDCHit::NUM_BYTES)])
          unless com_event.classify
            @num_bad_events += 1
            next
          end
          @num_hits += num_hits
          @num_com_events += 1
          if block.arity == 1
            yield com_event
          else
            yield @num_com_events, com_event
          end
        }
      rescue Errno::EIO => e
        puts "No COM signal: #{e}" if @debug
        pause
        raise ENoComSignal, "Trigger signal COM is silent. " + e
      rescue EOFError => e
        @state = TDCState::ENDED
        puts "No more data to read from TDC device: %s" % e if @debug
      rescue => e
        pause
        raise e
      end
    }
  end
  
  def read_raw_data(file=nil, &block)
    file ||= @device
    conn = Connection.new(file, :read)
    return conn.transaction {|f|
      begin
        loop {
          yield f.read()
        }
      rescue Errno::EIO => e
        puts "No COM signal: #{e}" if @debug
        pause
        raise ENoComSignal, "Trigger signal COM is silent. " + e
      rescue EOFError => e
        @state = TDCState::ENDED
        puts "No more data to read from TDC device: %s" % e if @debug
      rescue => e
        pause
        raise e
      end
    }
  end

  def each_event_raw(file=nil, &block)
    file ||= @device
    conn = Connection.new(file, :read)
    return conn.transaction {|f|
      begin
        loop {
          ##IO.readchar throws EOFError if end of file reached.
          ##same goes for IO.readbyte, which is only available in 1.9
          #num_hits = f.readchar # ruby 1.8
          num_hits = f.readchar
          data = f.read(num_hits * TDCHit::NUM_BYTES)
          yield num_hits, data
          @num_com_events += 1
          @num_hits += num_hits
        }
      rescue Errno::EIO => e
        puts "No COM signal: #{e}" if @debug
        pause
        raise ENoComSignal, "Trigger signal COM is silent. " + e
      rescue EOFError => e
        @state = TDCState::ENDED
        puts "No more data to read from TDC device: %s" % e if @debug
      rescue => e
        pause
        raise e
      end
    }
  end


  protected
  def _instruct_card(command)
    return unless @use_card
    puts "Telling card: %s" % command.dump if @debug
    begin
        conn = Connection.new(@device, :write)
        raise TdcCard::ETimeout, "Timeout when instructing card to #{command.dump}" unless\
          conn.transaction { |f| f.print(command) }
    rescue Errno::EACCES => e
      puts "No access! Make sure the tdcmod.ko module is loaded and then retry: #{e}"
      raise e
    end
  end
end




if __FILE__ == $0

  require '../helper/tdc_module_help'
  require '../helper/statistics'

  # get data from file instead of card?
  #FILE = "../data/data.dat"
  #FILE = "../data/data_20080229_01.dat.gz"
  #FILE = "../data/recorded_data_20080328_ch5-be.dat.gz"
  FILE = "../data/data_laser_2008-04-04_start_at_13_25_stop_at_14_15.dat.gz"
  #FILE = nil

  ShowOutput = false


  # This program reads COM events and studies
  # mean and standard deviation.
  # Use to test the speed of the driver etc,
  # by sending pulses to TDC-card from a
  # pulse generator.

  class Array
    include Statistics
  end

  T = 10 # how long to gather
  duration, num_com_events, num_hits = 0, 0, 0
  begin
    tdc = TdcCard.new(FILE)
  rescue TdcCard::ENoDevice => e
    puts "No TDC device found - #{e}"
    print "Get help on how to load module? (y/N): "
    ans = $stdin.gets.chop
    if ans.downcase == 'y'
      tdc_load_file = File.expand_path( File.dirname(__FILE__) + "/tdc_load")
      tdc_module_helper(tdc_load_file) if tdc_module_create_loader(tdc_load_file)
    end
    exit
  rescue
    raise
  end
  tdc.debug = true

  #tdc.max_delay = 32000

  Thread.abort_on_exception = true
  th1 = Thread.new do
    if FILE
      puts "Reading data from file " + FILE
    else
      puts "Testing card speed for #{T} s..."
      tdc.start
      sleep(T)
      tdc.stop
    end
  end

  th2 = Thread.new do

    # by default make a new array and store it
    # for hashkeys that doesn't exist:
    delays = Hash.new { |h,k| h[k] = [] }

    start_time = Time.now
    tries = 0
    begin

      #if tdc.each_event_raw do |n_hits, data|
      if tdc.each_event do |i, event|
        if ShowOutput
          #event = TDCEvent.new("%c%s" % [nhits, data])
          puts "COM Event #{i}:"
          puts event.to_s
        end
        event.each do |h|
          delays[h.channel] << h.delay
        end
      end then
        puts "All events processed."
      else
        puts "Processing events failed"
      end

      duration = Time.now - start_time

      puts "In total: %d events, %d hits, %d bad events" % [tdc.num_com_events, tdc.num_hits, tdc.num_bad_events]
      puts "com events/s: #{tdc.num_com_events/duration}"
      puts "hits/s: #{tdc.num_hits/duration}"
      puts "duration: #{duration} s"

      delays.default = nil
      delays.each do |ch, dlys|
        printf("CH%d: %d hits, avg: %.2f ns\n", ch, dlys.length, dlys.mean/2)
        printf("           std_dev: %.2f ns\n", dlys.std_dev/2)
      end

    rescue TdcCard::ENoComSignal => e
      puts "No COM signal detected: " << e
      unless tries > 10
        tries += 1
        puts "Retrying..."
        retry
      else
        puts "Could not get COM signal."
  tdc.stop
      end
    rescue TdcCard::ENotRunning => e
      unless tries > 10
        tries += 1
        tdc.start
        retry
      end
      puts  "TDC Card is not running: " << e
    rescue TdcCard::EBusy => e
      unless tries > 10
        tries += 1
        tdc.start
        retry
      end
      puts "TDC Card is busy: " << e
    rescue => e
      puts "error in main: #{e}"
      p e
      raise e
    end
    Thread.list.each {|t| t.kill }

  end

  # make sure that th1 always executes completely
  # even if main thread is finished first.
  th1.join
  th2.join

end
