#!/usr/bin/env ruby

# A minimalistic 2D vector class
# mostly copied from: http://www.koders.com/ruby/fidFB6CBBA5461CE0F6417F081EB570782235E60069.aspx?s=game#L5
# and rewritten more compactly
class Vector
  attr_accessor :x, :y  
  
  def initialize(x=0, y=0) @x, @y = x, y end

  def to_s() "(%0.2f, %0.2f)" % [@x, @y] end
  def to_a() [@x, @y] end

  #operators etc:
  def [](index) [@x, @y][index] end
  def ==(other) self.to_a == other.to_a end  
  
  def *(other) other.kind_of?(Numeric) ? self.class.new(@x*other,@y*other) : self.class.new(@x*other[0], @y*other[1]) end
  def /(other) x,y=@x.to_f,@y.to_f; other.kind_of?(Numeric) ? self.class.new(x/other, y/other) : self.class.new(x/other[0], y/other[1]) end
  def +(other) self.class.new(@x+other[0],@y+other[1]) end
  def -(other) self.class.new(@x-other[0],@y-other[1]) end
  def dot(other) @x*other[0] + @y*other[1] end

  def norm() Math.hypot(@x, @y) end
  def tangent() self.class.new(-@y, @x) end

end