require 'gtkglext'

$: << File.expand_path( File.dirname(__FILE__))
require 'vector'

module GLRenderPrimitives
  
  # parse CSS-style str as option hash. Help function for drawHistogram.
  def parse_options(str)
    opts = {}
    str.split(";").map {|pair|
      begin
        pair = pair.split(":").map{|t| t.strip}
        if pair[1] =~ /%$/
          pair[1] = pair[1].to_f/100
          pair[1] *= case pair[0]
            when 'width': @Xsize
            when 'height': @Ysize
            else 1
          end
        elsif pair[1].to_i.to_s == pair[1]
          pair[1] = pair[1].to_i
        end        
        opts[pair[0].to_sym] = pair[1]
      rescue => e
        next
      end  
    }
    opts[:size] = [opts[:width], opts[:height]] if opts[:width] && opts[:height]
    return opts
  end   
  
  def moveTo(x, y=nil) x.kind_of?(Vector) or x.kind_of?(Array) ? GL.Translate(x[0], x[1], 0) : GL.Translate(x,y,0) end    
  
  def drawHistogram(dict=nil, options={})
    if options.kind_of?(String)
      options = parse_options(options)
    end    
    options[:size] ||= [400,300]    
    options[:padding] ||= 10
    options[:pos] ||= [-options[:size][0]/2, -options[:size][1]/2]    
    
    pos = options[:pos]
    size = options[:size]
    padding = options[:padding]    
    
    width = size[0].to_f
    height = size[1].to_f
    if dict.nil? #make up a histogram of random values
      dict = Hash.new(0)
      (0..800).each do |i|
        dict[i] = 50.0*(Math.cos(10.0*i)**2) + rand(10)
      end
    end 
    
    # container box:
    GL.PushMatrix()
      moveTo(pos[0], -pos[1])
      GL.LineWidth(1)    
      GL.Begin(GL::QUADS) 
        GL.PolygonMode(GL::FRONT, GL::FILL)
        GL.Color3f(0, 0, 0)
        GL.Vertex2f(0, 0)
        GL.Vertex2f(0, -height)        
        GL.Vertex2f(width, -height)
        GL.Vertex2f(width, 0)        
      GL.End()
    GL.PopMatrix() 
    
    
    val_max = dict.values.max.to_f
    t_max = dict.keys.max
    
    return if t_max.nil? or val_max.nil?

    # draw histogram within container, and also add some padding
    GL.PushMatrix()
      moveTo(pos[0], -pos[1])
      moveTo(padding, -padding)
      GL.LineWidth(1)
      # go through all timebins in histogram
      0.upto(t_max) do |t|          
               
        ratio = dict[t]
        next unless ratio > 0
        ratio /= val_max        
        GL.PushMatrix()    
          moveTo((t/t_max.to_f)*(width-2*padding), 0)   
          GL.Begin(GL::LINES)              
            GL.Color3f(0.5, 0, 0)
            GL.Vertex2f(0, 0)
            GL.Color3f(0.5+0.5*ratio, ratio, ratio*0.2)
            GL.Vertex2f(0, -ratio * (height-2*padding))
          GL.End()
        GL.PopMatrix()
      end
    GL.PopMatrix()
      
      


#    # draw histogram within container, and also add some padding
#    max = dict.values.max
#    GL.PushMatrix()
#      moveTo(pos[0], -pos[1])
#      moveTo(padding, -padding)
#      GL.LineWidth(1)      
#        dict.values.each do |val|
#          ratio = val / max.to_f
#          GL.PushMatrix()
#            GL.Begin(GL::LINES)  
#              GL.Color3f(0.2, 0, 0)
#              GL.Vertex2f(0, 0)        
#              GL.Color3f(0.2+0.8*ratio, ratio, ratio*0.1)
#              GL.Vertex2f(0, -ratio * (height-2*padding))
#            GL.End()
#          GL.PopMatrix()
#          moveTo((width-2*padding)/dict.length, 0)
#     
#        end
#    GL.PopMatrix()
  end
  
  
  # Draw a filled circle, center is a 2D vector or array.
  def drawCircleFilled(center, radius, linecolor=nil, fillcolor=nil)
    GL.PushMatrix()
    GL.Translate(center[0], center[1], 0)    
    GL.PolygonMode(GL::FRONT, GL::FILL)
    GL.Begin(GL::TRIANGLE_FAN)
      0.step(360,5) do |i|
        GL.Vertex2f(radius * Math.sin(i * Math::PI/180), radius * Math.cos(i * Math::PI/180))
      end    
    GL.End()
    GL.PopMatrix()
  end
  
  # Draw a hollow circle, center is a 2D vector or array.
  def drawCircle(center, radius, linecolor=nil)
    GL.Translate(center[0], center[1], 0)   
    GL.Begin(GL::LINE_LOOP)
      0.step(360,5) do |i|
        GL.Vertex2f(radius * Math.sin(i * Math::PI/180), radius * Math.cos(i * Math::PI/180))
      end    
    GL.End()
  end    
end

