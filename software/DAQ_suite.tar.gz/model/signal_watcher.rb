# This class can be used together with an Observable class.
# It is used to watch variables and perform callback functions
# if the variable is changed, or otherwise emits a signal.

class SignalWatcher
  def initialize(model, respond_to_signals=nil, &block)
    model.add_observer(self)
    @respond_to = respond_to_signals
    if block_given?
      @callback = lambda &block
    end
  end
  def update(signal, *args)
    if !@respond_to or @respond_to.include?(signal)
      #p [signal, *args]
      @callback.call(*args) if @callback
    else
      #p "Not responding to signal " << signal.to_s
    end
  end
end


# Example of usage:
if __FILE__ == $0    
  
  require 'observer'
  class ObservableModel
    include Observable
    attr :x
    def x=(value)
      if value != @x
        @x = value
        changed
        notify_observers(:x_change, @x)
      end    
    end
  end
  
  model = ObservableModel.new
  
  SignalWatcher.new(model, [:x_change]) { |val|
    print "x has now changed value to: ", val, " (%s)\n" % val.class
  } 
  
  puts model.x
  
  model.x = 2
  model.x = 5
  model.x = 5 # should not signal a change
  model.x = nil
  
  model.x = {:test => "value", :test2 => "value2"}

end