För att kompilera:
$ make
För att rensa efter kompilering:
$ make clean

För att loada modulen när den är kompilerad:
$ sudo ./tdc_load

För att unloada modulen:
$ sudo ./tdc_unload

Dessa script skapar filen i /dev/tdc som används för åtkomst till
TDC-kortet.
